# NetSpout Dashboard Extension V2 — Developer Handoff

## Scope

This Figma Make prototype refines the existing Dashboard Gallery and scenario
dashboard. It does not implement Splunk searches, ingestion, Dashboard Studio
JSON generation, deployment, CIM normalization, or backend APIs.

## Implemented prototype interactions

- Gallery search by scenario ID, name, vendor, product, and telemetry
- Domain and dashboard-maturity filters
- Card and compact table views
- Five Phase 8C Golden reference cards
- Scenario-specific navigation from Gallery to Dashboard
- Searchable native scenario selector in the dashboard header
- NOC, Engineer, and Evidence perspectives
- Entity, path, KPI, and timeline drilldowns with removable filter chips
- Clear Filters and Reset
- Visualization selection rationale and explicit fallback
- Advanced Inspector tabs:
  Overview, Visualization, Data, SPL, Fields, CIM, Tokens, Dependencies,
  Validation
- Validation chain with Pending, Passed, Failed, and Not Applicable states
- Export versus Deploy dialog states
- Scenario-aware NOC wallboard and exit path
- Research Required blocked state with no fallback dashboard

## Route and state model

Conceptual route:

`Dashboards → Scenario ID → Selected View`

Current prototype state:

- `page`: Gallery or Dashboard
- `selectedDashboardId`: stable Cisco 100 scenario identifier
- `view`: NOC, Engineer, or Evidence
- `selected`: entity, path, KPI, or timeline context
- `filters`: removable active-filter chips
- `inspectorTab`: selected Advanced Inspector section
- `exportOpen`: export/deploy specification dialog
- `wallboard`: large-screen projection of the same selected Dashboard Pack

Implementation may later encode this state in routing, but no URL or backend
contract is asserted by the prototype.

## Component hierarchy

- `DashboardGallery`
  - reference rail
  - search and filters
  - layout switcher
  - Dashboard Gallery Card / compact row
- `ScenarioAwareDashboard`
  - Dashboard Header and Scenario Selector
  - View Switcher
  - active filter chips
  - NOC composition
  - Engineer composition
  - Evidence composition
  - `DashboardInspector`
  - `DashboardExportDialog`
  - wallboard composition
- `ResearchRequiredDashboard`
- Shared components:
  KPI Tile, Status Indicator, Topology Panel, Timeline, Investigation Table,
  Contract Stack, Validation Chain, and Dashboard Maturity Indicator

## Dashboard recipe selection

The scenario selects a recipe family such as Campus Health, Routing Health,
Data Center Fabric, Security Policy, or Cross-Domain Incident.

- `AUTO GENERATED`: select relevant shared panels from scenario metadata.
- `CURATED`: apply scenario-specific ordering/layout hints without replacing
  shared components.
- Omit irrelevant panels rather than rendering empty placeholders.
- Vendor-specific structural fields must come from verified source contracts,
  never from the visualization recipe.

## NOC / Engineer / Evidence composition

- NOC: health, affected entities, topology, KPI state, incident progression,
  and recovery.
- Engineer: detailed relationships, source correlation, investigation scope,
  expected findings, troubleshooting, and SPL contract status.
- Evidence: Native, Splunk, and NetSpout contracts; provenance; scenario
  runtime evidence; dashboard validation; CIM; expected versus observed.

Scenario maturity, dashboard maturity, Splunk observation, and CIM remain
independent indicators.

## Design tokens and layout

Preserve the existing NetSpout tokens in `netspout.css`:

- dark navigation and dashboard canvas
- existing navy/slate/accent/status colors
- compact IBM Plex Mono technical identifiers
- existing typography and spacing scale
- 1px technical panel borders and restrained square geometry

Desktop dashboard minimum remains 1120px. Gallery cards collapse to one column
at 1024px. The reference rail and command header reflow at 1320px. Wallboard is
intentionally optimized for a large NOC display.

## Topology and drilldown behavior

- Exactly one primary topology visualization is selected.
- Show selection reason, app dependency, installation/compatibility state, and
  an explicit supported alternative.
- Never silently substitute an incompatible visualization.
- Device click filters related panels by entity.
- Link click selects a path/dependency.
- KPI click opens supporting telemetry context.
- Timeline click scopes the investigation phase/time context.
- Security/event click opens correlated evidence context.
- Source/contract click opens the corresponding Inspector section.
- Filter chips are removable; Clear Filters restores scenario scope.

Production Splunk token names are intentionally not defined.

## Validation states

Required chain:

`Generated → SPL Checked → Search Executed → Fields Verified →
Data Shape Verified → Visualization Rendered → Drilldowns Tested →
Dashboard Ready`

Each stage supports Pending, Passed, Failed, and Not Applicable.
Figma rendering does not pass any stage. All five reference dashboards begin
as `NOT VALIDATED` or `DESIGN PREVIEW`; CIM is `NOT_ESTABLISHED`.

## Visualization dependencies

The prototype can represent:

1. Native Network Graph
2. Network Diagram Viz — Splunkbase App 4438
3. 3D Graph Network Topology — Splunkbase App 4611
4. Topology Visualization — Splunkbase App 9051
5. Flow Map Viz — Splunkbase App 4657

Implementation must verify app installation, version, Dashboard Studio or
Classic compatibility, required data shape, and license before enabling a
selection.

## Export and deployment

- Export produces an artifact after dashboard validation.
- Dashboard Studio JSON is the preferred design state.
- Classic XML appears only when a compatibility contract supports it.
- Deploy installs or updates an artifact in an authorized Splunk environment.
- Deployment requires connection, authorization, dependency, compatibility,
  conflict/update, and validation checks.
- Prototype buttons never claim export or deployment success.

## Future backend integration required

- Resolve scenario and Dashboard Pack data
- Execute and validate SPL
- Verify index, sourcetype, fields, and data shape
- Resolve visualization app inventory and compatibility
- Persist dashboard-validation evidence
- Generate Dashboard Studio JSON or supported Classic XML
- Authorize and perform Splunk deployment
- Return deployment status and open-in-Splunk URL
- Supply production-safe drilldown token definitions

No endpoint names are prescribed by this handoff.

## Empty, error, and research states

- Research Required: block Run and Dashboard; list missing evidence; create no
  fallback telemetry, SPL, sourcetype, TA, or CIM.
- Missing visualization dependency: preserve selected visualization and offer
  an explained supported alternative.
- Search or validation failure: mark the exact failed stage and retain prior
  evidence.
- Splunk unavailable: permit design review/export preview only where valid;
  disable Deploy.
- No relevant panel recipe: omit the panel and explain the missing contract in
  Evidence.
