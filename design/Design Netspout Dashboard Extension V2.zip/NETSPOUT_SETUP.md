# NetSpout UI

NetSpout is a unified enterprise telemetry lab designed for Splunk.

## Application files

- `src/netspout/NetSpoutApp.tsx` — NetSpout application shell, workflows, and interactive views
- `src/netspout/netspout.css` — NetSpout design tokens, components, layouts, and responsive behavior
- `src/App.tsx` — Minimal mount for the NetSpout product module
- `src/main.tsx` — React entrypoint
- `src/index.css` — Tailwind and shared font imports
- `.figma/make/site.json` — NetSpout preview metadata

## Current product areas

- Network Lab overview
- Generate Telemetry
- Scenario Library
- Scenario Detail
- Live Scenario Run
- Pipeline Health
- Docker Splunk destination
- External Splunk HEC destination
- Six-domain enterprise simulation model
- Data source, sourcetype, and single-event generators
- Multi-domain incident timeline
- Evidence pipeline
- Incident investigation
- Telemetry and provenance explorers
- Agentic AI incident view
- Multi-domain scenario builder
- Technical contract explorer
- Native / Splunk / NetSpout contract separation
- Provenance and source-verification states
- Splunk integration recommendation catalog
- Scenario source manifests and fidelity status
- Security scenario intelligence and coverage matrix
- Security scenario library, attack flow, source manifest, and live evidence boundary
- Separate Splunk Security Content, Sigma, and YARA coverage panels
- ITOps memory-pressure scenario, resource behavior, and service-health model
- Planned Supply Chain repository-to-runtime model and Dependency Confusion flow
- Expanded Scenario Builder entity palette for Security, ITOps, and Supply Chain

## Trust model

NetSpout fails closed when a telemetry contract cannot be verified. Vendor, standard,
Splunk, dataset, NetSpout-schema, modeled-value, research-required, and unsupported
states are displayed explicitly. NetSpout-defined sourcetypes use the `netspout:`
namespace and are never presented as vendor or official Splunk sourcetypes.

Supply Chain scenarios remain `PLANNED` and their platform telemetry contracts remain
`RESEARCH REQUIRED` until a source-control, CI/CD, registry, and deployment platform
has been selected and verified. Security detection mappings do not claim that a
detection fired unless the mapping is present in the verified catalog.

The development server is managed by Figma Make and updates through Vite hot reload.
