import { Component, lazy, Suspense, type ErrorInfo, type ReactNode } from "react";
import "./netspout/netspout.css";

const NetSpoutApp = lazy(() => import("./netspout/NetSpoutApp"));

class ModuleErrorBoundary extends Component<{ children: ReactNode }, { failed: boolean }> {
  state = { failed: false };

  static getDerivedStateFromError() {
    return { failed: true };
  }

  componentDidCatch(error: Error, info: ErrorInfo) {
    console.error("NetSpout module failed to load", error, info);
  }

  render() {
    if (this.state.failed) {
      return <main className="module-error" role="alert"><strong>NetSpout could not load the latest application module.</strong><span>The preview may have an outdated cached module.</span><button onClick={() => window.location.reload()}>Reload NetSpout</button></main>;
    }
    return this.props.children;
  }
}

export default function App() {
  return <ModuleErrorBoundary><Suspense fallback={<main className="module-loading"><span/><strong>Loading NetSpout</strong></main>}><NetSpoutApp /></Suspense></ModuleErrorBoundary>;
}
