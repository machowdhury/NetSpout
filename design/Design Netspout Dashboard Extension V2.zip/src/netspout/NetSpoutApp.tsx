import { useMemo, useState, type ReactNode } from "react"

type Page = "home" | "generate" | "data-source" | "sourcetype" | "single-event" | "scenarios" | "dashboards" | "dashboard" | "security" | "security-run" | "itops" | "supply-chain" | "supply-run" | "scenario" | "run" | "timeline" | "investigation" | "explorer" | "provenance" | "integrations" | "builder" | "agentic" | "pipeline" | "connections"
type IconName = "home" | "bolt" | "layers" | "radio" | "database" | "search" | "settings" | "help" | "menu" | "chevron" | "arrow" | "play" | "check" | "clock" | "server" | "network" | "pulse" | "shield" | "terminal" | "plug" | "more" | "grid" | "list" | "filter" | "external" | "copy"

const iconPaths: Record<IconName, ReactNode> = {
  home: (
    <>
      <path d="m3 11 9-7 9 7" />
      <path d="M5 10v10h14V10M9 20v-6h6v6" />
    </>
  ),
  bolt: <path d="m13 2-9 12h7l-1 8 9-12h-7z" />,
  layers: (
    <>
      <path d="m12 3-9 5 9 5 9-5z" />
      <path d="m3 12 9 5 9-5M3 16l9 5 9-5" />
    </>
  ),
  radio: (
    <>
      <circle cx="12" cy="12" r="2" />
      <path d="M8.5 8.5a5 5 0 0 0 0 7m7-7a5 5 0 0 1 0 7M5 5a10 10 0 0 0 0 14m14-14a10 10 0 0 1 0 14" />
    </>
  ),
  database: (
    <>
      <ellipse cx="12" cy="5" rx="8" ry="3" />
      <path d="M4 5v6c0 1.7 3.6 3 8 3s8-1.3 8-3V5M4 11v6c0 1.7 3.6 3 8 3s8-1.3 8-3v-6" />
    </>
  ),
  search: (
    <>
      <circle cx="11" cy="11" r="7" />
      <path d="m16 16 5 5" />
    </>
  ),
  settings: (
    <>
      <circle cx="12" cy="12" r="3" />
      <path d="M19.4 15a1.7 1.7 0 0 0 .3 1.9l.1.1-2.8 2.8-.1-.1a1.7 1.7 0 0 0-1.9-.3 1.7 1.7 0 0 0-1 1.6v.2h-4V21a1.7 1.7 0 0 0-1-1.6 1.7 1.7 0 0 0-1.9.3l-.1.1L4.2 17l.1-.1a1.7 1.7 0 0 0 .3-1.9A1.7 1.7 0 0 0 3 14H2.8v-4H3a1.7 1.7 0 0 0 1.6-1 1.7 1.7 0 0 0-.3-1.9L4.2 7 7 4.2l.1.1a1.7 1.7 0 0 0 1.9.3A1.7 1.7 0 0 0 10 3V2.8h4V3a1.7 1.7 0 0 0 1 1.6 1.7 1.7 0 0 0 1.9-.3l.1-.1L19.8 7l-.1.1a1.7 1.7 0 0 0-.3 1.9 1.7 1.7 0 0 0 1.6 1h.2v4H21a1.7 1.7 0 0 0-1.6 1Z" />
    </>
  ),
  help: (
    <>
      <circle cx="12" cy="12" r="9" />
      <path d="M9.6 9a2.5 2.5 0 1 1 3.6 2.3c-.8.4-1.2 1-1.2 1.7m0 4h.01" />
    </>
  ),
  menu: <path d="M4 7h16M4 12h16M4 17h16" />,
  chevron: <path d="m9 6 6 6-6 6" />,
  arrow: <path d="M5 12h14m-5-5 5 5-5 5" />,
  play: <path d="m8 5 11 7-11 7z" />,
  check: <path d="m5 12 4 4L19 6" />,
  clock: (
    <>
      <circle cx="12" cy="12" r="9" />
      <path d="M12 7v5l3 2" />
    </>
  ),
  server: (
    <>
      <rect x="3" y="4" width="18" height="6" rx="1" />
      <rect x="3" y="14" width="18" height="6" rx="1" />
      <path d="M7 7h.01M7 17h.01" />
    </>
  ),
  network: (
    <>
      <rect x="9" y="3" width="6" height="5" rx="1" />
      <rect x="3" y="16" width="6" height="5" rx="1" />
      <rect x="15" y="16" width="6" height="5" rx="1" />
      <path d="M12 8v4M6 16v-4h12v4" />
    </>
  ),
  pulse: <path d="M3 12h4l2-6 4 12 2-6h6" />,
  shield: <path d="M12 3 5 6v5c0 4.5 3 7.8 7 9 4-1.2 7-4.5 7-9V6z" />,
  terminal: (
    <>
      <path d="m5 7 4 5-4 5m7 0h7" />
    </>
  ),
  plug: (
    <>
      <path d="m8 12 8-8m-6 2 4 4M7 13l4 4-3 3-4-4z" />
    </>
  ),
  more: (
    <>
      <circle cx="5" cy="12" r="1" />
      <circle cx="12" cy="12" r="1" />
      <circle cx="19" cy="12" r="1" />
    </>
  ),
  grid: (
    <>
      <rect x="4" y="4" width="6" height="6" />
      <rect x="14" y="4" width="6" height="6" />
      <rect x="4" y="14" width="6" height="6" />
      <rect x="14" y="14" width="6" height="6" />
    </>
  ),
  list: <path d="M8 6h12M8 12h12M8 18h12M4 6h.01M4 12h.01M4 18h.01" />,
  filter: <path d="M3 5h18l-7 8v5l-4 2v-7z" />,
  external: (
    <>
      <path d="M14 4h6v6M20 4l-9 9" />
      <path d="M18 13v6H5V6h6" />
    </>
  ),
  copy: (
    <>
      <rect x="8" y="8" width="11" height="11" rx="1" />
      <path d="M16 8V5H5v11h3" />
    </>
  ),
}

function Icon({ name, size = 18 }: { name: IconName; size?: number }) {
  return (
    <svg
      className="icon"
      aria-hidden="true"
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.8"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      {iconPaths[name]}
    </svg>
  )
}

function Button({
  children,
  onClick,
  variant = "primary",
  icon,
  disabled,
}: {
  children: ReactNode
  onClick?: () => void
  variant?: "primary" | "secondary" | "ghost" | "danger"
  icon?: IconName
  disabled?: boolean
}) {
  return (
    <button
      className={`button button--${variant}`}
      onClick={onClick}
      disabled={disabled}
    >
      {children}
      {icon && <Icon name={icon} size={16} />}
    </button>
  )
}

function Status({
  children,
  tone = "healthy",
}: {
  children: ReactNode
  tone?: "healthy" | "warning" | "error" | "info" | "neutral"
}) {
  return (
    <span className={`status status--${tone}`}>
      <i />
      {children}
    </span>
  )
}

function Badge({
  children,
  tone = "neutral",
}: {
  children: ReactNode
  tone?: "neutral" | "blue" | "purple" | "amber" | "green"
}) {
  return <span className={`badge badge--${tone}`}>{children}</span>
}

const navGroups = [
  { label: "Home", items: [["home", "Overview", "home"]] },
  {
    label: "Generate",
    items: [
      ["generate", "Quick Generate", "bolt"],
      ["scenarios", "Scenarios", "layers"],
    ],
  },
  { label: "Build", items: [["builder", "Scenario Builder", "settings"]] },
  {
    label: "Observe",
    items: [
      ["dashboards", "Dashboards", "grid"],
      ["run", "Live Runs", "pulse"],
      ["explorer", "Telemetry Explorer", "search"],
      ["pipeline", "Pipeline Health", "radio"],
    ],
  },
  {
    label: "Investigate",
    items: [
      ["timeline", "Incident Timeline", "clock"],
      ["investigation", "Incident Investigation", "shield"],
      ["security", "Security Intelligence", "search"],
    ],
  },
  {
    label: "Catalog",
    items: [
      ["provenance", "Provenance", "database"],
      ["integrations", "Splunk Integrations", "plug"],
    ],
  },
  { label: "System", items: [["connections", "Connections", "plug"]] },
] as const

function Sidebar({
  page,
  navigate,
  collapsed,
  setCollapsed,
}: {
  page: Page
  navigate: (p: Page) => void
  collapsed: boolean
  setCollapsed: (v: boolean) => void
}) {
  return (
    <aside className={`sidebar ${collapsed ? "sidebar--collapsed" : ""}`}>
      <div className="brand">
        <div className="brand__mark">
          <Icon name="radio" size={21} />
        </div>
        {!collapsed && (
          <div>
            <strong>NetSpout</strong>
            <small>Telemetry Lab</small>
          </div>
        )}
        <button
          className="icon-button collapse"
          onClick={() => setCollapsed(!collapsed)}
          aria-label="Collapse navigation"
        >
          <Icon name="menu" />
        </button>
      </div>
      <nav aria-label="Primary navigation">
        {navGroups.map((group) => (
          <div className="nav-group" key={group.label}>
            {!collapsed && <div className="nav-label">{group.label}</div>}
            {group.items.map(([target, label, icon], index) => (
              <button
                title={collapsed ? label : undefined}
                key={`${label}-${index}`}
                className={`nav-item ${
                  page === target ||
                  (target === "scenarios" && page === "scenario") ||
                  (target === "dashboards" && page === "dashboard")
                    ? "nav-item--active"
                    : ""
                }`}
                onClick={() => navigate(target as Page)}
              >
                <Icon name={icon as IconName} />
                {!collapsed && <span>{label}</span>}
              </button>
            ))}
          </div>
        ))}
      </nav>
      <div className="sidebar__footer">
        <button className="nav-item">
          <Icon name="help" />
          {!collapsed && <span>Help & documentation</span>}
        </button>
        {!collapsed && <div className="build-label">NETSPOUT 2.4.0 · LAB</div>}
      </div>
    </aside>
  )
}

const pageNames: Record<Page, string> = {
  home: "Unified Telemetry Lab",
  generate: "Generate Telemetry",
  "data-source": "Data Source Generator",
  sourcetype: "Sourcetype Generator",
  "single-event": "Single Event Generator",
  scenarios: "Scenario Library",
  dashboards: "Dashboard Gallery",
  dashboard: "Scenario Dashboard",
  security: "Security Scenario",
  "security-run": "Security Live Run",
  itops: "ITOps Scenario",
  "supply-chain": "Supply Chain Scenario",
  "supply-run": "Supply Chain Preview",
  scenario: "Infrastructure Smoke Screen",
  run: "Live Scenario Run",
  timeline: "Incident Timeline",
  investigation: "Incident Investigation",
  explorer: "Telemetry Explorer",
  provenance: "Telemetry Provenance",
  integrations: "Splunk Integrations",
  builder: "Scenario Builder",
  agentic: "Agentic AI Incident",
  pipeline: "Pipeline Health",
  connections: "Connections",
}

function Topbar({
  page,
  advanced,
  setAdvanced,
}: {
  page: Page
  advanced: boolean
  setAdvanced: (value: boolean) => void
}) {
  return (
    <header className="topbar">
      <div className="breadcrumb">
        <span>NetSpout</span>
        <Icon name="chevron" size={13} />
        <strong>{pageNames[page]}</strong>
      </div>
      <div className="topbar__actions">
        <label className="mode-toggle">
          <span>Simple</span>
          <input
            type="checkbox"
            checked={advanced}
            onChange={(event) => setAdvanced(event.target.checked)}
          />
          <i />
          <span>Advanced</span>
        </label>
        <div className="connection-state">
          <Status>Splunk connected</Status>
        </div>
        <button className="icon-button" aria-label="Help">
          <Icon name="help" />
        </button>
        <button className="avatar" aria-label="User profile">
          NE
        </button>
      </div>
    </header>
  )
}

function Connections() {
  const [testing, setTesting] = useState<"docker" | "external" | null>(null)
  const [tested, setTested] = useState({ docker: true, external: false })
  const [dockerEnabled, setDockerEnabled] = useState(true)
  const [externalEnabled, setExternalEnabled] = useState(true)
  const [routing, setRouting] = useState<"both" | "docker" | "external">("both")
  const test = (target: "docker" | "external") => {
    setTesting(target)
    window.setTimeout(() => {
      setTesting(null)
      setTested((current) => ({ ...current, [target]: true }))
    }, 900)
  }
  return (
    <div className="page">
      <header className="page-header">
        <div>
          <div className="eyebrow">System</div>
          <h1>Splunk Destinations</h1>
          <p>
            Send every generated event to the bundled Docker lab, an external
            Splunk HEC endpoint, or both.
          </p>
        </div>
        <Status tone={tested.external ? "healthy" : "warning"}>
          {tested.external
            ? "2 destinations ready"
            : "1 of 2 destinations verified"}
        </Status>
      </header>
      <section className="routing-bar">
        <div>
          <div className="panel-kicker">Delivery policy</div>
          <h2>Where should NetSpout send events?</h2>
        </div>
        <div className="routing-options">
          {[
            ["both", "Both destinations", "Mirror each event"],
            ["docker", "Docker only", "Keep data in the lab"],
            ["external", "External only", "Send through HEC"],
          ].map(([value, label, detail]) => (
            <button
              key={value}
              className={routing === value ? "active" : ""}
              onClick={() =>
                setRouting(value as "both" | "docker" | "external")
              }
            >
              <i />
              <span>
                <strong>{label}</strong>
                <small>{detail}</small>
              </span>
            </button>
          ))}
        </div>
      </section>
      <div className="connections-layout">
        <main>
          <section className="connection-card">
            <header>
              <div className="connection-logo docker">
                <Icon name="server" />
              </div>
              <div>
                <h2>Bundled Docker Splunk</h2>
                <p>Local lab destination managed with NetSpout</p>
              </div>
              <Status>CONNECTED</Status>
              <label
                className="switch"
                aria-label="Enable Docker Splunk destination"
              >
                <input
                  type="checkbox"
                  checked={dockerEnabled}
                  onChange={(event) => setDockerEnabled(event.target.checked)}
                />
                <i />
              </label>
            </header>
            <div className="destination-summary">
              <div>
                <span>Container</span>
                <strong>netspout-splunk</strong>
              </div>
              <div>
                <span>HEC endpoint</span>
                <code>https://splunk:8088/services/collector</code>
              </div>
              <div>
                <span>Event index</span>
                <code>netspout_events</code>
              </div>
              <div>
                <span>Metrics index</span>
                <code>netspout_metrics</code>
              </div>
            </div>
            <div className="connection-body">
              <div className="field-grid">
                <label>
                  <span>HEC Token</span>
                  <div className="secret-input">
                    <input
                      type="password"
                      defaultValue="netspout-docker-token"
                    />
                    <button>Show</button>
                  </div>
                </label>
                <label>
                  <span>Container network</span>
                  <input defaultValue="netspout_default" />
                </label>
              </div>
            </div>
            <footer>
              <div>
                {tested.docker ? (
                  <span className="test-success">
                    <Icon name="check" size={15} />
                    <strong>HEC verified</strong> · ACK received in 46 ms
                  </span>
                ) : (
                  <span>Connection has not been tested</span>
                )}
              </div>
              <Button
                variant="secondary"
                onClick={() => test("docker")}
                disabled={testing === "docker"}
              >
                {testing === "docker" ? "Testing Docker…" : "Test HEC"}
              </Button>
              <Button>Save</Button>
            </footer>
          </section>
          <section className="connection-card">
            <header>
              <div className="connection-logo external">
                <Icon name="external" />
              </div>
              <div>
                <h2>External Splunk HEC</h2>
                <p>Splunk Enterprise or Splunk Cloud</p>
              </div>
              {tested.external ? (
                <Status>CONNECTED</Status>
              ) : (
                <Status tone="warning">NOT VERIFIED</Status>
              )}
              <label
                className="switch"
                aria-label="Enable external Splunk destination"
              >
                <input
                  type="checkbox"
                  checked={externalEnabled}
                  onChange={(event) => setExternalEnabled(event.target.checked)}
                />
                <i />
              </label>
            </header>
            <div className="connection-body">
              <div className="field-grid">
                <label className="wide-field">
                  <span>HEC URL</span>
                  <input
                    placeholder="https://splunk.example.com:8088/services/collector"
                    defaultValue="https://splunk.example.com:8088/services/collector"
                  />
                </label>
                <label>
                  <span>HEC Token</span>
                  <div className="secret-input">
                    <input type="password" placeholder="Enter HEC token" />
                    <button>Show</button>
                  </div>
                </label>
                <label>
                  <span>Event index</span>
                  <input defaultValue="netspout_events" />
                </label>
                <label>
                  <span>Metrics index</span>
                  <input defaultValue="netspout_metrics" />
                </label>
                <label>
                  <span>Source</span>
                  <input defaultValue="netspout" />
                </label>
              </div>
              <div className="tls-row">
                <div>
                  <strong>Verify TLS certificate</strong>
                  <span>
                    Required for Splunk Cloud and recommended for external
                    Enterprise
                  </span>
                </div>
                <label className="switch">
                  <input type="checkbox" defaultChecked />
                  <i />
                </label>
              </div>
            </div>
            <footer>
              <div>
                {tested.external ? (
                  <span className="test-success">
                    <Icon name="check" size={15} />
                    <strong>HEC verified</strong> · Test event indexed in 312 ms
                  </span>
                ) : (
                  <span>
                    Test sends one labeled event and confirms HEC
                    acknowledgement
                  </span>
                )}
              </div>
              <Button
                variant="secondary"
                onClick={() => test("external")}
                disabled={testing === "external"}
              >
                {testing === "external" ? "Testing external…" : "Test HEC"}
              </Button>
              <Button>Save</Button>
            </footer>
          </section>
        </main>
        <aside className="connection-help">
          <div className="panel-kicker">Active delivery</div>
          <h2>
            {routing === "both"
              ? "Mirrored delivery"
              : routing === "docker"
                ? "Docker lab only"
                : "External HEC only"}
          </h2>
          <div className="route-preview">
            <div className="route-source">
              <Icon name="pulse" />
              <strong>Generated event</strong>
            </div>
            <i />
            <div
              className={
                routing === "external" || !dockerEnabled
                  ? "route-destination disabled"
                  : "route-destination"
              }
            >
              <Icon name="server" />
              <span>
                <strong>Docker Splunk</strong>
                <small>{dockerEnabled ? "Enabled" : "Disabled"}</small>
              </span>
            </div>
            <div
              className={
                routing === "docker" || !externalEnabled
                  ? "route-destination disabled"
                  : "route-destination"
              }
            >
              <Icon name="external" />
              <span>
                <strong>External HEC</strong>
                <small>{externalEnabled ? "Enabled" : "Disabled"}</small>
              </span>
            </div>
          </div>
          <div className="delivery-note">
            <Icon name="shield" />
            <p>
              <strong>Independent delivery</strong>A failure at one destination
              does not block delivery to the other. Each result is recorded
              against the run.
            </p>
          </div>
          <div className="help-callout">
            <Icon name="help" />
            <p>
              <strong>External requirements</strong>Provide an HTTPS HEC URL,
              valid token, writable indexes, and network access from the
              NetSpout container.
            </p>
            <button>
              View HEC setup guide <Icon name="arrow" size={14} />
            </button>
          </div>
        </aside>
      </div>
    </div>
  )
}

type Domain = "NETOPS" | "SECOPS" | "ITOPS" | "OBSERVABILITY" | "AGENTIC AI" | "SUPPLY CHAIN"
const domains: { name: Domain; short: string; icon: IconName; state: string }[] = [
  { name: "NETOPS", short: "NetOps", icon: "network", state: "Available" },
  { name: "SECOPS", short: "SecOps", icon: "shield", state: "Available" },
  { name: "ITOPS", short: "ITOps", icon: "server", state: "Available" },
  {
    name: "OBSERVABILITY",
    short: "Observability",
    icon: "pulse",
    state: "Available",
  },
  { name: "AGENTIC AI", short: "Agentic AI", icon: "terminal", state: "Beta" },
  {
    name: "SUPPLY CHAIN",
    short: "Supply Chain",
    icon: "layers",
    state: "Planned",
  },
]

function DomainPill({ domain }: { domain: Domain }) {
  const item = domains.find((candidate) => candidate.name === domain)!
  return (
    <span
      className={`domain-pill domain-${domain.toLowerCase().replaceAll(" ", "-")}`}
    >
      <Icon name={item.icon} size={12} />
      {item.short}
    </span>
  )
}

function DomainSelector({
  value,
  onChange,
  includeAll = true,
}: {
  value: Domain | "ALL"
  onChange: (domain: Domain | "ALL") => void
  includeAll?: boolean
}) {
  return (
    <div className="domain-selector" aria-label="Domain filter">
      {includeAll && (
        <button
          className={value === "ALL" ? "active" : ""}
          onClick={() => onChange("ALL")}
        >
          ALL
        </button>
      )}
      {domains.map((domain) => (
        <button
          className={value === domain.name ? "active" : ""}
          key={domain.name}
          onClick={() => onChange(domain.name)}
        >
          <Icon name={domain.icon} size={14} />
          <span>{domain.short}</span>
          {domain.state !== "Available" && <small>{domain.state}</small>}
        </button>
      ))}
    </div>
  )
}

const evidenceStages = [
  "Generated",
  "Encoded",
  "Sent",
  "Receiver observed",
  "Normalized",
  "Splunk dispatched",
  "Splunk observed",
  "Validated",
]

function EvidencePipeline({
  partial = false,
  compact = false,
}: {
  partial?: boolean
  compact?: boolean
}) {
  return (
    <div
      className={`evidence-pipeline ${
        compact ? "evidence-pipeline--compact" : ""
      }`}
    >
      {evidenceStages.map((stage, index) => {
        const failed = partial && index >= 6
        return (
          <div className={failed ? "failed" : "complete"} key={stage}>
            <span>{failed ? "!" : <Icon name="check" size={12} />}</span>
            <strong>{stage}</strong>
            <small>
              {failed ? (index === 6 ? "82 / 100" : "Failed") : "Complete"}
            </small>
            {index < evidenceStages.length - 1 && <i />}
          </div>
        )
      })}
    </div>
  )
}

type ProvenanceKind = "VENDOR VERIFIED" | "STANDARD VERIFIED" | "SPLUNK VERIFIED" | "DATASET VERIFIED" | "NETSPOUT SCHEMA" | "MODELED VALUE" | "UNSUPPORTED" | "RESEARCH REQUIRED"

function ProvenanceBadge({ kind }: { kind: ProvenanceKind }) {
  return (
    <span
      className={`provenance-badge provenance-${kind.toLowerCase().replaceAll(" ", "-")}`}
    >
      {kind === "UNSUPPORTED" || kind === "RESEARCH REQUIRED" ? (
        "!"
      ) : (
        <Icon name="check" size={10} />
      )}{" "}
      {kind}
    </span>
  )
}

const sourceContracts = {
  windows: {
    title: "Windows Security",
    source: "Microsoft Windows Security Event Log",
    native: "Microsoft event definition · Event 4769",
    splunk: "XmlWinEventLog:Security · CIM Authentication",
    netspout:
      "Vendor-defined event with modeled host, account and service values",
    integration: "Splunk Add-on for Microsoft Windows",
    publisher: "Splunk",
    support: "Splunk Supported",
    events: "4688 · 4769 · 4624 · 4625 · 4104",
    badges: [
      "VENDOR VERIFIED",
      "SPLUNK VERIFIED",
      "MODELED VALUE",
    ] as ProvenanceKind[],
  },
  otel: {
    title: "OpenTelemetry",
    source: "OpenTelemetry logs, metrics and traces",
    native: "OpenTelemetry specification · OTLP/HTTP and OTLP/gRPC",
    splunk: "Splunk OpenTelemetry integration",
    netspout:
      "Standard signal structures with modeled service and timing values",
    integration: "Splunk Distribution of the OpenTelemetry Collector",
    publisher: "Splunk",
    support: "Official Splunk Integration",
    events: "Logs · Metrics · Traces",
    badges: [
      "STANDARD VERIFIED",
      "SPLUNK VERIFIED",
      "MODELED VALUE",
    ] as ProvenanceKind[],
  },
  openconfig: {
    title: "OpenConfig Interface State",
    source: "OpenConfig interfaces YANG model",
    native: "OpenConfig path · gNMI · JSON_IETF",
    splunk: "No specific Technical Add-on asserted",
    netspout:
      "Standard path and encoding with modeled device and interface values",
    integration: "No verified add-on recommendation",
    publisher: "Not applicable",
    support: "Direct ingestion mapping requires configuration",
    events: "Interface operational state",
    badges: ["STANDARD VERIFIED", "MODELED VALUE"] as ProvenanceKind[],
  },
  agentic: {
    title: "Agent Tool Execution",
    source: "NetSpout-defined schema",
    native: "No vendor or open-standard contract claimed",
    splunk: "NetSpout-defined sourcetype · netspout:agentic:audit",
    netspout: "Explicitly modeled AI-agent audit event",
    integration: "No official Splunk integration asserted",
    publisher: "NetSpout",
    support: "NetSpout-defined",
    events: "Agent audit · policy result · tool request",
    badges: ["NETSPOUT SCHEMA", "MODELED VALUE"] as ProvenanceKind[],
  },
}

type ContractKey = keyof typeof sourceContracts

function TelemetryContracts({ source }: { source: ContractKey }) {
  const item = sourceContracts[source]
  return (
    <section className="contract-panel">
      <div className="section-head compact">
        <div>
          <div className="eyebrow">Telemetry detail</div>
          <h2>Three technical contracts</h2>
        </div>
        <div className="provenance-badges">
          {item.badges.map((badge) => (
            <ProvenanceBadge kind={badge} key={badge} />
          ))}
        </div>
      </div>
      <div className="contract-grid">
        <article>
          <span>01 · Native contract</span>
          <strong>What the technology produces</strong>
          <p>{item.native}</p>
          <small>Authority: vendor or open standard</small>
        </article>
        <article>
          <span>02 · Splunk contract</span>
          <strong>How Splunk parses and normalizes</strong>
          <p>{item.splunk}</p>
          <small>Authority: Splunk integration or documentation</small>
        </article>
        <article>
          <span>03 · NetSpout contract</span>
          <strong>What the simulator models</strong>
          <p>{item.netspout}</p>
          <small>Modeled values never redefine the source schema</small>
        </article>
      </div>
    </section>
  )
}

function SplunkIntegrationPanel({ source }: { source: ContractKey }) {
  const item = sourceContracts[source]
  const available = source === "windows" || source === "otel"
  return (
    <section
      className={`integration-panel ${
        available ? "" : "integration-panel--neutral"
      }`}
    >
      <header>
        <div className="integration-mark">
          <Icon name="plug" />
        </div>
        <div>
          <span>Recommended Splunk Integration</span>
          <h2>{item.title}</h2>
        </div>
        {available ? (
          <ProvenanceBadge kind="SPLUNK VERIFIED" />
        ) : (
          <Badge tone="neutral">NO VERIFIED RECOMMENDATION</Badge>
        )}
      </header>
      <div className="integration-name">
        <span>{available ? "Recommended" : "Integration state"}</span>
        <strong>{item.integration}</strong>
      </div>
      <dl>
        <div>
          <dt>Publisher</dt>
          <dd>{item.publisher}</dd>
        </div>
        <div>
          <dt>Support</dt>
          <dd>{item.support}</dd>
        </div>
        <div>
          <dt>Purpose</dt>
          <dd>
            {available
              ? "Collection and Splunk normalization"
              : "No production add-on claim is made"}
          </dd>
        </div>
        <div>
          <dt>Expected telemetry</dt>
          <dd>{item.events}</dd>
        </div>
      </dl>
      <Button variant="secondary" disabled={!available}>
        View integration details
      </Button>
    </section>
  )
}

function GenerationPreflight({ domain }: { domain: Domain }) {
  const source: ContractKey =
    domain === "SECOPS"
      ? "windows"
      : domain === "AGENTIC AI"
        ? "agentic"
        : "openconfig"
  const item = sourceContracts[source]
  const ready = source !== "agentic"
  return (
    <section className="preflight">
      <div className="panel-kicker">Telemetry contract</div>
      <div className="preflight-title">
        <strong>{item.title}</strong>
        <Status tone={ready ? "healthy" : "info"}>
          {ready ? "READY" : "NETSPOUT-DEFINED"}
        </Status>
      </div>
      <div className="provenance-badges">
        {item.badges.map((badge) => (
          <ProvenanceBadge kind={badge} key={badge} />
        ))}
      </div>
      <dl>
        <div>
          <dt>Native schema</dt>
          <dd>{source === "agentic" ? "Not claimed" : "Verified"}</dd>
        </div>
        <div>
          <dt>Splunk mapping</dt>
          <dd>
            {source === "windows"
              ? "Verified"
              : source === "agentic"
                ? "NetSpout-defined"
                : "Configuration required"}
          </dd>
        </div>
        <div>
          <dt>Integration</dt>
          <dd>{item.integration}</dd>
        </div>
        <div>
          <dt>Generator</dt>
          <dd>{ready ? "READY" : "BETA"}</dd>
        </div>
      </dl>
    </section>
  )
}

function SourceVerificationRequired() {
  return (
    <section className="unsupported-experience">
      <span>
        <Icon name="shield" />
      </span>
      <div>
        <div className="eyebrow">Fail closed</div>
        <h2>Source Verification Required</h2>
        <p>
          NetSpout does not currently have sufficient authoritative evidence to
          generate this telemetry accurately.
        </p>
        <dl>
          <div>
            <dt>Vendor</dt>
            <dd>Unsupported</dd>
          </div>
          <div>
            <dt>Requested telemetry</dt>
            <dd>Proprietary fabric ASIC alert</dd>
          </div>
          <div>
            <dt>Missing evidence</dt>
            <dd>Authoritative event schema and Splunk mapping</dd>
          </div>
          <div>
            <dt>Generation state</dt>
            <dd>
              <ProvenanceBadge kind="UNSUPPORTED" />
            </dd>
          </div>
        </dl>
        <div>
          <Button variant="secondary">View provenance</Button>
          <Button>Choose supported source</Button>
        </div>
      </div>
    </section>
  )
}

function ScenarioSourceManifest() {
  const sources: {
    domain: Domain
    name: string
    authority: string
    integration: string
    state: ProvenanceKind
  }[] = [
    {
      domain: "NETOPS",
      name: "OpenConfig interface state",
      authority: "OpenConfig YANG",
      integration: "Direct Splunk mapping · configuration required",
      state: "STANDARD VERIFIED",
    },
    {
      domain: "OBSERVABILITY",
      name: "OpenTelemetry traces",
      authority: "OpenTelemetry specification",
      integration: "Splunk Distribution of the OpenTelemetry Collector",
      state: "SPLUNK VERIFIED",
    },
    {
      domain: "SECOPS",
      name: "Microsoft Windows Security 4769",
      authority: "Microsoft documentation",
      integration: "Splunk Add-on for Microsoft Windows",
      state: "VENDOR VERIFIED",
    },
    {
      domain: "ITOPS",
      name: "Host metrics",
      authority: "Source contract not selected",
      integration: "Integration not selected",
      state: "RESEARCH REQUIRED",
    },
  ]
  return (
    <section className="source-manifest">
      <div className="manifest-head">
        <div>
          <div className="eyebrow">Scenario source manifest</div>
          <h2>Infrastructure Smoke Screen</h2>
        </div>
        <div className="fidelity-summary">
          <strong>3 verified</strong>
          <span>1 research required · 0 unsupported</span>
          <Badge tone="amber">EXPERIMENTAL</Badge>
        </div>
      </div>
      <div className="manifest-table">
        <div className="manifest-row manifest-labels">
          <span>Domain</span>
          <span>Telemetry source</span>
          <span>Authority</span>
          <span>Splunk integration</span>
          <span>State</span>
        </div>
        {sources.map((source) => (
          <div className="manifest-row" key={source.domain}>
            <DomainPill domain={source.domain} />
            <strong>{source.name}</strong>
            <span>{source.authority}</span>
            <span>{source.integration}</span>
            <ProvenanceBadge kind={source.state} />
          </div>
        ))}
      </div>
      <div className="manifest-note">
        <Icon name="shield" />
        <span>
          <strong>Experimental scenario</strong>The unverified ITOps source is
          excluded from production-quality generation until its telemetry
          contract is selected and verified.
        </span>
      </div>
    </section>
  )
}

function TrustedTelemetryCatalog({ advanced }: { advanced: boolean }) {
  const [source, setSource] = useState<ContractKey>("windows")
  const entries: {
    key: ContractKey
    domain: Domain
    title: string
    product: string
    state: string
  }[] = [
    {
      key: "windows",
      domain: "SECOPS",
      title: "Windows Security Event Log",
      product: "Microsoft Windows",
      state: "VERIFIED",
    },
    {
      key: "otel",
      domain: "OBSERVABILITY",
      title: "OpenTelemetry Signals",
      product: "OpenTelemetry",
      state: "VERIFIED",
    },
    {
      key: "openconfig",
      domain: "NETOPS",
      title: "OpenConfig Interface State",
      product: "OpenConfig",
      state: "VERIFIED",
    },
    {
      key: "agentic",
      domain: "AGENTIC AI",
      title: "Agent Tool Execution",
      product: "NetSpout",
      state: "PARTIALLY VERIFIED",
    },
  ]
  const item = sourceContracts[source]
  return (
    <div className="page">
      <header className="page-header">
        <div>
          <div className="eyebrow">Telemetry catalog</div>
          <h1>Technical Contract Explorer</h1>
          <p>
            The environment is simulated. The telemetry contract is not
            invented.
          </p>
        </div>
        <div className="trust-promise">
          <Icon name="shield" />
          <span>
            <strong>Fail-closed generation</strong>Unsupported contracts are
            never approximated.
          </span>
        </div>
      </header>
      <div className="catalog-layout">
        <aside className="catalog-index">
          <div className="search-field">
            <Icon name="search" />
            <input
              aria-label="Search telemetry contracts"
              placeholder="Search sources, events, schemas..."
            />
          </div>
          {entries.map((entry) => (
            <button
              className={source === entry.key ? "active" : ""}
              onClick={() => setSource(entry.key)}
              key={entry.key}
            >
              <DomainPill domain={entry.domain} />
              <span>
                <strong>{entry.title}</strong>
                <small>{entry.product}</small>
              </span>
              <Status tone={entry.state === "VERIFIED" ? "healthy" : "warning"}>
                {entry.state}
              </Status>
            </button>
          ))}
          <button onClick={() => undefined}>
            <ProvenanceBadge kind="UNSUPPORTED" />
            <span>
              <strong>Proprietary Fabric ASIC Alert</strong>
              <small>Insufficient evidence</small>
            </span>
          </button>
        </aside>
        <main className="catalog-detail">
          <div className="catalog-detail-head">
            <div>
              <div className="provenance-badges">
                {item.badges.map((badge) => (
                  <ProvenanceBadge kind={badge} key={badge} />
                ))}
              </div>
              <h1>{item.title}</h1>
              <p>{item.source}</p>
            </div>
            <Status tone={source === "agentic" ? "warning" : "healthy"}>
              {source === "agentic" ? "PARTIALLY VERIFIED" : "VERIFIED"}
            </Status>
          </div>
          <div className="catalog-fields">
            {source === "windows"
              ? [
                  ["Domain", "SecOps"],
                  ["Vendor", "Microsoft"],
                  ["Product", "Windows"],
                  ["Telemetry source", "Security Event Log"],
                  ["Event", "4769 — Kerberos service ticket requested"],
                  ["Transport", "Windows Event Log"],
                  ["Sourcetype", "XmlWinEventLog:Security"],
                  ["CIM mapping", "Authentication"],
                  ["Provenance", "Microsoft documentation"],
                  ["Fidelity", "Vendor-documented / modeled values"],
                ]
              : source === "otel"
                ? [
                    ["Domain", "Observability"],
                    ["Standard", "OpenTelemetry"],
                    ["Signals", "Logs · Metrics · Traces"],
                    ["Protocols", "OTLP/HTTP · OTLP/gRPC"],
                    ["Component", "OTel Collector"],
                    ["Provenance", "OpenTelemetry specification"],
                    ["Fidelity", "Standard-documented / modeled values"],
                  ]
                : source === "openconfig"
                  ? [
                      ["Domain", "NetOps"],
                      ["Standard", "OpenConfig"],
                      ["Model", "interfaces"],
                      ["Transport", "gNMI"],
                      ["Encoding", "JSON_IETF"],
                      ["Path", "/interfaces/interface/state/oper-status"],
                      ["Provenance", "OpenConfig YANG"],
                      ["Fidelity", "Standard-documented / modeled values"],
                    ]
                  : [
                      ["Domain", "Agentic AI"],
                      ["Publisher", "NetSpout"],
                      ["Schema", "NetSpout-defined"],
                      ["Sourcetype", "netspout:agentic:audit"],
                      ["Transport", "JSON / HEC"],
                      ["Native vendor claim", "None"],
                      ["Fidelity", "NetSpout schema / modeled event"],
                    ].map(([label, value]) => (
                      <div key={label}>
                        <span>{label}</span>
                        <code>{value}</code>
                      </div>
                    ))}
          </div>
          {advanced ? (
            <TelemetryContracts source={source} />
          ) : (
            <div className="simple-trust">
              <ProvenanceBadge
                kind={
                  source === "agentic"
                    ? "NETSPOUT SCHEMA"
                    : source === "windows"
                      ? "VENDOR VERIFIED"
                      : "STANDARD VERIFIED"
                }
              />
              <span>
                {source === "agentic"
                  ? "NetSpout-defined contract; no vendor standard is claimed."
                  : "Telemetry definition verified against an authoritative source."}
              </span>
            </div>
          )}
          <SplunkIntegrationPanel source={source} />
        </main>
      </div>
      <SourceVerificationRequired />
    </div>
  )
}

function SplunkIntegrationsCatalog() {
  const entries = [
    {
      name: "Splunk Add-on for Microsoft Windows",
      publisher: "Splunk",
      source: "Microsoft Windows Event Log",
      sourcetype: "XmlWinEventLog:Security",
      cim: "Authentication · Endpoint · Change",
      coverage: "Windows generator",
      support: "SPLUNK SUPPORTED",
      type: "SECURITY · WINDOWS",
    },
    {
      name: "Splunk Distribution of the OpenTelemetry Collector",
      publisher: "Splunk",
      source: "OpenTelemetry",
      sourcetype: "Signal pipeline",
      cim: "Logs · Metrics · Traces",
      coverage: "OTel generator",
      support: "OFFICIAL SPLUNK INTEGRATION",
      type: "OBSERVABILITY",
    },
    {
      name: "Splunk Add-on for OpenTelemetry Collector",
      publisher: "Splunk",
      source: "OTel Collector operational data",
      sourcetype: "See integration documentation",
      cim: "Collector monitoring",
      coverage: "Pipeline evidence",
      support: "OFFICIAL SPLUNK INTEGRATION",
      type: "OBSERVABILITY",
    },
  ]
  const [selected, setSelected] = useState(0)
  return (
    <div className="page">
      <header className="page-header">
        <div>
          <div className="eyebrow">Official integration guidance</div>
          <h1>Splunk Integrations</h1>
          <p>
            Recommendations describe what a production Splunk environment
            normally uses. NetSpout remains self-contained for supported
            generation workflows.
          </p>
        </div>
        <ProvenanceBadge kind="SPLUNK VERIFIED" />
      </header>
      <div className="integration-filters">
        {[
          "ALL",
          "SECURITY",
          "NETWORK",
          "CLOUD",
          "WINDOWS",
          "LINUX",
          "OBSERVABILITY",
          "APPLICATION",
          "CONTAINER",
          "IDENTITY",
        ].map((filter, index) => (
          <button className={index === 0 ? "active" : ""} key={filter}>
            {filter}
          </button>
        ))}
      </div>
      <div className="integrations-layout">
        <main className="table-frame">
          <table>
            <thead>
              <tr>
                <th>Integration</th>
                <th>Publisher</th>
                <th>Supported source</th>
                <th>Sourcetype / signals</th>
                <th>CIM / coverage</th>
                <th>NetSpout</th>
                <th>Support</th>
              </tr>
            </thead>
            <tbody>
              {entries.map((entry, index) => (
                <tr
                  className={selected === index ? "selected-row" : ""}
                  onClick={() => setSelected(index)}
                  key={entry.name}
                >
                  <td>
                    <strong>{entry.name}</strong>
                    <small className="source-caption">{entry.type}</small>
                  </td>
                  <td>{entry.publisher}</td>
                  <td>{entry.source}</td>
                  <td>
                    <code>{entry.sourcetype}</code>
                  </td>
                  <td>{entry.cim}</td>
                  <td>{entry.coverage}</td>
                  <td>
                    <Status>{entry.support}</Status>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </main>
        <aside>
          <SplunkIntegrationPanel
            source={selected === 0 ? "windows" : "otel"}
          />
          <div className="integration-caveat">
            <Icon name="shield" />
            <p>
              <strong>
                Integration evidence is not native-schema evidence.
              </strong>
              A Splunk Technical Add-on describes Splunk parsing and
              normalization. The original telemetry structure remains grounded
              in the vendor or standard definition.
            </p>
          </div>
        </aside>
      </div>
    </div>
  )
}

function SecurityIntelligence() {
  const [tab, setTab] = useState("OVERVIEW")
  return (
    <div className="page">
      <header className="page-header">
        <div>
          <div className="eyebrow">Security scenario intelligence</div>
          <h1>Kerberoasting</h1>
          <p>
            A deterministic credential-access simulation with separately sourced
            attack intelligence, telemetry contracts, detection behavior and
            Splunk mappings.
          </p>
          <div className="domain-cell">
            <DomainPill domain="SECOPS" />
            <Badge tone="amber">CREDENTIAL ACCESS</Badge>
            <Badge tone="blue">MITRE T1558.003</Badge>
            <ProvenanceBadge kind="VENDOR VERIFIED" />
          </div>
        </div>
        <Button icon="play">Run verified scenario</Button>
      </header>
      <div className="security-tabs">
        {[
          "OVERVIEW",
          "ATTACK FLOW",
          "TELEMETRY",
          "DETECTIONS",
          "MITRE",
          "ARTIFACTS",
          "PROVENANCE",
          "SPLUNK",
        ].map((item) => (
          <button
            className={tab === item ? "active" : ""}
            onClick={() => setTab(item)}
            key={item}
          >
            {item}
          </button>
        ))}
      </div>
      {tab === "OVERVIEW" ? (
        <>
          <section className="security-layer-model">
            <div>
              <span>01 · Attack behavior</span>
              <strong>Kerberoasting</strong>
              <p>MITRE ATT&CK · T1558.003</p>
            </div>
            <Icon name="arrow" />
            <div>
              <span>02 · Telemetry</span>
              <strong>Windows Security 4769</strong>
              <p>Microsoft-defined event contract</p>
            </div>
            <Icon name="arrow" />
            <div>
              <span>03 · Detection behavior</span>
              <strong>Splunk Security Content · Sigma</strong>
              <p>Coverage mapping requires catalog validation</p>
            </div>
            <Icon name="arrow" />
            <div>
              <span>04 · Artifact detection</span>
              <strong>Not applicable</strong>
              <p>YARA is not a log schema</p>
            </div>
          </section>
          <div className="security-overview-grid">
            <section className="signature-section">
              <div className="eyebrow">Security source manifest</div>
              <h2>Trust layers</h2>
              <div className="security-manifest">
                {[
                  [
                    "Attack intelligence",
                    "MITRE ATT&CK T1558.003",
                    "STANDARD VERIFIED",
                  ],
                  [
                    "Telemetry contract",
                    "Microsoft Windows Security 4769",
                    "VENDOR VERIFIED",
                  ],
                  [
                    "Splunk normalization",
                    "Splunk Add-on for Microsoft Windows",
                    "SPLUNK VERIFIED",
                  ],
                  [
                    "Detection intelligence",
                    "Splunk Security Content · Sigma",
                    "RESEARCH REQUIRED",
                  ],
                  [
                    "Artifact intelligence",
                    "YARA · Not applicable",
                    "STANDARD VERIFIED",
                  ],
                ].map(([layer, source, state]) => (
                  <div key={layer}>
                    <span>{layer}</span>
                    <strong>{source}</strong>
                    <ProvenanceBadge kind={state as ProvenanceKind} />
                  </div>
                ))}
              </div>
            </section>
            <SplunkIntegrationPanel source="windows" />
          </div>
        </>
      ) : tab === "DETECTIONS" ? (
        <section className="detection-separation">
          <header>
            <div className="eyebrow">Detection coverage</div>
            <h2>Sources are not interchangeable</h2>
          </header>
          {[
            [
              "Splunk Security Content",
              "Detection and investigation behavior",
              "Catalog validation required",
            ],
            [
              "Sigma",
              "Vendor-agnostic detection behavior",
              "Manual field-model review required",
            ],
            [
              "YARA",
              "File and content artifact matching",
              "Not applicable to this scenario",
            ],
            [
              "Native product detection",
              "Vendor security-product alert",
              "Not used",
            ],
          ].map(([name, role, state]) => (
            <article key={name}>
              <Icon name={name === "YARA" ? "search" : "shield"} />
              <div>
                <strong>{name}</strong>
                <p>{role}</p>
              </div>
              <Badge tone={state.includes("Not") ? "neutral" : "amber"}>
                {state}
              </Badge>
            </article>
          ))}
        </section>
      ) : tab === "TELEMETRY" || tab === "PROVENANCE" ? (
        <>
          <TelemetryContracts source="windows" />
          <SplunkIntegrationPanel source="windows" />
        </>
      ) : (
        <section className="focused-tab">
          <div>
            <Icon name={tab === "ARTIFACTS" ? "search" : "shield"} />
            <h2>{tab[0] + tab.slice(1).toLowerCase()}</h2>
            <p>
              This prototype view preserves the distinction between behavior
              intelligence, telemetry definition, Splunk normalization,
              detection logic and artifact evidence.
            </p>
          </div>
        </section>
      )}
      <section className="coverage-matrix">
        <div className="section-head compact">
          <div>
            <div className="eyebrow">Security coverage matrix</div>
            <h2>Catalog-backed states only</h2>
          </div>
          <span>No fictitious rule counts</span>
        </div>
        <div className="table-frame">
          <table>
            <thead>
              <tr>
                <th>Scenario</th>
                <th>MITRE</th>
                <th>Required data</th>
                <th>Splunk detection</th>
                <th>Sigma</th>
                <th>YARA</th>
                <th>NetSpout</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>
                  <strong>Kerberoasting</strong>
                </td>
                <td>
                  <code>T1558.003</code>
                </td>
                <td>Windows Security</td>
                <td>
                  <Status tone="warning">RESEARCH REQUIRED</Status>
                </td>
                <td>
                  <Status tone="warning">RESEARCH REQUIRED</Status>
                </td>
                <td>N/A</td>
                <td>
                  <Status>Telemetry ready</Status>
                </td>
              </tr>
              <tr>
                <td>
                  <strong>Malicious document</strong>
                </td>
                <td>Illustrative</td>
                <td>Email · Host · Network</td>
                <td>
                  <Status tone="warning">RESEARCH REQUIRED</Status>
                </td>
                <td>
                  <Status tone="warning">RESEARCH REQUIRED</Status>
                </td>
                <td>
                  <Status tone="warning">RESEARCH REQUIRED</Status>
                </td>
                <td>
                  <Badge tone="neutral">PLANNED</Badge>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </section>
    </div>
  )
}

function ScenarioTrustView({ navigate }: { navigate: (page: Page) => void }) {
  return (
    <>
      <MultiDomainScenario navigate={navigate} />
      <div className="trust-extension">
        <ScenarioSourceManifest />
      </div>
    </>
  )
}

function ScenarioFidelity({
  telemetry,
  verified,
  splunk,
  detection,
  research,
  unsupported,
  overall,
}: {
  telemetry: number
  verified: number
  splunk: number
  detection: number | "N/A"
  research: number
  unsupported: number
  overall: "VERIFIED" | "PARTIALLY VERIFIED" | "PLANNED"
}) {
  return (
    <section className="fidelity-scorecard">
      <div className="fidelity-title">
        <div>
          <div className="eyebrow">Scenario fidelity</div>
          <h2>Evidence-based readiness</h2>
        </div>
        <Badge
          tone={
            overall === "VERIFIED"
              ? "green"
              : overall === "PLANNED"
                ? "neutral"
                : "amber"
          }
        >
          {overall}
        </Badge>
      </div>
      <div className="fidelity-counts">
        {[
          ["Telemetry sources", telemetry],
          ["Vendor / standard verified", verified],
          ["Splunk mappings verified", splunk],
          ["Detection mappings verified", detection],
          ["Research required", research],
          ["Unsupported", unsupported],
        ].map(([label, value]) => (
          <div key={label}>
            <span>{label}</span>
            <strong>{value}</strong>
          </div>
        ))}
      </div>
      <small>
        Counts reflect this prototype source manifest. No percentage is
        inferred.
      </small>
    </section>
  )
}

const refinedScenarios: {
  name: string
  domain: Domain
  category: string
  description: string
  telemetry: string
  crossDomain: string
  maturity: string
  fidelity: string
  page: Page
}[] = [
  {
    name: "Kerberoasting",
    domain: "SECOPS",
    category: "Credential Access · T1558.003",
    description:
      "Simulate service-ticket activity and inspect the legitimate Windows telemetry contract separately from detection intelligence.",
    telemetry: "Windows Security",
    crossDomain: "Identity · Detection",
    maturity: "BETA",
    fidelity: "PARTIALLY VERIFIED",
    page: "security",
  },
  {
    name: "Malicious Document",
    domain: "SECOPS",
    category: "Phishing · Artifact",
    description:
      "Planned correlation of attachment evidence, process execution, network activity and artifact inspection.",
    telemetry: "Email · Host · Network",
    crossDomain: "YARA relevant",
    maturity: "PLANNED",
    fidelity: "RESEARCH REQUIRED",
    page: "security",
  },
  {
    name: "Web Shell",
    domain: "SECOPS",
    category: "Web Exploitation",
    description: "Planned web, host, network and artifact evidence sequence.",
    telemetry: "Web · Host · Network",
    crossDomain: "YARA relevant",
    maturity: "PLANNED",
    fidelity: "RESEARCH REQUIRED",
    page: "security",
  },
  {
    name: "Progressive Memory Leak",
    domain: "ITOPS",
    category: "Resource Pressure",
    description:
      "Memory rises over time, creating GC pressure, service latency, HTTP failures and a controlled restart.",
    telemetry: "OpenTelemetry metrics · traces",
    crossDomain: "Observability",
    maturity: "BETA",
    fidelity: "PARTIALLY VERIFIED",
    page: "itops",
  },
  {
    name: "CPU Saturation",
    domain: "ITOPS",
    category: "Compute",
    description:
      "Planned simulation of sustained compute pressure and service KPI degradation.",
    telemetry: "Source contract not selected",
    crossDomain: "Observability",
    maturity: "PLANNED",
    fidelity: "RESEARCH REQUIRED",
    page: "itops",
  },
  {
    name: "Database Connection Exhaustion",
    domain: "ITOPS",
    category: "Database",
    description:
      "Planned connection-pool pressure and downstream application impact.",
    telemetry: "Source contract not selected",
    crossDomain: "Observability",
    maturity: "PLANNED",
    fidelity: "RESEARCH REQUIRED",
    page: "itops",
  },
  {
    name: "Dependency Confusion",
    domain: "SUPPLY CHAIN",
    category: "Dependency · Build",
    description:
      "Conceptual repository-to-runtime flow for an unexpected dependency, modified artifact and downstream security activity.",
    telemetry: "Contracts require platform selection",
    crossDomain: "SecOps · Observability",
    maturity: "PLANNED",
    fidelity: "RESEARCH REQUIRED",
    page: "supply-chain",
  },
  {
    name: "Compromised CI Runner",
    domain: "SUPPLY CHAIN",
    category: "Runner · Credential",
    description:
      "Conceptual build-runner compromise and artifact modification flow.",
    telemetry: "Contracts require platform selection",
    crossDomain: "SecOps · Network",
    maturity: "PLANNED",
    fidelity: "RESEARCH REQUIRED",
    page: "supply-chain",
  },
  {
    name: "Artifact Tampering",
    domain: "SUPPLY CHAIN",
    category: "Artifact · Deployment",
    description:
      "Conceptual artifact integrity and unauthorized deployment scenario.",
    telemetry: "Contracts require platform selection",
    crossDomain: "Runtime · SecOps",
    maturity: "PLANNED",
    fidelity: "RESEARCH REQUIRED",
    page: "supply-chain",
  },
  {
    name: "Infrastructure Smoke Screen",
    domain: "NETOPS",
    category: "Cross-Domain",
    description:
      "Routing instability, application impact and concurrent security activity.",
    telemetry: "OpenConfig · OpenTelemetry · Windows",
    crossDomain: "ITOps · Obs · SecOps",
    maturity: "BETA",
    fidelity: "PARTIALLY VERIFIED",
    page: "scenario",
  },
  {
    name: "Agentic AI Cascading Failure",
    domain: "AGENTIC AI",
    category: "Agent Tool Activity",
    description:
      "Poisoned context, MCP activity, database pressure and application impact.",
    telemetry: "NetSpout-defined schema",
    crossDomain: "ITOps · Obs · SecOps",
    maturity: "BETA",
    fidelity: "PARTIALLY VERIFIED",
    page: "agentic",
  },
]

function RefinedScenarioLibrary({
  navigate,
}: {
  navigate: (page: Page) => void
}) {
  const [domain, setDomain] = useState<Domain | "ALL">("ALL")
  const [query, setQuery] = useState("")
  const [filter, setFilter] = useState("ALL")
  const visible = refinedScenarios.filter(
    (scenario) =>
      (domain === "ALL" || scenario.domain === domain) &&
      scenario.name.toLowerCase().includes(query.toLowerCase()) &&
      (filter === "ALL" || scenario.category.toUpperCase().includes(filter)),
  )
  const filters =
    domain === "SECOPS"
      ? [
          "ALL",
          "CREDENTIAL ACCESS",
          "EXECUTION",
          "PHISHING",
          "WEB EXPLOITATION",
          "RESEARCH REQUIRED",
        ]
      : domain === "ITOPS"
        ? [
            "ALL",
            "RESOURCE PRESSURE",
            "COMPUTE",
            "DATABASE",
            "SERVICE",
            "PLANNED",
          ]
        : domain === "SUPPLY CHAIN"
          ? ["ALL", "DEPENDENCY", "RUNNER", "ARTIFACT", "DEPLOYMENT", "PLANNED"]
          : ["ALL", "CROSS-DOMAIN", "AVAILABLE", "BETA", "PLANNED"]
  return (
    <div className="page">
      <header className="page-header">
        <div>
          <div className="eyebrow">Scenario library · v2.1 refinement</div>
          <h1>Enterprise Scenarios</h1>
          <p>
            Security, infrastructure and software delivery remain perspectives
            on one simulated enterprise state.
          </p>
        </div>
        <Button
          onClick={() => navigate("builder")}
          variant="secondary"
          icon="settings"
        >
          Build scenario
        </Button>
      </header>
      <DomainSelector
        value={domain}
        onChange={(value) => {
          setDomain(value)
          setFilter("ALL")
        }}
      />
      <div className="library-tools">
        <div className="search-field">
          <Icon name="search" />
          <input
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder="Search scenarios..."
            aria-label="Search scenarios"
          />
        </div>
        <Button variant="secondary" icon="filter">
          {domain === "SECOPS"
            ? "Tactic · Threat · Telemetry · Intelligence"
            : domain === "ITOPS"
              ? "Resource · Entity · Telemetry · Status"
              : domain === "SUPPLY CHAIN"
                ? "Stage · Entity · Platform · Status"
                : "Domain · Maturity · Fidelity"}
        </Button>
      </div>
      <div className="filter-row">
        {filters.map((item) => (
          <button
            className={filter === item ? "active" : ""}
            onClick={() => setFilter(item)}
            key={item}
          >
            {item}
          </button>
        ))}
      </div>
      <div className="results-meta">
        <strong>{visible.length} scenarios</strong>
        <span>Runtime maturity is distinct from design availability</span>
      </div>
      <div className="refined-scenario-list">
        {visible.map((scenario) => (
          <article key={scenario.name}>
            <div className="refined-card-main">
              <div className="scenario-symbol">
                <Icon
                  name={
                    scenario.domain === "SECOPS"
                      ? "shield"
                      : scenario.domain === "ITOPS"
                        ? "server"
                        : scenario.domain === "SUPPLY CHAIN"
                          ? "layers"
                          : scenario.domain === "AGENTIC AI"
                            ? "terminal"
                            : "network"
                  }
                />
              </div>
              <div>
                <div className="card-kicker">
                  <DomainPill domain={scenario.domain} />
                  <Badge
                    tone={
                      scenario.maturity === "AVAILABLE"
                        ? "green"
                        : scenario.maturity === "BETA"
                          ? "amber"
                          : "neutral"
                    }
                  >
                    {scenario.maturity}
                  </Badge>
                </div>
                <h2>{scenario.name}</h2>
                <p>{scenario.description}</p>
                <div className="card-facts">
                  <div>
                    <span>
                      {scenario.domain === "SECOPS"
                        ? "ATT&CK / category"
                        : "Behavior"}
                    </span>
                    <strong>{scenario.category}</strong>
                  </div>
                  <div>
                    <span>Required telemetry</span>
                    <strong>{scenario.telemetry}</strong>
                  </div>
                  <div>
                    <span>Cross-domain</span>
                    <strong>{scenario.crossDomain}</strong>
                  </div>
                  <div>
                    <span>Fidelity</span>
                    <strong
                      className={
                        scenario.fidelity === "RESEARCH REQUIRED"
                          ? "warning-text"
                          : ""
                      }
                    >
                      {scenario.fidelity}
                    </strong>
                  </div>
                </div>
              </div>
            </div>
            <div className="refined-card-actions">
              {scenario.domain === "SECOPS" && (
                <div>
                  <span>Detection intelligence</span>
                  <strong>Splunk Content · Sigma · YARA relevance</strong>
                </div>
              )}
              <Button
                variant="secondary"
                onClick={() => navigate(scenario.page)}
              >
                View scenario
              </Button>
              <Button disabled={scenario.maturity === "PLANNED"} icon="play">
                Run
              </Button>
            </div>
          </article>
        ))}
      </div>
    </div>
  )
}

function SplunkSecurityContentPanel() {
  return (
    <section className="intelligence-panel splunk-content-panel">
      <header>
        <span>
          <Icon name="database" />
        </span>
        <div>
          <div className="eyebrow">Splunk Security Content</div>
          <h2>Analytic Story mapping</h2>
        </div>
        <ProvenanceBadge kind="RESEARCH REQUIRED" />
      </header>
      <dl>
        <div>
          <dt>Analytic Story</dt>
          <dd>Not yet verified in the NetSpout catalog</dd>
        </div>
        <div>
          <dt>ATT&CK</dt>
          <dd>
            <code>T1558.003</code>
          </dd>
        </div>
        <div>
          <dt>Required data</dt>
          <dd>Windows Security</dd>
        </div>
        <div>
          <dt>Relevant detections</dt>
          <dd>Catalog research required</dd>
        </div>
        <div>
          <dt>Investigation searches</dt>
          <dd>Catalog research required</dd>
        </div>
        <div>
          <dt>Source</dt>
          <dd>Splunk Security Research · reference slot</dd>
        </div>
      </dl>
      <Button variant="secondary">View source details</Button>
    </section>
  )
}

function SigmaCoveragePanel() {
  return (
    <section className="intelligence-panel sigma-panel">
      <header>
        <span>
          <Icon name="search" />
        </span>
        <div>
          <div className="eyebrow">Sigma detection coverage</div>
          <h2>Behavior mapping</h2>
        </div>
        <ProvenanceBadge kind="RESEARCH REQUIRED" />
      </header>
      <dl>
        <div>
          <dt>Rule title</dt>
          <dd>Not asserted</dd>
        </div>
        <div>
          <dt>Rule ID</dt>
          <dd>Not asserted</dd>
        </div>
        <div>
          <dt>Rule type</dt>
          <dd>Generic detection / hunting · pending review</dd>
        </div>
        <div>
          <dt>Log source</dt>
          <dd>Windows Security · mapping review required</dd>
        </div>
        <div>
          <dt>ATT&CK mapping</dt>
          <dd>
            <code>T1558.003</code>
          </dd>
        </div>
        <div>
          <dt>SPL conversion</dt>
          <dd>Manual review required</dd>
        </div>
      </dl>
      <p>
        Sigma informs expected observable behavior; it does not define the
        Microsoft event schema and is not assumed to convert perfectly into SPL.
      </p>
    </section>
  )
}

function YaraCoveragePanel({ relevant = false }: { relevant?: boolean }) {
  return (
    <section className="intelligence-panel yara-panel">
      <header>
        <span>
          <Icon name="search" />
        </span>
        <div>
          <div className="eyebrow">YARA artifact coverage</div>
          <h2>{relevant ? "Artifact mapping" : "Not applicable"}</h2>
        </div>
        {relevant ? (
          <ProvenanceBadge kind="RESEARCH REQUIRED" />
        ) : (
          <Badge tone="neutral">N/A</Badge>
        )}
      </header>
      {relevant ? (
        <dl>
          <div>
            <dt>Rule</dt>
            <dd>Not asserted</dd>
          </div>
          <div>
            <dt>Category</dt>
            <dd>Malicious document</dd>
          </div>
          <div>
            <dt>Artifact type</dt>
            <dd>File / document</dd>
          </div>
          <div>
            <dt>Coverage</dt>
            <dd>Research required</dd>
          </div>
        </dl>
      ) : (
        <div className="na-state">
          <strong>No file or artifact component</strong>
          <p>
            Kerberoasting is represented through identity behavior and Windows
            telemetry. YARA is not used as a generic SIEM-log detector.
          </p>
        </div>
      )}
    </section>
  )
}

function SecurityScenarioDetail({
  navigate,
}: {
  navigate: (page: Page) => void
}) {
  const [tab, setTab] = useState("OVERVIEW")
  const attackStages = [
    ["DISCOVERY", "Service discovery", "Affected entity · domain identity"],
    ["CREDENTIAL ACCESS", "T1558.003", "Windows Security evidence required"],
    ["OBSERVATION", "Event 4769", "Microsoft-defined telemetry contract"],
    ["DETECTION", "Coverage review", "Splunk Content and Sigma separated"],
    ["INVESTIGATION", "Splunk evidence", "Correlated run and source manifest"],
  ]
  return (
    <div className="page">
      <header className="detail-header">
        <div>
          <div className="domain-cell">
            <DomainPill domain="SECOPS" />
            <Badge tone="amber">CREDENTIAL ACCESS</Badge>
            <Badge tone="blue">MITRE T1558.003</Badge>
          </div>
          <h1>Kerberoasting</h1>
          <p>
            Simulate credential-access behavior and validate the required
            telemetry without conflating the attack, event contract, detection
            logic or artifact evidence.
          </p>
        </div>
        <div className="detail-actions">
          <Badge tone="amber">PARTIALLY VERIFIED</Badge>
          <Button icon="play" onClick={() => navigate("security-run")}>
            Run verified telemetry
          </Button>
        </div>
      </header>
      <div className="security-tabs">
        {[
          "OVERVIEW",
          "ATTACK FLOW",
          "TELEMETRY",
          "DETECTIONS",
          "MITRE",
          "ARTIFACTS",
          "PROVENANCE",
          "SPLUNK",
        ].map((item) => (
          <button
            className={tab === item ? "active" : ""}
            onClick={() => setTab(item)}
            key={item}
          >
            {item}
          </button>
        ))}
      </div>
      {tab === "ATTACK FLOW" ? (
        <section className="attack-flow-v21">
          {attackStages.map(([stage, title, detail], index) => (
            <button key={stage}>
              <span>
                {String(index + 1).padStart(2, "0")} · {stage}
              </span>
              <strong>{title}</strong>
              <small>{detail}</small>
              {index < attackStages.length - 1 && <Icon name="arrow" />}
            </button>
          ))}
        </section>
      ) : tab === "DETECTIONS" ? (
        <div className="intelligence-grid">
          <SplunkSecurityContentPanel />
          <SigmaCoveragePanel />
          <YaraCoveragePanel />
        </div>
      ) : tab === "TELEMETRY" || tab === "PROVENANCE" ? (
        <>
          <TelemetryContracts source="windows" />
          <SplunkIntegrationPanel source="windows" />
        </>
      ) : tab === "ARTIFACTS" ? (
        <YaraCoveragePanel />
      ) : (
        <>
          <section className="security-layer-model">
            <div>
              <span>Attack behavior</span>
              <strong>Kerberoasting</strong>
              <p>MITRE ATT&CK T1558.003</p>
            </div>
            <Icon name="arrow" />
            <div>
              <span>Telemetry</span>
              <strong>Microsoft Windows Security 4769</strong>
              <p>Vendor-defined event contract</p>
            </div>
            <Icon name="arrow" />
            <div>
              <span>Detection</span>
              <strong>Splunk Content · Sigma</strong>
              <p>Mappings remain research required</p>
            </div>
            <Icon name="arrow" />
            <div>
              <span>Artifact detection</span>
              <strong>YARA · N/A</strong>
              <p>No file component</p>
            </div>
          </section>
          <div className="security-detail-grid">
            <ScenarioFidelity
              telemetry={1}
              verified={1}
              splunk={1}
              detection={0}
              research={2}
              unsupported={0}
              overall="PARTIALLY VERIFIED"
            />
            <SplunkIntegrationPanel source="windows" />
          </div>
          <section className="security-manifest-v21">
            <div className="section-head compact">
              <div>
                <div className="eyebrow">Scenario source manifest</div>
                <h2>Separate intelligence and contract layers</h2>
              </div>
            </div>
            {[
              [
                "Attack intelligence",
                "MITRE ATT&CK T1558.003",
                "STANDARD VERIFIED",
              ],
              [
                "Detection intelligence",
                "Splunk Security Content · Sigma",
                "RESEARCH REQUIRED",
              ],
              [
                "Artifact intelligence",
                "YARA · Not applicable",
                "STANDARD VERIFIED",
              ],
              [
                "Telemetry source",
                "Microsoft Windows Security 4769",
                "VENDOR VERIFIED",
              ],
              [
                "Splunk integration",
                "Splunk Add-on for Microsoft Windows",
                "SPLUNK VERIFIED",
              ],
            ].map(([type, source, state]) => (
              <div key={type}>
                <span>{type}</span>
                <strong>{source}</strong>
                <ProvenanceBadge kind={state as ProvenanceKind} />
              </div>
            ))}
          </section>
        </>
      )}
    </div>
  )
}

function SecurityLiveRun({ navigate }: { navigate: (page: Page) => void }) {
  const events = [
    [
      "14:31:10",
      "ATTACK",
      "Domain identity",
      "Service-ticket activity begins",
      "MODELED BEHAVIOR",
    ],
    [
      "14:31:12",
      "TELEMETRY",
      "DC-01",
      "Windows Security 4769 generated",
      "VENDOR CONTRACT",
    ],
    [
      "14:31:14",
      "SPLUNK",
      "netspout_events",
      "Event observed in Splunk",
      "SPLUNK OBSERVED",
    ],
    [
      "14:31:17",
      "DETECTION",
      "Coverage layer",
      "Applicable detection mapping requires research",
      "NOT FIRED",
    ],
  ]
  return (
    <div className="page">
      <header className="page-header">
        <div>
          <div className="domain-cell">
            <DomainPill domain="SECOPS" />
            <Badge tone="amber">PARTIALLY VERIFIED</Badge>
          </div>
          <h1>Kerberoasting · Live Run</h1>
          <p>
            Attack state, telemetry generation, Splunk observation and detection
            evidence are tracked as separate claims.
          </p>
        </div>
        <div className="run-actions">
          <Button variant="secondary">Pause</Button>
          <Button variant="danger">Stop run</Button>
        </div>
      </header>
      <div className="security-run-tabs">
        {["ATTACK", "TELEMETRY", "DETECTIONS", "EVIDENCE"].map(
          (item, index) => (
            <button className={index === 0 ? "active" : ""} key={item}>
              {item}
            </button>
          ),
        )}
      </div>
      <div className="security-run-layout">
        <main className="security-event-stream">
          <header>
            <span>Time</span>
            <span>Layer</span>
            <span>Entity</span>
            <span>Observation</span>
            <span>Evidence state</span>
          </header>
          {events.map(([time, layer, entity, observation, state]) => (
            <div key={time}>
              <time>{time}</time>
              <Badge
                tone={
                  layer === "ATTACK"
                    ? "amber"
                    : layer === "TELEMETRY"
                      ? "blue"
                      : layer === "SPLUNK"
                        ? "green"
                        : "neutral"
                }
              >
                {layer}
              </Badge>
              <strong>{entity}</strong>
              <span>{observation}</span>
              <em className={state === "NOT FIRED" ? "not-fired" : ""}>
                {state}
              </em>
            </div>
          ))}
        </main>
        <aside className="security-run-evidence">
          <div className="panel-kicker">Evidence status</div>
          <h2>Telemetry observed</h2>
          <EvidencePipeline compact />
          <div className="detection-boundary">
            <Icon name="shield" />
            <p>
              <strong>No detection-fired claim</strong>Telemetry is present.
              Splunk Security Content and Sigma mappings remain research
              required, so NetSpout does not claim that a detection fired.
            </p>
          </div>
          <Button onClick={() => navigate("investigation")} icon="arrow">
            Open investigation
          </Button>
        </aside>
      </div>
    </div>
  )
}

function ResourceBehavior() {
  const values = [42, 51, 63, 76, 88, 96]
  return (
    <section className="resource-behavior">
      <div className="section-head compact">
        <div>
          <div className="eyebrow">
            Resource behavior · realistic prototype data
          </div>
          <h2>Memory pressure over time</h2>
        </div>
        <Badge tone="amber">MODELED VALUES</Badge>
      </div>
      <div className="resource-chart">
        <div className="chart-axis">
          <span>100%</span>
          <span>75%</span>
          <span>50%</span>
          <span>25%</span>
        </div>
        <div className="chart-plot">
          <svg
            viewBox="0 0 600 190"
            preserveAspectRatio="none"
            aria-label="Memory increases from 42 to 96 percent"
          >
            <path
              className="area"
              d="M0 145 L120 128 L240 103 L360 76 L480 45 L600 18 L600 190 L0 190 Z"
            />
            <path
              className="line"
              d="M0 145 L120 128 L240 103 L360 76 L480 45 L600 18"
            />
            {values.map((value, index) => (
              <circle
                key={value}
                cx={index * 120}
                cy={[145, 128, 103, 76, 45, 18][index]}
                r="4"
              />
            ))}
          </svg>
          <div className="chart-events">
            <span className="event-threshold">Memory threshold</span>
            <span className="event-gc">GC pressure</span>
            <span className="event-latency">Trace latency</span>
            <span className="event-restart">Restart</span>
          </div>
          <div className="chart-labels">
            {values.map((value, index) => (
              <span key={value}>
                <small>T+{index * 2}</small>
                <strong>{value}%</strong>
              </span>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}

function ITOpsScenarioDetail({ advanced }: { advanced: boolean }) {
  return (
    <div className="page">
      <header className="detail-header">
        <div>
          <div className="domain-cell">
            <DomainPill domain="ITOPS" />
            <DomainPill domain="OBSERVABILITY" />
            <Badge tone="amber">BETA</Badge>
          </div>
          <h1>Progressive Memory Leak</h1>
          <p>
            Model gradual memory pressure and show how infrastructure
            degradation becomes trace latency, HTTP errors and service restart.
          </p>
        </div>
        <div className="detail-actions">
          <Button variant="secondary">Configure simulation</Button>
          <Button icon="play">Run beta scenario</Button>
        </div>
      </header>
      <div className="itops-layout">
        <main>
          <section className="infrastructure-state">
            <div className="section-head compact">
              <div>
                <div className="eyebrow">Infrastructure state</div>
                <h2>APP-SERVER-03</h2>
              </div>
              <Status tone="warning">DEGRADED</Status>
            </div>
            <div className="resource-table">
              {[
                ["CPU", "62%", "Stable"],
                ["Memory", "91% ↑", "Rising"],
                ["Disk", "64%", "Stable"],
                ["I/O Wait", "18%", "Elevated"],
                ["Service", "checkout-api", "Degraded"],
              ].map(([metric, value, state]) => (
                <div key={metric}>
                  <span>{metric}</span>
                  <strong>{value}</strong>
                  <small className={state === "Stable" ? "" : "warning-text"}>
                    {state}
                  </small>
                </div>
              ))}
            </div>
          </section>
          <ResourceBehavior />
          <section className="correlation-lanes">
            <div className="section-head compact">
              <div>
                <div className="eyebrow">ITOps + Observability correlation</div>
                <h2>Memory Leak → Application Failure</h2>
              </div>
            </div>
            <div className="correlation-lane">
              <DomainPill domain="ITOPS" />
              {[
                "Memory 42%",
                "Memory 63%",
                "GC pressure",
                "Memory 96%",
                "Service restart",
              ].map((item, index) => (
                <span key={item} className={index > 1 ? "warning" : ""}>
                  {item}
                </span>
              ))}
            </div>
            <div className="correlation-lane">
              <DomainPill domain="OBSERVABILITY" />
              {[
                "Baseline",
                "Normal traces",
                "Trace latency",
                "HTTP 5xx",
                "Recovery",
              ].map((item, index) => (
                <span
                  key={item}
                  className={index === 2 || index === 3 ? "critical" : ""}
                >
                  {item}
                </span>
              ))}
            </div>
          </section>
          <TelemetryContracts source="otel" />
        </main>
        <aside>
          <section className="service-model">
            <div className="panel-kicker">Service health model</div>
            <h2>Online Banking</h2>
            {[
              ["Web Tier", "DEGRADED"],
              ["API Tier", "CRITICAL"],
              ["Authentication", "HEALTHY"],
              ["Database", "DEGRADED"],
              ["Network", "DEGRADED"],
            ].map(([name, state]) => (
              <div key={name}>
                <span>{name}</span>
                <Status
                  tone={
                    state === "HEALTHY"
                      ? "healthy"
                      : state === "CRITICAL"
                        ? "error"
                        : "warning"
                  }
                >
                  {state}
                </Status>
              </div>
            ))}
            <footer>
              <span>Overall service</span>
              <Status tone="error">CRITICAL</Status>
            </footer>
          </section>
          <section className="itops-generator">
            <div className="panel-kicker">ITOps generator</div>
            <h2>Simulation configuration</h2>
            <dl>
              <div>
                <dt>Entity type</dt>
                <dd>Linux Server</dd>
              </div>
              <div>
                <dt>Behavior</dt>
                <dd>Memory Leak</dd>
              </div>
              <div>
                <dt>Starting value</dt>
                <dd>42%</dd>
              </div>
              <div>
                <dt>Peak</dt>
                <dd>96%</dd>
              </div>
              <div>
                <dt>Duration</dt>
                <dd>10 minutes</dd>
              </div>
              <div>
                <dt>Telemetry</dt>
                <dd>OpenTelemetry Metrics</dd>
              </div>
            </dl>
            {advanced && (
              <div className="advanced-contract">
                <ProvenanceBadge kind="RESEARCH REQUIRED" />
                <span>
                  Metric name, unit, interval and resource attributes must be
                  selected from the verified catalog before generation.
                </span>
              </div>
            )}
            <SplunkIntegrationPanel source="otel" />
          </section>
          <ScenarioFidelity
            telemetry={2}
            verified={1}
            splunk={1}
            detection="N/A"
            research={1}
            unsupported={0}
            overall="PARTIALLY VERIFIED"
          />
        </aside>
      </div>
    </div>
  )
}

const supplyStages = [
  "Developer",
  "Source Repository",
  "Pull Request",
  "CI/CD Pipeline",
  "Build Runner",
  "Dependency",
  "Build",
  "Artifact",
  "Registry",
  "Deployment",
  "Workload",
]

function SupplyChainPipeline({ active = -1 }: { active?: number }) {
  return (
    <div className="supply-pipeline">
      {supplyStages.map((stage, index) => (
        <div
          className={
            active === index ? "active" : index < active ? "complete" : ""
          }
          key={stage}
        >
          <span>
            <Icon
              name={
                index < 3
                  ? "terminal"
                  : index < 7
                    ? "settings"
                    : index < 9
                      ? "layers"
                      : "server"
              }
              size={15}
            />
          </span>
          <strong>{stage}</strong>
          {index < supplyStages.length - 1 && <Icon name="arrow" size={13} />}
        </div>
      ))}
    </div>
  )
}

function SupplyChainScenarioDetail({
  navigate,
}: {
  navigate: (page: Page) => void
}) {
  return (
    <div className="page">
      <header className="detail-header">
        <div>
          <div className="domain-cell">
            <DomainPill domain="SUPPLY CHAIN" />
            <DomainPill domain="SECOPS" />
            <DomainPill domain="OBSERVABILITY" />
            <Badge tone="neutral">PLANNED</Badge>
          </div>
          <h1>Dependency Confusion</h1>
          <p>
            A conceptual source-to-runtime scenario showing how an unexpected
            dependency could influence a build, artifact, deployment and
            downstream security evidence.
          </p>
        </div>
        <div className="detail-actions">
          <Button variant="secondary" onClick={() => navigate("supply-run")}>
            Preview planned flow
          </Button>
          <Button disabled icon="play">
            Runtime not available
          </Button>
        </div>
      </header>
      <div className="planned-banner">
        <ProvenanceBadge kind="RESEARCH REQUIRED" />
        <div>
          <strong>
            Conceptual scenario — no platform event schema is asserted
          </strong>
          <p>
            Selecting a repository, CI/CD and registry platform is required
            before telemetry contracts can be researched and verified.
          </p>
        </div>
      </div>
      <section className="signature-section">
        <div className="section-head compact">
          <div>
            <div className="eyebrow">Supply chain enterprise model</div>
            <h2>Repository to runtime</h2>
          </div>
          <span className="prototype-label">
            NETSPOUT-DEFINED CONCEPTUAL FLOW
          </span>
        </div>
        <SupplyChainPipeline />
      </section>
      <section className="dependency-flow">
        <div className="section-head compact">
          <div>
            <div className="eyebrow">Scenario sequence</div>
            <h2>Dependency Confusion Incident</h2>
          </div>
        </div>
        {[
          "Developer triggers build",
          "Pipeline resolves dependency",
          "Unexpected external package selected",
          "Runner downloads package",
          "Package executes during build",
          "Credential access behavior",
          "Artifact modified",
          "Artifact published",
          "Deployment occurs",
          "Runtime security activity",
        ].map((item, index) => (
          <div key={item}>
            <span>{String(index + 1).padStart(2, "0")}</span>
            <strong>{item}</strong>
            <small>
              {index < 2
                ? "Expected state"
                : index < 6
                  ? "Supply Chain + SecOps"
                  : "Runtime propagation"}
            </small>
            {index < 9 && <Icon name="arrow" size={13} />}
          </div>
        ))}
      </section>
      <div className="supply-detail-grid">
        <ScenarioFidelity
          telemetry={6}
          verified={0}
          splunk={0}
          detection={0}
          research={6}
          unsupported={0}
          overall="PLANNED"
        />
        <section className="supply-contracts">
          <div className="panel-kicker">Telemetry contract readiness</div>
          <h2>Platform selection required</h2>
          {[
            ["Source control audit", "RESEARCH REQUIRED"],
            ["CI/CD audit", "RESEARCH REQUIRED"],
            ["Runner / host telemetry", "RESEARCH REQUIRED"],
            ["Artifact / registry audit", "RESEARCH REQUIRED"],
            ["Deployment audit", "RESEARCH REQUIRED"],
            ["Runtime security telemetry", "RESEARCH REQUIRED"],
          ].map(([name, state]) => (
            <div key={name}>
              <span>{name}</span>
              <ProvenanceBadge kind={state as ProvenanceKind} />
            </div>
          ))}
          <p>
            No GitHub, GitLab, Jenkins, Azure DevOps, registry or cloud schema
            is implied by this prototype.
          </p>
        </section>
      </div>
    </div>
  )
}

function SupplyChainLiveRun() {
  const events = [
    ["14:10:01", "SOURCE", "Pull request merged"],
    ["14:10:12", "BUILD", "Pipeline started"],
    ["14:10:38", "DEPENDENCY", "Unexpected package resolved"],
    ["14:10:42", "RUNNER", "Unexpected process behavior"],
    ["14:11:15", "ARTIFACT", "Build artifact produced"],
    ["14:12:02", "DEPLOYMENT", "Artifact deployed"],
    ["14:12:21", "SECURITY", "Unexpected outbound behavior"],
  ]
  return (
    <div className="page">
      <header className="page-header">
        <div>
          <div className="eyebrow">
            Planned flow preview · realistic prototype data
          </div>
          <h1>Dependency Confusion</h1>
          <p>
            This preview demonstrates product interaction only. It does not
            claim native CI/CD telemetry or runtime support.
          </p>
        </div>
        <Badge tone="neutral">PLANNED</Badge>
      </header>
      <SupplyChainPipeline active={5} />
      <div className="supply-run-grid">
        <section className="supply-event-stream">
          <header>
            <span>Scenario timeline</span>
            <ProvenanceBadge kind="RESEARCH REQUIRED" />
          </header>
          {events.map(([time, stage, summary]) => (
            <div key={time}>
              <time>{time}</time>
              <Badge tone="neutral">{stage}</Badge>
              <strong>{summary}</strong>
              <span>
                Conceptual state transition · no vendor schema claimed
              </span>
            </div>
          ))}
        </section>
        <aside className="supply-investigation">
          <div className="panel-kicker">Cross-domain investigation</div>
          <h2>Propagation path</h2>
          {[
            ["ROOT EVENT", "Unexpected dependency resolved"],
            ["SUPPLY CHAIN", "Package executed in runner"],
            ["SECURITY", "Credential access behavior"],
            ["SUPPLY CHAIN", "Artifact modified"],
            ["DEPLOYMENT", "Modified artifact deployed"],
            ["OBSERVABILITY", "Application behavior changes"],
            ["NETOPS", "Unexpected external communication"],
            ["SECURITY", "Detection evidence · research required"],
          ].map(([domain, event], index) => (
            <div key={`${domain}-${event}`}>
              <span>{domain}</span>
              <strong>{event}</strong>
              {index < 7 && <i />}
            </div>
          ))}
          <Button variant="secondary">Open investigation prototype</Button>
        </aside>
      </div>
    </div>
  )
}

function UnifiedHome({ navigate }: { navigate: (page: Page) => void }) {
  return (
    <div className="page phase2-home">
      <section className="unified-hero">
        <div>
          <div className="eyebrow">
            NetSpout · Unified Enterprise Telemetry Lab
          </div>
          <h1>
            One simulated enterprise.
            <br />
            Every operational perspective.
          </h1>
          <p>
            Simulate enterprise incidents. Generate authentic telemetry.
            Correlate what happened. Investigate it in Splunk.
          </p>
          <div className="hero-actions">
            <Button onClick={() => navigate("scenarios")} icon="play">
              Run scenario
            </Button>
            <Button
              onClick={() => navigate("generate")}
              variant="secondary"
              icon="bolt"
            >
              Generate telemetry
            </Button>
          </div>
          <div className="hero-links">
            <button onClick={() => navigate("builder")}>
              Build scenario <Icon name="arrow" size={14} />
            </button>
            <button onClick={() => navigate("explorer")}>
              Explore telemetry <Icon name="arrow" size={14} />
            </button>
          </div>
        </div>
        <div className="enterprise-state">
          <div className="state-label">ONE ENTERPRISE STATE</div>
          <div className="state-origin">
            <Icon name="bolt" />
            <div>
              <strong>Core routing instability</strong>
              <span>Infrastructure Smoke Screen</span>
            </div>
          </div>
          <div className="state-branches">
            {[
              ["NETOPS", "BGP adjacency lost"],
              ["ITOPS", "Service KPI degraded"],
              ["OBSERVABILITY", "API latency · HTTP 5xx"],
              ["SECOPS", "Credential activity detected"],
            ].map(([domain, event]) => (
              <div key={domain}>
                <DomainPill domain={domain as Domain} />
                <span>{event}</span>
              </div>
            ))}
          </div>
          <small>One incident · correlated observations</small>
        </div>
      </section>
      <section className="status-strip">
        <div className="strip-title">
          <span>Runtime readiness</span>
          <strong>Evidence-based status</strong>
        </div>
        {[
          ["Splunk", "Connected"],
          ["Syslog", "Listening"],
          ["SNMP", "Ready"],
          ["gNMI", "Streaming"],
          ["Flow", "Receiving"],
          ["OTel Collector", "Healthy"],
        ].map(([name, state]) => (
          <div className="service-status" key={name}>
            <Status>{state}</Status>
            <strong>{name}</strong>
          </div>
        ))}
        <button onClick={() => navigate("pipeline")}>
          Inspect pipelines <Icon name="arrow" size={14} />
        </button>
      </section>
      <section className="domain-readiness">
        <div className="section-head compact">
          <div>
            <div className="eyebrow">Content capability</div>
            <h2>Domain readiness</h2>
          </div>
          <span>Separate from runtime health</span>
        </div>
        <div>
          {domains.map((domain) => (
            <button
              key={domain.name}
              onClick={() =>
                domain.state !== "Planned" && navigate("scenarios")
              }
            >
              <span>
                <Icon name={domain.icon} />
              </span>
              <strong>{domain.short}</strong>
              <small>{domain.state}</small>
            </button>
          ))}
        </div>
      </section>
      <section className="content-section">
        <div className="section-head">
          <div>
            <div className="eyebrow">Recent simulations</div>
            <h2>Continue an investigation</h2>
          </div>
          <button
            className="text-link"
            onClick={() => navigate("investigation")}
          >
            View investigations <Icon name="arrow" size={14} />
          </button>
        </div>
        <div className="table-frame">
          <table>
            <thead>
              <tr>
                <th>Scenario</th>
                <th>Domains</th>
                <th>Status</th>
                <th>Evidence</th>
                <th>Splunk</th>
                <th>Time</th>
                <th />
              </tr>
            </thead>
            <tbody>
              {[
                [
                  "Infrastructure Smoke Screen",
                  ["NETOPS", "SECOPS", "ITOPS", "OBSERVABILITY"],
                  "842",
                  "4m ago",
                ],
                [
                  "Agentic AI Cascading Failure",
                  ["AGENTIC AI", "OBSERVABILITY", "ITOPS"],
                  "376",
                  "23m ago",
                ],
                ["BGP Link Failure", ["NETOPS"], "184", "1h ago"],
                ["Kerberoasting Lab", ["SECOPS"], "128", "2h ago"],
              ].map(([name, runDomains, evidence, time], index) => (
                <tr
                  key={name as string}
                  onClick={() =>
                    navigate(index === 1 ? "agentic" : "investigation")
                  }
                >
                  <td>
                    <strong>{name as string}</strong>
                  </td>
                  <td>
                    <div className="domain-cell">
                      {(runDomains as string[]).map((domain) => (
                        <DomainPill key={domain} domain={domain as Domain} />
                      ))}
                    </div>
                  </td>
                  <td>
                    <Status>Completed</Status>
                  </td>
                  <td>{evidence as string}</td>
                  <td>
                    <span className="observed">
                      <Icon name="check" size={13} />
                      Observed
                    </span>
                  </td>
                  <td>{time as string}</td>
                  <td>
                    <Icon name="chevron" size={14} />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
      <section className="getting-started five-step">
        {["Choose", "Run", "Observe", "Correlate", "Investigate"].map(
          (step, index) => (
            <div key={step}>
              <span className="step-number">
                {String(index + 1).padStart(2, "0")}
              </span>
              <div>
                <strong>{step}</strong>
                <small>
                  {
                    [
                      "Select enterprise state",
                      "Start the simulation",
                      "Watch each perspective",
                      "Connect the evidence",
                      "Open in Splunk",
                    ][index]
                  }
                </small>
              </div>
              {index < 4 && <Icon name="arrow" />}
            </div>
          ),
        )}
      </section>
    </div>
  )
}

function GenerateHub({ navigate }: { navigate: (page: Page) => void }) {
  const [domain, setDomain] = useState<Domain | "ALL">("ALL")
  const modes: {
    title: string
    description: string
    icon: IconName
    page: Page
    examples: string
  }[] = [
    {
      title: "Scenario",
      description: "Simulate a complete incident",
      icon: "network",
      page: "scenarios",
      examples: "Cross-domain · security · network · AI",
    },
    {
      title: "Data Source",
      description: "Generate from a platform or technology",
      icon: "server",
      page: "data-source",
      examples: "Cisco · Windows · AWS · Kubernetes",
    },
    {
      title: "Sourcetype",
      description: "Generate an exact telemetry quantity",
      icon: "terminal",
      page: "sourcetype",
      examples: "Count · rate · duration · destination",
    },
    {
      title: "Single Event",
      description: "Create exactly one observation",
      icon: "pulse",
      page: "single-event",
      examples: "Preview · send · prove delivery",
    },
  ]
  return (
    <div className="page">
      <header className="page-header">
        <div>
          <div className="eyebrow">Generate</div>
          <h1>Generate Telemetry</h1>
          <p>
            Choose an outcome first. Protocol and schema detail remain available
            when you need them.
          </p>
        </div>
        <Status>Splunk destination ready</Status>
      </header>
      <DomainSelector value={domain} onChange={setDomain} />
      <div className="mode-grid">
        {modes.map((mode) => (
          <button key={mode.title} onClick={() => navigate(mode.page)}>
            <span>
              <Icon name={mode.icon} />
            </span>
            <div>
              <strong>{mode.title}</strong>
              <p>{mode.description}</p>
              <small>{mode.examples}</small>
            </div>
            <Icon name="arrow" />
          </button>
        ))}
      </div>
      <section className="generation-principle">
        <Icon name="shield" />
        <div>
          <strong>State before syntax</strong>
          <p>
            NetSpout models enterprise behavior, then derives observations.
            Provenance and fidelity are shown before generation.
          </p>
        </div>
        <button onClick={() => navigate("provenance")}>
          Review provenance <Icon name="arrow" size={14} />
        </button>
      </section>
    </div>
  )
}

function GeneratorWorkspace({
  mode,
  navigate,
}: {
  mode: "data" | "sourcetype" | "single"
  navigate: (page: Page) => void
}) {
  const [domain, setDomain] = useState<Domain | "ALL">("NETOPS")
  const [count, setCount] = useState(mode === "single" ? 1 : 10)
  const [generated, setGenerated] = useState(false)
  const labels =
    mode === "data"
      ? [
          "Domain",
          "Vendor / Platform",
          "Product / Technology",
          "Telemetry type",
        ]
      : mode === "sourcetype"
        ? ["Domain", "Telemetry family", "Sourcetype", "Transport"]
        : ["Domain", "Vendor / Platform", "Event family", "Event"]
  const values =
    domain === "SECOPS"
      ? [
          "SECOPS",
          "Windows / Active Directory",
          "Credential Access · Kerberoasting",
          "Windows Security 4769",
        ]
      : domain === "AGENTIC AI"
        ? [
            "AGENTIC AI",
            "Database Assistant",
            "MCP tool execution",
            "netspout:agentic:audit",
          ]
        : ["NETOPS", "OpenConfig", "Interfaces", "gNMI / JSON_IETF"]
  return (
    <div className="page">
      <header className="detail-header">
        <div>
          <button className="back-link" onClick={() => navigate("generate")}>
            ← Generate Telemetry
          </button>
          <div className="eyebrow">
            {mode === "data"
              ? "Data source"
              : mode === "sourcetype"
                ? "Exact data generation"
                : "Single observation"}
          </div>
          <h1>
            {mode === "data"
              ? "Data Source Generator"
              : mode === "sourcetype"
                ? "Sourcetype Generator"
                : "Single Event Generator"}
          </h1>
          <p>
            {mode === "single"
              ? "Generate exactly one event, inspect it, then prove where it went."
              : "Configure realistic telemetry without exposing protocol internals prematurely."}
          </p>
        </div>
        <Status>Destination ready</Status>
      </header>
      <DomainSelector value={domain} onChange={setDomain} includeAll={false} />
      <div className="generator-layout">
        <main className="generator-form">
          <div className="step-fields">
            {labels.map((label, index) => (
              <label key={label}>
                <span>
                  {String(index + 1).padStart(2, "0")} · {label}
                </span>
                <button>
                  {values[index]}
                  <Icon name="chevron" size={14} />
                </button>
              </label>
            ))}
          </div>
          {domain === "SECOPS" && (
            <div className="mapping-note">
              <Badge tone="amber">MITRE ATT&CK</Badge>
              <strong>T1558.003 · Kerberoasting</strong>
              <span>
                Attack behavior and telemetry evidence are modeled separately.
              </span>
            </div>
          )}
          {domain === "AGENTIC AI" && (
            <div className="agent-fields">
              <div>
                <span>Policy result</span>
                <strong>DENIED</strong>
              </div>
              <div>
                <span>MCP server</span>
                <strong>Database MCP</strong>
              </div>
              <div>
                <span>Human approval</span>
                <strong>Not requested</strong>
              </div>
            </div>
          )}
          <section className="volume-section">
            <div className="section-head compact">
              <div>
                <div className="eyebrow">Volume</div>
                <h2>
                  {mode === "single"
                    ? "Exactly one event"
                    : "Generation controls"}
                </h2>
              </div>
            </div>
            <div className="volume-controls">
              <label>
                <span>Event count</span>
                <input
                  type="number"
                  value={count}
                  disabled={mode === "single"}
                  onChange={(event) => setCount(Number(event.target.value))}
                />
              </label>
              {mode !== "single" && (
                <>
                  <div className="presets">
                    {[1, 10, 50, 100, 500].map((preset) => (
                      <button
                        className={count === preset ? "active" : ""}
                        key={preset}
                        onClick={() => setCount(preset)}
                      >
                        {preset}
                      </button>
                    ))}
                  </div>
                  <label>
                    <span>Rate</span>
                    <div>
                      <input type="number" defaultValue="10" />
                      <small>EPS</small>
                    </div>
                  </label>
                </>
              )}
            </div>
          </section>
          <section className="event-preview">
            <div>
              <span>Normalized preview · modeled values</span>
              {domain === "AGENTIC AI" ? (
                <ProvenanceBadge kind="NETSPOUT SCHEMA" />
              ) : domain === "NETOPS" ? (
                <ProvenanceBadge kind="STANDARD VERIFIED" />
              ) : (
                <ProvenanceBadge kind="VENDOR VERIFIED" />
              )}
            </div>
            <code>
              {domain === "SECOPS"
                ? `EventCode=4769 ComputerName=DC-01 ServiceName=MSSQLSvc/SQL-01 TicketEncryptionType=0x17`
                : domain === "AGENTIC AI"
                  ? `{"schema":"netspout:agentic:audit","agent":"database-assistant","policy_result":"denied","tool":"query_database"}`
                  : `{"path":"/interfaces/interface[name=GigabitEthernet0/0/1]/state/oper-status","value":"DOWN"}`}
            </code>
          </section>
        </main>
        <aside className="generator-summary">
          <div className="panel-kicker">Provenance</div>
          <h2>
            {domain === "AGENTIC AI"
              ? "NetSpout-defined schema"
              : domain === "NETOPS"
                ? "Open standard telemetry"
                : "Vendor-grounded telemetry"}
          </h2>
          <dl>
            <div>
              <dt>Classification</dt>
              <dd>
                {domain === "AGENTIC AI"
                  ? "NETSPOUT_SCHEMA"
                  : domain === "NETOPS"
                    ? "STANDARD DOCUMENTED"
                    : "VENDOR DOCUMENTED"}
              </dd>
            </div>
            <div>
              <dt>Fidelity</dt>
              <dd>MODELED EVENT</dd>
            </div>
            <div>
              <dt>Transport</dt>
              <dd>
                {domain === "AGENTIC AI"
                  ? "JSON / HEC"
                  : domain === "NETOPS"
                    ? "gNMI"
                    : "Windows Event Log"}
              </dd>
            </div>
            <div>
              <dt>Destination</dt>
              <dd>Docker + External HEC</dd>
            </div>
          </dl>
          <GenerationPreflight domain={domain as Domain} />
          <Button icon="play" onClick={() => setGenerated(true)}>
            {mode === "single" ? "Send event" : `Generate ${count}`}
          </Button>
          {generated && (
            <div className="generation-result">
              <Status>Generation complete</Status>
              {[
                ["Requested", count],
                ["Generated", count],
                ["Sent", count],
                ["Receiver observed", count],
                ["Splunk observed", count],
                ["Duplicates", 0],
              ].map(([label, value]) => (
                <div key={label}>
                  <span>{label}</span>
                  <strong>{value}</strong>
                </div>
              ))}
              <Button
                variant="secondary"
                onClick={() => navigate("investigation")}
              >
                View evidence
              </Button>
            </div>
          )}
        </aside>
      </div>
    </div>
  )
}

const phase2Scenarios: {
  name: string
  type: string
  domains: Domain[]
  level: string
  duration: string
  description: string
  status: string
}[] = [
  {
    name: "Infrastructure Smoke Screen",
    type: "MULTI-DOMAIN",
    domains: ["NETOPS", "ITOPS", "OBSERVABILITY", "SECOPS"],
    level: "Advanced",
    duration: "~8 min",
    description:
      "Routing instability degrades application performance while suspicious credential activity occurs during the operational distraction.",
    status: "Available",
  },
  {
    name: "Agentic AI Cascading Failure",
    type: "ADVANCED",
    domains: ["AGENTIC AI", "OBSERVABILITY", "ITOPS", "SECOPS"],
    level: "Advanced",
    duration: "~7 min",
    description:
      "Poisoned context drives unauthorized MCP activity, database pressure, application failures and security evidence.",
    status: "Beta",
  },
  {
    name: "BGP Link Failure",
    type: "SINGLE DOMAIN",
    domains: ["NETOPS"],
    level: "Intermediate",
    duration: "~3 min",
    description:
      "Provider-edge link failure causes BGP loss, traffic rerouting and controlled recovery.",
    status: "Available",
  },
  {
    name: "Kerberoasting Lab",
    type: "SINGLE DOMAIN",
    domains: ["SECOPS"],
    level: "Intermediate",
    duration: "~4 min",
    description:
      "Modeled service-ticket activity produces Windows authentication evidence for detection development.",
    status: "Available",
  },
  {
    name: "Compromised Build Runner",
    type: "MULTI-DOMAIN",
    domains: ["SUPPLY CHAIN", "SECOPS"],
    level: "Advanced",
    duration: "~6 min",
    description:
      "Future scenario for runner compromise, artifact tampering and downstream detection.",
    status: "Planned",
  },
]

function ExpandedScenarioLibrary({
  navigate,
}: {
  navigate: (page: Page) => void
}) {
  const [domain, setDomain] = useState<Domain | "ALL">("ALL")
  const [query, setQuery] = useState("")
  const visible = phase2Scenarios.filter(
    (scenario) =>
      (domain === "ALL" || scenario.domains.includes(domain)) &&
      scenario.name.toLowerCase().includes(query.toLowerCase()),
  )
  return (
    <div className="page">
      <header className="page-header">
        <div>
          <div className="eyebrow">Enterprise incident catalog</div>
          <h1>Scenario Library</h1>
          <p>
            Choose a modeled enterprise condition. Multi-domain scenarios remain
            one incident, not separate event bundles.
          </p>
        </div>
        <Button
          onClick={() => navigate("builder")}
          variant="secondary"
          icon="settings"
        >
          Build scenario
        </Button>
      </header>
      <DomainSelector value={domain} onChange={setDomain} />
      <div className="library-tools phase2-tools">
        <div className="search-field">
          <Icon name="search" />
          <input
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder="Search scenarios..."
            aria-label="Search scenarios"
          />
        </div>
        <Button variant="secondary" icon="filter">
          Vendor · Difficulty · Telemetry · MITRE
        </Button>
      </div>
      <div className="results-meta">
        <strong>{visible.length} scenarios</strong>
        <span>Prototype content · capability state shown</span>
      </div>
      <div className="scenario-list">
        {visible.map((scenario) => (
          <article
            className={`scenario-row scenario-${scenario.type.toLowerCase().replace(" ", "-")}`}
            key={scenario.name}
          >
            <div className="scenario-symbol">
              <Icon
                name={
                  scenario.domains.includes("AGENTIC AI")
                    ? "terminal"
                    : scenario.domains.length > 1
                      ? "layers"
                      : scenario.domains[0] === "SECOPS"
                        ? "shield"
                        : "network"
                }
              />
            </div>
            <div className="scenario-main">
              <div className="scenario-title">
                <div>
                  <div className="scenario-type">{scenario.type}</div>
                  <h2>{scenario.name}</h2>
                  <div className="domain-cell">
                    {scenario.domains.map((item) => (
                      <DomainPill key={item} domain={item} />
                    ))}
                  </div>
                </div>
                <div>
                  <Badge
                    tone={
                      scenario.status === "Beta"
                        ? "amber"
                        : scenario.status === "Planned"
                          ? "neutral"
                          : "green"
                    }
                  >
                    {scenario.status.toUpperCase()}
                  </Badge>
                  <span className="duration">
                    <Icon name="clock" size={13} />
                    {scenario.duration}
                  </span>
                </div>
              </div>
              <p>{scenario.description}</p>
              <div className="scenario-meta">
                <span>{scenario.level}</span>
                <i />
                <span>
                  {scenario.domains.length > 1
                    ? "Correlated evidence"
                    : "Focused lab"}
                </span>
              </div>
            </div>
            <div className="scenario-actions">
              <Button
                variant="secondary"
                disabled={scenario.status === "Planned"}
                onClick={() =>
                  navigate(
                    scenario.name.includes("Agentic")
                      ? "agentic"
                      : scenario.name.includes("Kerberoasting")
                        ? "security"
                        : "scenario",
                  )
                }
              >
                View scenario
              </Button>
              <Button
                disabled={scenario.status === "Planned"}
                onClick={() => navigate("run")}
                icon="play"
              >
                Run
              </Button>
            </div>
          </article>
        ))}
      </div>
    </div>
  )
}

const laneEvents: Record<string, {
  left: number
  width: number
  label: string
  state?: string
}[]> = {
  NETOPS: [
    { left: 8, width: 27, label: "BGP instability" },
    { left: 35, width: 16, label: "Link failure", state: "critical" },
    { left: 51, width: 19, label: "Failover" },
    { left: 70, width: 22, label: "Recovery" },
  ],
  ITOPS: [
    { left: 25, width: 47, label: "Service KPI degradation", state: "warning" },
    { left: 72, width: 18, label: "Recovery" },
  ],
  OBSERVABILITY: [
    { left: 19, width: 28, label: "Trace latency" },
    { left: 47, width: 28, label: "HTTP 5xx", state: "critical" },
    { left: 75, width: 17, label: "Normal" },
  ],
  SECOPS: [
    { left: 39, width: 23, label: "Kerberoasting", state: "critical" },
    { left: 62, width: 27, label: "Detection" },
  ],
  "AGENTIC AI": [],
}

function IncidentTimeline({ interactive = true }: { interactive?: boolean }) {
  const [selected, setSelected] = useState("Link failure")
  return (
    <div className="incident-timeline">
      <div className="timeline-ruler">
        <span>TIME</span>
        {["T+00", "T+60", "T+120", "T+180", "T+240"].map((time) => (
          <i key={time}>{time}</i>
        ))}
      </div>
      {Object.entries(laneEvents).map(([domain, events]) => (
        <div className="swimlane" key={domain}>
          <DomainPill domain={domain as Domain} />
          <div className="lane-track">
            {events.map((event) => (
              <button
                className={`${event.state || ""} ${
                  selected === event.label ? "selected" : ""
                }`}
                style={{ left: `${event.left}%`, width: `${event.width}%` }}
                key={event.label}
                onClick={() => interactive && setSelected(event.label)}
              >
                {event.label}
              </button>
            ))}
          </div>
        </div>
      ))}
      {interactive && (
        <div className="timeline-selection">
          <span>Selected evidence</span>
          <strong>{selected}</strong>
          <code>correlation_id=NS-2026-00481 · Splunk observed</code>
          <button>
            Inspect evidence <Icon name="arrow" size={13} />
          </button>
        </div>
      )}
    </div>
  )
}

function CausalGraph() {
  return (
    <div className="causal-graph">
      <div className="causal-branch">
        {[
          "BGP instability",
          "Packet loss",
          "checkout-api latency",
          "DB connection pressure",
          "HTTP 5xx",
        ].map((item, index) => (
          <div key={item}>
            <span className={index === 0 ? "root" : ""}>{item}</span>
            {index < 4 && <Icon name="arrow" size={15} />}
          </div>
        ))}
      </div>
      <div className="causal-meanwhile">
        <span>MEANWHILE</span>
      </div>
      <div className="causal-branch security">
        {[
          "Operational distraction",
          "Kerberos activity",
          "Credential access evidence",
          "Security detection",
        ].map((item, index) => (
          <div key={item}>
            <span>{item}</span>
            {index < 3 && <Icon name="arrow" size={15} />}
          </div>
        ))}
      </div>
    </div>
  )
}

function MultiDomainScenario({ navigate }: { navigate: (page: Page) => void }) {
  return (
    <div className="page">
      <header className="detail-header">
        <div>
          <button className="back-link" onClick={() => navigate("scenarios")}>
            ← Scenario Library
          </button>
          <div className="domain-cell">
            {(["NETOPS", "ITOPS", "OBSERVABILITY", "SECOPS"] as Domain[]).map(
              (domain) => (
                <DomainPill domain={domain} key={domain} />
              ),
            )}
          </div>
          <h1>Infrastructure Smoke Screen</h1>
          <p>
            A routing incident degrades application and infrastructure health
            while credential-access activity occurs during the operational
            distraction.
          </p>
          <div className="scenario-meta">
            <Badge tone="amber">ADVANCED</Badge>
            <span>
              <Icon name="clock" size={13} /> ~8 minutes
            </span>
            <span>Prototype scenario · Available</span>
          </div>
        </div>
        <div className="detail-actions">
          <Button
            variant="secondary"
            onClick={() => navigate("builder")}
            icon="settings"
          >
            Configure
          </Button>
          <Button onClick={() => navigate("run")} icon="play">
            Run scenario
          </Button>
        </div>
      </header>
      <section className="phase-track extended">
        {[
          "Initialize",
          "Baseline",
          "Degrade",
          "Fault",
          "Impact",
          "Attack",
          "Failover",
          "Recover",
          "Validate",
        ].map((phase, index) => (
          <div key={phase}>
            <span>{String(index + 1).padStart(2, "0")}</span>
            <strong>{phase}</strong>
            {index < 8 && <i />}
          </div>
        ))}
      </section>
      <div className="scenario-story-grid">
        <section className="plain-section">
          <div className="eyebrow">Incident story</div>
          <h2>Operational failure creates a security opportunity</h2>
          <p>
            A core routing instability causes packet loss, checkout latency,
            infrastructure KPI degradation and HTTP failures. During the
            response, modeled suspicious service-ticket activity appears in the
            Windows environment.
          </p>
        </section>
        <aside className="scenario-facts">
          <div>
            <span>Root cause</span>
            <strong>Core routing instability</strong>
          </div>
          <div>
            <span>Entities</span>
            <strong>8 across 4 domains</strong>
          </div>
          <div>
            <span>Expected evidence</span>
            <strong>~800–900 observations</strong>
          </div>
          <div>
            <span>Destination</span>
            <Status>Docker + External HEC</Status>
          </div>
        </aside>
      </div>
      <section className="signature-section">
        <div className="section-head compact">
          <div>
            <div className="eyebrow">Enterprise causal graph</div>
            <h2>What causes what</h2>
          </div>
          <Badge tone="blue">SIGNATURE VIEW</Badge>
        </div>
        <CausalGraph />
      </section>
      <section className="signature-section">
        <div className="section-head compact">
          <div>
            <div className="eyebrow">Multi-domain timeline</div>
            <h2>One incident across four perspectives</h2>
          </div>
          <button className="text-link" onClick={() => navigate("timeline")}>
            Open full timeline <Icon name="external" size={13} />
          </button>
        </div>
        <IncidentTimeline interactive={false} />
      </section>
      <section className="signature-section">
        <div className="section-head compact">
          <div>
            <div className="eyebrow">Evidence path</div>
            <h2>Expected delivery stages</h2>
          </div>
        </div>
        <EvidencePipeline compact />
      </section>
    </div>
  )
}

const crossDomainTelemetry = [
  ["14:31:02", "NETOPS", "PE-RTR-01", "BGP", "Adjacency with 10.30.4.137 lost"],
  [
    "14:31:18",
    "ITOPS",
    "app-node-03",
    "OTel Metric",
    "Service KPI degraded to 71%",
  ],
  [
    "14:31:29",
    "OBSERVABILITY",
    "checkout-api",
    "OTel Trace",
    "DB span latency increased to 2.8s",
  ],
  [
    "14:31:42",
    "SECOPS",
    "DC-01",
    "Windows 4769",
    "Abnormal service ticket activity",
  ],
  [
    "14:32:05",
    "OBSERVABILITY",
    "checkout-api",
    "Application JSON",
    "HTTP 5xx rate exceeded threshold",
  ],
] as const

function MultiDomainLiveRun({ navigate }: { navigate: (page: Page) => void }) {
  const [selected, setSelected] = useState(0)
  return (
    <div className="phase2-run">
      <header className="run-header">
        <div>
          <div className="run-title-line">
            <h1>Infrastructure Smoke Screen</h1>
            <Status tone="info">RUNNING</Status>
          </div>
          <div className="run-meta">
            <span>
              Run ID <code>NS-2026-00481</code>
            </span>
            <span>
              <Icon name="clock" size={13} />
              04:18 elapsed
            </span>
            <span>
              Current phase <strong>CONCURRENT ATTACK</strong>
            </span>
          </div>
        </div>
        <div className="run-actions">
          <Button variant="secondary">Pause</Button>
          <Button variant="danger">Stop run</Button>
        </div>
      </header>
      <div className="run-domain-filter">
        <DomainSelector value="ALL" onChange={() => undefined} />
      </div>
      <section className="run-phases phase2-phases">
        {[
          "Initialize",
          "Baseline",
          "Degrade",
          "Fault",
          "Impact",
          "Attack",
          "Failover",
          "Recover",
          "Validate",
          "Complete",
        ].map((phase, index) => (
          <div
            className={index < 5 ? "done" : index === 5 ? "active" : ""}
            key={phase}
          >
            <span>
              {index < 5 ? <Icon name="check" size={12} /> : index + 1}
            </span>
            <strong>{phase}</strong>
            <small>
              {index < 5 ? "Complete" : index === 5 ? "Active" : "Waiting"}
            </small>
          </div>
        ))}
      </section>
      <div className="phase2-run-grid">
        <section className="run-panel enterprise-panel">
          <div className="panel-head">
            <div>
              <span>Enterprise state</span>
              <Status tone="warning">DEGRADED</Status>
            </div>
          </div>
          <div className="entity-map">
            {[
              ["network", "PE-RTR-01", "BGP fault", "critical"],
              ["server", "checkout-api", "2.8s latency", "warning"],
              ["database", "orders-db", "Pool 91%", "warning"],
              ["shield", "DC-01", "4769 activity", "critical"],
            ].map(([icon, name, state, tone], index) => (
              <div className={`entity-node ${tone}`} key={name}>
                <span>
                  <Icon name={icon as IconName} />
                </span>
                <div>
                  <strong>{name}</strong>
                  <small>{state}</small>
                </div>
                {index < 3 && <i />}
              </div>
            ))}
          </div>
          <div className="enterprise-summary">
            <div>
              <span>Operational recovery</span>
              <strong>Pending failover</strong>
            </div>
            <div>
              <span>Security activity</span>
              <strong className="critical-text">Investigation active</strong>
            </div>
          </div>
        </section>
        <section className="run-panel live-timeline-panel">
          <div className="panel-head">
            <div>
              <span>Incident timeline</span>
              <Badge tone="blue">LIVE</Badge>
            </div>
            <button onClick={() => navigate("timeline")}>
              <Icon name="external" />
            </button>
          </div>
          <IncidentTimeline />
        </section>
        <section className="run-panel phase2-telemetry">
          <div className="panel-head">
            <div>
              <span>Live telemetry</span>
              <span className="streaming">
                <i />
                Streaming
              </span>
            </div>
            <button>
              <Icon name="filter" />
            </button>
          </div>
          <div className="telemetry-filter-row">
            {["ALL", "NETOPS", "SECOPS", "ITOPS", "OBSERVABILITY", "AI"].map(
              (item, index) => (
                <button className={index === 0 ? "active" : ""} key={item}>
                  {item}
                </button>
              ),
            )}
          </div>
          <div className="cross-event-list">
            {crossDomainTelemetry.map((event, index) => (
              <button
                className={selected === index ? "active" : ""}
                key={event[0]}
                onClick={() => setSelected(index)}
              >
                <time>{event[0]}</time>
                <DomainPill domain={event[1] as Domain} />
                <strong>{event[2]}</strong>
                <Badge>{event[3]}</Badge>
                <span>{event[4]}</span>
                <em>
                  <Icon name="check" size={11} />
                  SPLUNK OBSERVED
                </em>
              </button>
            ))}
          </div>
          <div className="live-evidence">
            <div>
              <span>Selected observation</span>
              <strong>{crossDomainTelemetry[selected][4]}</strong>
            </div>
            <EvidencePipeline compact />
            <Button onClick={() => navigate("investigation")} icon="arrow">
              Investigate incident
            </Button>
          </div>
        </section>
      </div>
    </div>
  )
}

function TimelinePage({ navigate }: { navigate: (page: Page) => void }) {
  return (
    <div className="page">
      <header className="page-header">
        <div>
          <div className="eyebrow">Signature experience</div>
          <h1>Incident Timeline</h1>
          <p>
            Infrastructure Smoke Screen · <code>NS-2026-00481</code>
          </p>
        </div>
        <div className="timeline-controls">
          <Button variant="secondary">−</Button>
          <span>100%</span>
          <Button variant="secondary">+</Button>
          <Button onClick={() => navigate("investigation")}>
            Open investigation
          </Button>
        </div>
      </header>
      <DomainSelector value="ALL" onChange={() => undefined} />
      <section className="signature-section timeline-full">
        <IncidentTimeline />
      </section>
      <section className="timeline-evidence-grid">
        <div>
          <div className="eyebrow">Correlation</div>
          <h2>Selected event relationships</h2>
          <CausalGraph />
        </div>
        <aside>
          <div className="panel-kicker">Evidence detail</div>
          <h2>Link failure</h2>
          <dl>
            <div>
              <dt>Entity</dt>
              <dd>PE-RTR-01 · Gi0/0/1</dd>
            </div>
            <div>
              <dt>Domain</dt>
              <dd>NetOps</dd>
            </div>
            <div>
              <dt>Correlation ID</dt>
              <dd>
                <code>corr-481-bgp-04</code>
              </dd>
            </div>
            <div>
              <dt>Splunk state</dt>
              <dd>
                <Status>Observed</Status>
              </dd>
            </div>
          </dl>
          <Button variant="secondary">Open event inspector</Button>
        </aside>
      </section>
    </div>
  )
}

function Investigation({ navigate }: { navigate: (page: Page) => void }) {
  const [tab, setTab] = useState("OVERVIEW")
  return (
    <div className="page investigation-page">
      <header className="investigation-header">
        <div>
          <div className="eyebrow">Incident investigation</div>
          <h1>Infrastructure Smoke Screen</h1>
          <div className="run-meta">
            <span>
              Run <code>NS-2026-00481</code>
            </span>
            <Badge tone="amber">HIGH</Badge>
            <Status tone="warning">RECOVERED · INVESTIGATION ACTIVE</Status>
          </div>
        </div>
        <div>
          <Button variant="secondary" icon="copy">
            Copy SPL
          </Button>
          <Button icon="external">Open in Splunk</Button>
        </div>
      </header>
      <div className="investigation-tabs">
        {[
          "OVERVIEW",
          "NETWORK",
          "SECURITY",
          "INFRASTRUCTURE",
          "APPLICATIONS",
          "AI",
          "EVIDENCE",
          "SPLUNK",
        ].map((item) => (
          <button
            className={tab === item ? "active" : ""}
            onClick={() => setTab(item)}
            key={item}
          >
            {item}
          </button>
        ))}
      </div>
      {tab === "OVERVIEW" ? (
        <>
          <section className="incident-summary-grid">
            {[
              ["Root cause", "Core routing instability", "network"],
              ["Operational impact", "Checkout API latency", "pulse"],
              ["Security activity", "Suspicious Kerberos activity", "shield"],
              ["Network recovery", "Recovered at T+226", "check"],
              ["Security status", "Investigation remains active", "search"],
            ].map(([label, value, icon]) => (
              <div key={label}>
                <span>
                  <Icon name={icon as IconName} />
                  {label}
                </span>
                <strong>{value}</strong>
              </div>
            ))}
          </section>
          <div className="investigation-grid">
            <main>
              <section className="signature-section">
                <div className="section-head compact">
                  <div>
                    <div className="eyebrow">Incident timeline</div>
                    <h2>Correlated evidence</h2>
                  </div>
                  <button
                    className="text-link"
                    onClick={() => navigate("timeline")}
                  >
                    Expand timeline
                  </button>
                </div>
                <IncidentTimeline interactive={false} />
              </section>
              <section className="signature-section">
                <div className="section-head compact">
                  <div>
                    <div className="eyebrow">Enterprise causal graph</div>
                    <h2>Root cause and concurrent activity</h2>
                  </div>
                </div>
                <CausalGraph />
              </section>
            </main>
            <aside className="investigation-aside">
              <div className="panel-kicker">Evidence summary</div>
              <div className="evidence-total">
                <strong>842</strong>
                <span>correlated observations</span>
              </div>
              {[
                ["NetOps", "286"],
                ["ITOps", "144"],
                ["Observability", "284"],
                ["SecOps", "128"],
              ].map(([label, value]) => (
                <div className="evidence-domain" key={label}>
                  <span>{label}</span>
                  <strong>{value}</strong>
                </div>
              ))}
              <div className="splunk-observed">
                <Status>842 / 842 observed</Status>
                <span>Last ACK 2 sec after run completion</span>
              </div>
            </aside>
          </div>
        </>
      ) : (
        <section className="focused-tab">
          <div>
            <Icon
              name={
                tab === "SECURITY"
                  ? "shield"
                  : tab === "SPLUNK"
                    ? "database"
                    : "layers"
              }
            />
            <h2>{tab[0] + tab.slice(1).toLowerCase()} evidence</h2>
            <p>
              Filtered evidence for this operational perspective. Select an
              observation to inspect raw data, provenance, correlation and
              Splunk delivery.
            </p>
          </div>
          <EvidencePipeline />
          <Button variant="secondary">Open event inspector</Button>
        </section>
      )}
    </div>
  )
}

function AgenticIncident({ navigate }: { navigate: (page: Page) => void }) {
  const nodes = [
    ["USER / EVENT", "Workshop trigger", "home"],
    ["PROMPT", "Analyze database health", "terminal"],
    ["MEMORY RETRIEVAL", "Poisoned context", "database"],
    ["AGENT DECISION", "query_database", "bolt"],
    ["MCP TOOL", "Unauthorized invocation", "plug"],
    ["DATABASE", "312 queries", "database"],
    ["DOWNSTREAM EFFECT", "HTTP 5xx · pod restart", "pulse"],
  ]
  return (
    <div className="page">
      <header className="detail-header">
        <div>
          <button className="back-link" onClick={() => navigate("scenarios")}>
            ← Scenario Library
          </button>
          <div className="domain-cell">
            <DomainPill domain="AGENTIC AI" />
            <DomainPill domain="OBSERVABILITY" />
            <DomainPill domain="ITOPS" />
            <DomainPill domain="SECOPS" />
          </div>
          <h1>Agentic AI Cascading Failure</h1>
          <p>
            Poisoned retrieved context influences an agent decision, drives
            unauthorized MCP activity and creates observable application
            consequences.
          </p>
        </div>
        <div className="detail-actions">
          <Badge tone="amber">BETA</Badge>
          <Button onClick={() => navigate("run")} icon="play">
            Run scenario
          </Button>
        </div>
      </header>
      <section className="agentic-flow">
        <div className="flow-checkpoints">
          <span>POLICY</span>
          <span>PERMISSION</span>
          <span>HUMAN APPROVAL</span>
          <span>CREDENTIAL</span>
          <span>TOOL AUTHORIZATION</span>
        </div>
        <div className="agentic-node-row">
          {nodes.map(([type, label, icon], index) => (
            <div key={type}>
              <article
                className={
                  index === 2 || index === 4
                    ? "warning"
                    : index > 4
                      ? "impact"
                      : ""
                }
              >
                <span>
                  <Icon name={icon as IconName} />
                  {type}
                </span>
                <strong>{label}</strong>
                {index === 2 && (
                  <small>Warning · Modeled poisoned context</small>
                )}
                {index === 4 && <small>Warning · Authorization bypassed</small>}
              </article>
              {index < nodes.length - 1 && <Icon name="arrow" />}
            </div>
          ))}
        </div>
      </section>
      <div className="scenario-story-grid">
        <section className="signature-section">
          <div className="eyebrow">Downstream causal chain</div>
          <h2>AI activity becomes enterprise impact</h2>
          <div className="impact-chain">
            {[
              "MCP invocation",
              "Database pool 98%",
              "Trace latency 4.1s",
              "HTTP 5xx",
              "Kubernetes restart",
              "Security evidence",
            ].map((item, index) => (
              <div key={item}>
                <span>{index + 1}</span>
                <strong>{item}</strong>
                {index < 5 && <Icon name="arrow" size={14} />}
              </div>
            ))}
          </div>
        </section>
        <aside className="scenario-facts">
          <div>
            <span>Schema status</span>
            <strong>NetSpout-defined · Beta</strong>
          </div>
          <div>
            <span>Native vendor standard</span>
            <strong>No</strong>
          </div>
          <div>
            <span>Provenance</span>
            <strong>Explicitly modeled</strong>
          </div>
          <div>
            <span>Splunk mapping</span>
            <strong>
              <code>netspout:agentic:audit</code>
            </strong>
          </div>
        </aside>
      </div>
      <section className="signature-section">
        <div className="section-head compact">
          <div>
            <div className="eyebrow">Evidence pipeline</div>
            <h2>Agent action to Splunk evidence</h2>
          </div>
        </div>
        <EvidencePipeline />
      </section>
    </div>
  )
}

function ScenarioBuilder() {
  const [selected, setSelected] = useState("BGP degradation")
  const palette = [
    ["NETWORK", ["Router", "Switch", "Firewall", "WAN"]],
    ["SECURITY", ["Identity", "Endpoint", "Attacker", "Security Control"]],
    [
      "INFRASTRUCTURE",
      [
        "Server",
        "VM",
        "Container",
        "Database",
        "Storage",
        "Process",
        "Service",
      ],
    ],
    ["APPLICATION", ["Service", "API", "Kubernetes"]],
    ["AI", ["Agent", "Model", "Memory", "MCP Server", "Tool"]],
    [
      "SUPPLY CHAIN",
      [
        "Developer",
        "Repository",
        "Branch",
        "Pull Request",
        "Workflow",
        "CI Pipeline",
        "Runner",
        "Secret",
        "Dependency",
        "Package Registry",
        "Build",
        "Artifact",
        "Container Image",
        "Artifact Registry",
        "Deployment",
        "Cloud Workload",
      ],
    ],
  ]
  return (
    <div className="builder-page">
      <header className="builder-header">
        <div>
          <div className="eyebrow">Build</div>
          <h1>Multi-Domain Scenario Builder</h1>
          <span>Draft · Infrastructure response exercise</span>
        </div>
        <div>
          <Button variant="secondary">Preview</Button>
          <Button variant="secondary">Save</Button>
          <Button icon="play">Run draft</Button>
        </div>
      </header>
      <div className="builder-layout">
        <aside className="builder-palette">
          <div className="search-field">
            <Icon name="search" />
            <input
              placeholder="Find entity or event..."
              aria-label="Find entity"
            />
          </div>
          {palette.map(([group, items]) => (
            <section key={group as string}>
              <span>{group as string}</span>
              <div>
                {(items as string[]).map((item) => (
                  <button key={item}>
                    <Icon
                      name={
                        group === "SECURITY"
                          ? "shield"
                          : group === "AI"
                            ? "terminal"
                            : group === "NETWORK"
                              ? "network"
                              : "server"
                      }
                      size={14}
                    />
                    {item}
                  </button>
                ))}
              </div>
            </section>
          ))}
        </aside>
        <main className="builder-canvas">
          <div className="builder-toolbar">
            <span>Scenario timeline</span>
            <button>−</button>
            <strong>100%</strong>
            <button>+</button>
            <button>
              <Icon name="settings" size={14} /> Snap to grid
            </button>
          </div>
          <div className="builder-ruler">
            {["T+00", "T+60", "T+120", "T+180", "T+240"].map((time) => (
              <span key={time}>{time}</span>
            ))}
          </div>
          {[
            ["NETOPS", ["Healthy baseline", "BGP degradation", "Failover"]],
            ["ITOPS", ["", "KPI degradation", "Recovery"]],
            ["OBSERVABILITY", ["", "API latency", "HTTP 5xx"]],
            ["SECOPS", ["", "", "Kerberoasting"]],
            ["AGENTIC AI", []],
          ].map(([domain, events]) => (
            <div className="builder-lane" key={domain as string}>
              <DomainPill domain={domain as Domain} />
              <div>
                {(events as string[]).map(
                  (event, index) =>
                    event && (
                      <button
                        className={selected === event ? "selected" : ""}
                        onClick={() => setSelected(event)}
                        key={event}
                        style={{ left: `${8 + index * 30}%` }}
                      >
                        {event}
                        <i />
                      </button>
                    ),
                )}
              </div>
            </div>
          ))}
        </main>
        <aside className="builder-inspector">
          <div className="panel-kicker">Inspector</div>
          <h2>{selected}</h2>
          <label>
            <span>Entity</span>
            <button>
              PE-RTR-01 <Icon name="chevron" size={13} />
            </button>
          </label>
          <label>
            <span>Event</span>
            <button>
              BGP Neighbor Down <Icon name="chevron" size={13} />
            </button>
          </label>
          <label>
            <span>Start time</span>
            <input defaultValue="T+60" />
          </label>
          <label>
            <span>Duration</span>
            <input defaultValue="60 seconds" />
          </label>
          <div className="causal-link">
            <span>CAUSES</span>
            <strong>checkout-api latency</strong>
            <button>Change relationship</button>
          </div>
          <div className="inspector-telemetry">
            <span>Telemetry</span>
            {["Syslog", "SNMP", "gNMI", "Flow"].map((item) => (
              <label key={item}>
                <input type="checkbox" defaultChecked />
                {item}
              </label>
            ))}
          </div>
          <Button variant="secondary">Advanced configuration</Button>
        </aside>
      </div>
    </div>
  )
}

function EvidenceBasedPipeline() {
  const [selected, setSelected] = useState("SNMP")
  const [restored, setRestored] = useState(false)
  const runtime = [
    ["Syslog", "LISTENING", "UDP/TCP 514", "2 sec", "Observed", "HEALTHY"],
    [
      "SNMP",
      restored ? "LISTENING" : "DEGRADED",
      "UDP 162",
      restored ? "1 sec" : "2 min",
      "Partial",
      restored ? "HEALTHY" : "DEGRADED",
    ],
    ["gNMI", "STREAMING", "TCP 57400", "1 sec", "Observed", "HEALTHY"],
    ["NetFlow", "RECEIVING", "UDP 2055", "3 sec", "Observed", "HEALTHY"],
    ["IPFIX", "RECEIVING", "UDP 4739", "3 sec", "Observed", "HEALTHY"],
    [
      "OpenTelemetry",
      "RECEIVING",
      "HTTP 4318 · gRPC 4317",
      "4 sec",
      "Observed",
      "HEALTHY",
    ],
  ]
  const current = runtime.find((row) => row[0] === selected)!
  return (
    <div className="page">
      <header className="page-header">
        <div>
          <div className="eyebrow">Observe · runtime evidence</div>
          <h1>Pipeline Health</h1>
          <p>
            Status reflects the latest listener, receiver and Splunk observation
            evidence—not configured expectations.
          </p>
        </div>
        <div className="header-status">
          <Status tone={restored ? "healthy" : "warning"}>
            {restored ? "6 pipelines verified" : "1 pipeline degraded"}
          </Status>
          <span>Last runtime probe 4 sec ago</span>
        </div>
      </header>
      <div className="pipeline-flow">
        <div className="flow-stage source">
          <span>01 · ENTERPRISE STATE</span>
          <div>
            <Icon name="layers" />
            <strong>Simulation runtime</strong>
            <small>1 active run</small>
          </div>
        </div>
        <Icon name="arrow" />
        <div className="flow-stage transports">
          <span>02 · TRANSPORTS</span>
          <div className="transport-icons">
            {["SYSLOG", "SNMP", "gNMI", "FLOW", "IPFIX", "OTLP"].map((item) => (
              <i key={item}>{item}</i>
            ))}
          </div>
        </div>
        <Icon name="arrow" />
        <div className="flow-stage">
          <span>03 · COLLECTION</span>
          <div>
            <Icon name="server" />
            <strong>Embedded services</strong>
            <small>{restored ? "6 ready" : "5 ready · 1 degraded"}</small>
          </div>
        </div>
        <Icon name="arrow" />
        <div className="flow-stage compact-stage">
          <span>04 · PROCESS</span>
          <div>
            <Icon name="layers" />
            <strong>Normalize</strong>
          </div>
        </div>
        <Icon name="arrow" />
        <div className="flow-stage splunk">
          <span>05 · DESTINATION</span>
          <div>
            <Icon name="database" />
            <strong>Splunk</strong>
            <small>Latest ACK 2 sec ago</small>
          </div>
        </div>
      </div>
      <div className="pipeline-layout">
        <main>
          <div className="section-head compact">
            <div>
              <div className="eyebrow">Transport runtime</div>
              <h2>Observed pipeline state</h2>
            </div>
            <span className="prototype-label">REALISTIC PROTOTYPE DATA</span>
          </div>
          <div className="runtime-table">
            <div className="runtime-head">
              <span>Pipeline</span>
              <span>Runtime</span>
              <span>Endpoint</span>
              <span>Last evidence</span>
              <span>Splunk</span>
              <span>State</span>
              <span />
            </div>
            {runtime.map((row) => (
              <button
                className={selected === row[0] ? "active" : ""}
                onClick={() => setSelected(row[0])}
                key={row[0]}
              >
                <span>
                  <Icon
                    name={row[0] === "OpenTelemetry" ? "pulse" : "radio"}
                    size={15}
                  />
                  <strong>{row[0]}</strong>
                </span>
                <code>{row[1]}</code>
                <code>{row[2]}</code>
                <span>{row[3]}</span>
                <span>{row[4]}</span>
                <Status tone={row[5] === "DEGRADED" ? "warning" : "healthy"}>
                  {row[5]}
                </Status>
                <Icon name="chevron" size={13} />
              </button>
            ))}
          </div>
        </main>
        <aside className="pipeline-detail phase2-pipeline-detail">
          <div className="panel-kicker">Diagnostic evidence</div>
          <div className="detail-service">
            <span>
              <Icon name="radio" />
            </span>
            <div>
              <h2>{current[0]}</h2>
              <Status tone={current[5] === "DEGRADED" ? "warning" : "healthy"}>
                {current[1]}
              </Status>
            </div>
          </div>
          {current[5] === "DEGRADED" ? (
            <>
              <div className="diagnostic-alert">
                <Icon name="shield" />
                <div>
                  <strong>Receiver evidence is stale</strong>
                  <p>
                    Listener is bound, but only 18 of 25 expected traps reached
                    the receiver. Splunk observation is partial.
                  </p>
                </div>
              </div>
              <EvidencePipeline partial compact />
              <dl>
                <div>
                  <dt>Last packet</dt>
                  <dd>2 min ago</dd>
                </div>
                <div>
                  <dt>Listener</dt>
                  <dd>
                    <code>0.0.0.0:162</code>
                  </dd>
                </div>
                <div>
                  <dt>Expected / observed</dt>
                  <dd>25 / 18</dd>
                </div>
                <div>
                  <dt>Failed stage</dt>
                  <dd>RECEIVER OBSERVED</dd>
                </div>
              </dl>
              <Button onClick={() => setRestored(true)}>
                Restore listener
              </Button>
            </>
          ) : (
            <>
              <div className="validation">
                <Icon name="check" />
                <div>
                  <strong>Runtime evidence restored</strong>
                  <span>Receiver and Splunk observation resumed.</span>
                </div>
              </div>
              <EvidencePipeline compact />
              <dl>
                <div>
                  <dt>Last activity</dt>
                  <dd>{current[3]}</dd>
                </div>
                <div>
                  <dt>Endpoint</dt>
                  <dd>
                    <code>{current[2]}</code>
                  </dd>
                </div>
                <div>
                  <dt>Splunk</dt>
                  <dd>{current[4]}</dd>
                </div>
              </dl>
              <Button variant="secondary">View diagnostic log</Button>
            </>
          )}
        </aside>
      </div>
    </div>
  )
}

type DashboardMaturity = "DESIGN PREVIEW" | "NOT VALIDATED" | "RESEARCH REQUIRED"
type DashboardView = "NOC" | "ENGINEER" | "EVIDENCE"
type ValidationStage = "PENDING" | "PASSED" | "FAILED" | "NOT APPLICABLE"
type DashboardScenario = {
  id: string
  name: string
  vendor: string
  product: string
  domain: Domain
  domainName: string
  description: string
  telemetry: string
  sourceContracts: string[]
  scenarioMaturity: "GOLDEN" | "RESEARCH REQUIRED"
  dashboardMaturity: DashboardMaturity
  recipe: string
  topology: string
  topologyReason: string
  entities: string[]
  kpis: [string, string, "info" | "warning" | "error" | "healthy"][]
  expected: string
  cim: "NOT_ESTABLISHED"
  recommended?: boolean
  recent?: boolean
}

const dashboardCatalog: DashboardScenario[] = [
  {
    id: "C100-ENT-001",
    name: "Campus Access Link Degradation",
    vendor: "Cisco",
    product: "Catalyst 9600 · IOS XE 17.17",
    domain: "NETOPS",
    domainName: "Enterprise Networking",
    description:
      "Campus uplink lifecycle from healthy state through link loss and recovery.",
    telemetry: "IOS XE interface syslog",
    sourceContracts: ["cisco-ios-xe-interface-syslog"],
    scenarioMaturity: "GOLDEN",
    dashboardMaturity: "DESIGN PREVIEW",
    recipe: "CAMPUS HEALTH",
    topology: "Native Network Graph",
    topologyReason:
      "A compact device-to-uplink dependency does not require an external visualization.",
    entities: [
      "catalyst-9600-campus01",
      "GigabitEthernet0/1",
      "campus-service",
    ],
    kpis: [
      ["LINK STATE", "DOWN", "error"],
      ["AFFECTED ENTITIES", "2", "warning"],
      ["RECOVERY", "IN PROGRESS", "info"],
      ["OBSERVATIONS", "4 expected", "info"],
    ],
    expected:
      "The modeled interface reports down during incident and up during recovery.",
    cim: "NOT_ESTABLISHED",
    recommended: true,
  },
  {
    id: "C100-SP-001",
    name: "IOS XR Interface Degradation",
    vendor: "Cisco",
    product: "Cisco 8000 · IOS XR",
    domain: "NETOPS",
    domainName: "Service Provider & Carrier",
    description:
      "Provider-edge interface degradation correlated across documented Syslog, SNMP, and gNMI sources.",
    telemetry: "Syslog · SNMP · gNMI",
    sourceContracts: [
      "cisco-ios-xr-interface-syslog",
      "ietf-snmpv2c-ifmib",
      "openconfig-gnmi-interfaces",
    ],
    scenarioMaturity: "GOLDEN",
    dashboardMaturity: "NOT VALIDATED",
    recipe: "ROUTING HEALTH",
    topology: "Network Diagram Viz · App 4438",
    topologyReason:
      "A fixed provider-edge hierarchy benefits from directional links; installation and engine compatibility require validation.",
    entities: ["cisco-asr9k-pe1", "HundredGigE0/0/0/1", "carrier-service"],
    kpis: [
      ["INTERFACE STATE", "DEGRADED", "error"],
      ["PACKET LOSS", "8% modeled", "warning"],
      ["PATH HEALTH", "IMPAIRED", "warning"],
      ["NATIVE SOURCES", "3", "info"],
    ],
    expected:
      "All documented channels describe the same modeled interface lifecycle.",
    cim: "NOT_ESTABLISHED",
    recommended: true,
    recent: true,
  },
  {
    id: "C100-DC-001",
    name: "Nexus Fabric Uplink Degradation",
    vendor: "Cisco",
    product: "Nexus 9000 · NX-OS",
    domain: "NETOPS",
    domainName: "Data Center & AI Cloud",
    description:
      "Fabric uplink failure and recovery using bounded NX-OS ETHPORT structures.",
    telemetry: "NX-OS interface syslog",
    sourceContracts: ["cisco-nx-os-interface-syslog"],
    scenarioMaturity: "GOLDEN",
    dashboardMaturity: "DESIGN PREVIEW",
    recipe: "DATA CENTER FABRIC",
    topology: "Topology Visualization · App 9051",
    topologyReason:
      "Leaf-to-service relationships suit a fabric view; dependency availability is not assumed.",
    entities: ["nexus-9000-leaf01", "Ethernet1/31", "east-west-service"],
    kpis: [
      ["FABRIC LINK", "DOWN", "error"],
      ["DEPENDENCIES", "2 affected", "warning"],
      ["RECOVERY", "PENDING", "info"],
      ["OBSERVATIONS", "4 expected", "info"],
    ],
    expected:
      "The interface reports IF_DOWN_LINK_FAILURE and later IF_UP in Layer3.",
    cim: "NOT_ESTABLISHED",
    recommended: true,
  },
  {
    id: "C100-SEC-001",
    name: "Secure Firewall Suspicious Connection Burst",
    vendor: "Cisco",
    product: "Secure Firewall ASA",
    domain: "SECOPS",
    domainName: "Security & SASE",
    description:
      "Modeled connection-rate increase using documented ASA connection lifecycle messages without attack attribution.",
    telemetry: "ASA 302013 · 302014 syslog",
    sourceContracts: ["cisco-asa-connection-syslog"],
    scenarioMaturity: "GOLDEN",
    dashboardMaturity: "NOT VALIDATED",
    recipe: "SECURITY POLICY",
    topology: "Native Network Graph",
    topologyReason:
      "The reference needs entity and evidence relationships, not a decorative attack graph.",
    entities: ["asa-edge01", "outside", "modeled-destination"],
    kpis: [
      ["CONNECTION EVENTS", "11 expected", "warning"],
      ["ACTION", "OBSERVED", "info"],
      ["ATTRIBUTION", "NOT ASSERTED", "healthy"],
      ["RECOVERY", "TEARDOWN", "info"],
    ],
    expected:
      "Connection creation volume rises and a teardown appears during recovery.",
    cim: "NOT_ESTABLISHED",
    recommended: true,
    recent: true,
  },
  {
    id: "C100-CRI-002",
    name: "Telecom Operations Network Degradation",
    vendor: "Cisco + NetSpout",
    product: "IOS XE · IOS XR composition",
    domain: "ITOPS",
    domainName: "Critical Infrastructure / Cross-Domain",
    description:
      "One modeled path condition propagates across operations and carrier dependencies on a shared simulation clock.",
    telemetry: "IOS XE syslog · IOS XR syslog",
    sourceContracts: [
      "cisco-ios-xe-interface-syslog",
      "cisco-ios-xr-interface-syslog",
    ],
    scenarioMaturity: "GOLDEN",
    dashboardMaturity: "DESIGN PREVIEW",
    recipe: "CROSS-DOMAIN INCIDENT",
    topology: "Flow Map Viz · App 4657",
    topologyReason:
      "Causal propagation is primary; a supported native graph remains the explicit fallback.",
    entities: [
      "catalyst-9600-operations01",
      "cisco-asr9k-pe1",
      "critical-service",
    ],
    kpis: [
      ["ROOT CONDITION", "PATH DEGRADED", "error"],
      ["DOMAINS", "2", "warning"],
      ["DEPENDENCIES", "3", "warning"],
      ["RECOVERY", "COORDINATED", "info"],
    ],
    expected:
      "Both independent source structures follow one ordered modeled lifecycle.",
    cim: "NOT_ESTABLISHED",
    recommended: true,
  },
  {
    id: "C100-SP-020",
    name: "PE-CE Policy Mismatch",
    vendor: "Cisco",
    product: "IOS XR",
    domain: "NETOPS",
    domainName: "Service Provider & Carrier",
    description:
      "Authoritative telemetry, transport applicability, and Splunk relationships remain unresolved.",
    telemetry: "Verified sources pending",
    sourceContracts: [],
    scenarioMaturity: "RESEARCH REQUIRED",
    dashboardMaturity: "RESEARCH REQUIRED",
    recipe: "ROUTING HEALTH",
    topology: "NOT VERIFIED",
    topologyReason:
      "No visualization is selected until the source and data-shape contracts are established.",
    entities: [],
    kpis: [],
    expected: "No dashboard finding is asserted.",
    cim: "NOT_ESTABLISHED",
  },
]

function DashboardMaturityBadge({ maturity }: { maturity: DashboardMaturity }) {
  const tone =
    maturity === "NOT VALIDATED" || maturity === "RESEARCH REQUIRED"
      ? "amber"
      : "neutral"
  return <Badge tone={tone}>{maturity}</Badge>
}

function DashboardGallery({
  navigate,
  selectScenario,
}: {
  navigate: (page: Page) => void
  selectScenario: (id: string) => void
}) {
  const [query, setQuery] = useState("")
  const [domain, setDomain] = useState<Domain | "ALL">("ALL")
  const [status, setStatus] = useState("ALL")
  const [layout, setLayout] = useState<"CARD" | "TABLE">("CARD")
  const visible = dashboardCatalog.filter(
    (item) =>
      (domain === "ALL" || item.domain === domain) &&
      (status === "ALL" || item.dashboardMaturity === status) &&
      `${item.id} ${item.name} ${item.vendor} ${item.product} ${item.telemetry}`
        .toLowerCase()
        .includes(query.toLowerCase()),
  )
  const open = (item: DashboardScenario) => {
    selectScenario(item.id)
    navigate("dashboard")
  }
  return (
    <div className="page dashboard-gallery">
      <header className="page-header">
        <div>
          <div className="eyebrow">Scenario-aware operational experiences</div>
          <h1>Dashboard Gallery</h1>
          <p>
            Find a scenario by ID, domain, product, maturity, or telemetry.
            Scenario maturity and dashboard validation remain independent.
          </p>
        </div>
        <div className="gallery-summary">
          <strong>0</strong>
          <span>dashboard-ready references</span>
          <Status tone="warning">Validation required</Status>
        </div>
      </header>
      <section className="dashboard-reference-rail">
        <div>
          <span>VALIDATED REFERENCE SCENARIOS</span>
          <strong>Five Phase 8C Golden scenarios</strong>
          <small>
            Dashboard status remains NOT VALIDATED or DESIGN PREVIEW
          </small>
        </div>
        {dashboardCatalog
          .filter((item) => item.recommended)
          .map((item) => (
            <button key={item.id} onClick={() => open(item)}>
              <code>{item.id}</code>
              <span>{item.domainName}</span>
              <DashboardMaturityBadge maturity={item.dashboardMaturity} />
            </button>
          ))}
      </section>
      <section className="dashboard-recipe-strip">
        <div>
          <Icon name="layers" />
          <span>
            <strong>Scenario metadata</strong>
            <small>Intent · entities · expected findings</small>
          </span>
        </div>
        <Icon name="arrow" />
        <div>
          <Icon name="shield" />
          <span>
            <strong>Verified contracts</strong>
            <small>Native · Splunk · NetSpout</small>
          </span>
        </div>
        <Icon name="arrow" />
        <div>
          <Icon name="grid" />
          <span>
            <strong>Dashboard recipe</strong>
            <small>Auto-generated or curated</small>
          </span>
        </div>
        <Icon name="arrow" />
        <div>
          <Icon name="check" />
          <span>
            <strong>Validation chain</strong>
            <small>Required before Dashboard Ready</small>
          </span>
        </div>
      </section>
      <DomainSelector value={domain} onChange={setDomain} />
      <div className="dashboard-tools">
        <div className="search-field">
          <Icon name="search" />
          <input
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder="Search scenario ID, name, vendor, product, telemetry..."
            aria-label="Search dashboards"
          />
        </div>
        {["ALL", "DESIGN PREVIEW", "NOT VALIDATED", "RESEARCH REQUIRED"].map(
          (item) => (
            <button
              className={status === item ? "active" : ""}
              onClick={() => setStatus(item)}
              key={item}
            >
              {item}
            </button>
          ),
        )}
        <div className="dashboard-layout-toggle">
          <button
            className={layout === "CARD" ? "active" : ""}
            onClick={() => setLayout("CARD")}
            aria-label="Card view"
          >
            <Icon name="grid" size={13} />
          </button>
          <button
            className={layout === "TABLE" ? "active" : ""}
            onClick={() => setLayout("TABLE")}
            aria-label="Table view"
          >
            <Icon name="list" size={13} />
          </button>
        </div>
      </div>
      <div className="results-meta">
        <strong>{visible.length} scenario dashboards</strong>
        <span>Prototype interactions · no live Splunk deployment</span>
      </div>
      {layout === "CARD" ? (
        <div className="dashboard-card-grid">
          {visible.map((item) => (
            <article className="dashboard-card" key={item.id}>
              <header>
                <div className="dashboard-card__icon">
                  <Icon
                    name={
                      item.domain === "SECOPS"
                        ? "shield"
                        : item.domain === "ITOPS"
                          ? "layers"
                          : "network"
                    }
                  />
                </div>
                <div>
                  <div className="domain-cell">
                    <DomainPill domain={item.domain} />
                    <Badge tone="green">{item.scenarioMaturity}</Badge>
                  </div>
                  <h2>{item.name}</h2>
                  <span>
                    <code>{item.id}</code> · {item.vendor} · {item.product}
                  </span>
                </div>
                <DashboardMaturityBadge maturity={item.dashboardMaturity} />
              </header>
              <p>{item.description}</p>
              <dl>
                <div>
                  <dt>Recipe</dt>
                  <dd>{item.recipe}</dd>
                </div>
                <div>
                  <dt>Telemetry</dt>
                  <dd>{item.telemetry}</dd>
                </div>
                <div>
                  <dt>CIM</dt>
                  <dd>{item.cim}</dd>
                </div>
              </dl>
              <footer>
                {item.dashboardMaturity === "RESEARCH REQUIRED" ? (
                  <>
                    <Button variant="secondary" onClick={() => open(item)}>
                      View missing evidence
                    </Button>
                    <Button disabled>Run unavailable</Button>
                  </>
                ) : (
                  <>
                    <Button variant="ghost">Run scenario</Button>
                    <Button variant="secondary">View evidence</Button>
                    <Button onClick={() => open(item)} icon="arrow">
                      {item.dashboardMaturity === "DESIGN PREVIEW"
                        ? "View design preview"
                        : "Open dashboard"}
                    </Button>
                  </>
                )}
              </footer>
            </article>
          ))}
        </div>
      ) : (
        <div className="dashboard-compact-table">
          <div>
            <span>Scenario</span>
            <span>Domain / product</span>
            <span>Scenario</span>
            <span>Dashboard</span>
            <span>CIM</span>
            <span>Actions</span>
          </div>
          {visible.map((item) => (
            <div key={item.id}>
              <span>
                <code>{item.id}</code>
                <strong>{item.name}</strong>
              </span>
              <span>
                {item.domainName}
                <small>{item.product}</small>
              </span>
              <Badge tone="green">{item.scenarioMaturity}</Badge>
              <DashboardMaturityBadge maturity={item.dashboardMaturity} />
              <span>{item.cim}</span>
              <Button
                disabled={item.dashboardMaturity === "RESEARCH REQUIRED"}
                onClick={() => open(item)}
              >
                {item.dashboardMaturity === "RESEARCH REQUIRED"
                  ? "Unavailable"
                  : "Open"}
              </Button>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

function MiniTrend({
  tone = "info",
}: {
  tone?: "info" | "warning" | "error" | "healthy"
}) {
  return (
    <svg
      className={`mini-trend trend-${tone}`}
      viewBox="0 0 120 28"
      preserveAspectRatio="none"
      aria-label="Illustrative trend"
    >
      <path d="M1 23 L18 21 L34 22 L51 15 L68 17 L85 8 L103 12 L119 4" />
    </svg>
  )
}

function DashboardTopology({
  scenario = dashboardCatalog[0],
  selected,
  setSelected,
  onInvestigate = () => undefined,
}: {
  scenario?: DashboardScenario
  selected: string
  setSelected: (value: string) => void
  onInvestigate?: () => void
}) {
  return (
    <div className="dashboard-topology">
      <div className="topology-stage">
        {scenario.entities.map((name, index) => (
          <div className="topology-step" key={name}>
            <button
              className={`dashboard-node node-${
                index === 0 ? "critical" : index === 1 ? "warning" : "healthy"
              } ${selected === name ? "selected" : ""}`}
              onClick={() => setSelected(name)}
            >
              <span>
                <Icon
                  name={
                    index === scenario.entities.length - 1
                      ? "server"
                      : "network"
                  }
                />
              </span>
              <strong>{name}</strong>
              <small>
                {index === 0
                  ? "ROOT CONDITION"
                  : index === scenario.entities.length - 1
                    ? "SERVICE / OBSERVER"
                    : "DEPENDENCY"}
              </small>
            </button>
            {index < scenario.entities.length - 1 && (
              <button
                className={`dashboard-link ${
                  index === 0 ? "failed" : "rerouted"
                }`}
                onClick={() =>
                  setSelected(
                    `${scenario.entities[index]} → ${scenario.entities[index + 1]}`,
                  )
                }
              >
                <i />
                <small>{index === 0 ? "STATE CHANGE" : "PROPAGATES"}</small>
              </button>
            )}
          </div>
        ))}
      </div>
      <div className="topology-detail">
        <div>
          <span>Selected entity / path</span>
          <strong>{selected}</strong>
        </div>
        <div>
          <span>Related telemetry</span>
          <strong>{scenario.telemetry}</strong>
        </div>
        <div>
          <span>Expected finding</span>
          <strong>{scenario.expected}</strong>
        </div>
        <button onClick={onInvestigate}>
          Open investigation <Icon name="arrow" size={13} />
        </button>
      </div>
    </div>
  )
}

function ScenarioDashboard({
  navigate,
  advanced,
}: {
  navigate: (page: Page) => void
  advanced: boolean
}) {
  const [view, setView] = useState<"NOC" | "ENGINEER" | "EVIDENCE">("NOC")
  const [selected, setSelected] = useState("dc-core-01")
  const [filtered, setFiltered] = useState(false)
  return (
    <div className="scenario-dashboard">
      <header className="dashboard-command">
        <div className="dashboard-command__title">
          <button
            onClick={() => navigate("dashboards")}
            aria-label="Back to Dashboard Gallery"
          >
            ←
          </button>
          <div>
            <span>NETOPS · CISCO · IOS XR</span>
            <strong>Core Datacenter / BGP Failure</strong>
          </div>
          <Status tone="warning">RECOVERING</Status>
          <DashboardMaturityBadge maturity="DESIGN PREVIEW" />
        </div>
        <div className="dashboard-command__meta">
          <span>
            Run <code>NS-DEMO-00481</code>
          </span>
          <span>Last 15 minutes</span>
          <Status>Splunk observed</Status>
        </div>
        <div className="dashboard-command__actions">
          <Button variant="ghost">Reset</Button>
          <Button variant="secondary">Replay</Button>
          <Button variant="secondary" onClick={() => navigate("investigation")}>
            Investigation
          </Button>
          <Button icon="external">Open in Splunk</Button>
        </div>
      </header>
      <div className="dashboard-subnav">
        <div className="dashboard-view-toggle">
          {(["NOC", "ENGINEER", "EVIDENCE"] as const).map((item) => (
            <button
              className={view === item ? "active" : ""}
              onClick={() => setView(item)}
              key={item}
            >
              {item}
            </button>
          ))}
        </div>
        <div className="dashboard-filters">
          {filtered && (
            <span>
              Entity: dc-core-01{" "}
              <button onClick={() => setFiltered(false)}>×</button>
            </span>
          )}
          <button onClick={() => setFiltered(true)}>
            <Icon name="filter" size={13} /> Filter dashboard
          </button>
        </div>
        <span className="illustrative-label">ILLUSTRATIVE DASHBOARD DATA</span>
      </div>
      {view === "NOC" && (
        <main className="dashboard-canvas">
          <section className="kpi-row">
            {[
              ["INCIDENT STATE", "BGP withdrawal", "error"],
              ["AFFECTED ENTITIES", "3", "warning"],
              ["AVAILABILITY", "98.72%", "warning"],
              ["PACKET LOSS", "4.8%", "error"],
              ["LATENCY", "86 ms", "warning"],
              ["RECOVERY", "62%", "info"],
            ].map(([label, value, tone]) => (
              <article className={`kpi-tile kpi-${tone}`} key={label}>
                <span>{label}</span>
                <strong>{value}</strong>
                <small>
                  {label === "RECOVERY"
                    ? "Failover validation active"
                    : label === "INCIDENT STATE"
                      ? "Started T+02:14"
                      : "vs baseline"}
                </small>
                <MiniTrend
                  tone={tone as "info" | "warning" | "error" | "healthy"}
                />
              </article>
            ))}
          </section>
          <section className="dashboard-primary-grid">
            <article className="dark-panel topology-dashboard-panel">
              <header>
                <div>
                  <span>PRIMARY TOPOLOGY</span>
                  <strong>Failure propagation</strong>
                </div>
                <div>
                  <Badge tone="blue">HIERARCHICAL TOPOLOGY</Badge>
                  <button>
                    <Icon name="more" />
                  </button>
                </div>
              </header>
              <DashboardTopology
                selected={selected}
                setSelected={(value) => {
                  setSelected(value)
                  setFiltered(true)
                }}
              />
            </article>
            <article className="dark-panel incident-panel">
              <header>
                <div>
                  <span>ACTIVE INCIDENT</span>
                  <strong>Routing adjacency lost</strong>
                </div>
                <Status tone="error">HIGH</Status>
              </header>
              <div className="root-cause">
                <span>
                  <Icon name="shield" />
                </span>
                <div>
                  <small>PROBABLE ROOT CAUSE</small>
                  <strong>Provider-facing interface loss on dc-core-01</strong>
                  <p>
                    Evidence chain links interface state change to route
                    withdrawal and service degradation.
                  </p>
                </div>
              </div>
              <dl>
                <div>
                  <dt>Started</dt>
                  <dd>T+02:14</dd>
                </div>
                <div>
                  <dt>Affected</dt>
                  <dd>2 sites · 1 service</dd>
                </div>
                <div>
                  <dt>Current path</dt>
                  <dd>Backup · degraded</dd>
                </div>
                <div>
                  <dt>Recovery</dt>
                  <dd>Validation in progress</dd>
                </div>
              </dl>
              <Button
                variant="secondary"
                onClick={() => navigate("investigation")}
              >
                Open root-cause investigation
              </Button>
            </article>
          </section>
          <section className="dashboard-analysis-grid">
            <article className="dark-panel metric-panel">
              <header>
                <div>
                  <span>BEHAVIOR</span>
                  <strong>Availability and packet loss</strong>
                </div>
                <Badge tone="neutral">SHARED BASE SEARCH</Badge>
              </header>
              <div className="large-chart">
                <div className="chart-y">
                  <span>100%</span>
                  <span>50%</span>
                  <span>0%</span>
                </div>
                <svg
                  viewBox="0 0 700 170"
                  preserveAspectRatio="none"
                  aria-label="Illustrative availability and packet-loss trends"
                >
                  <path
                    className="availability-area"
                    d="M0 20 L110 22 L220 24 L300 126 L390 111 L490 83 L590 55 L700 31 L700 170 L0 170 Z"
                  />
                  <path
                    className="availability-line"
                    d="M0 20 L110 22 L220 24 L300 126 L390 111 L490 83 L590 55 L700 31"
                  />
                  <path
                    className="loss-line"
                    d="M0 150 L220 148 L300 58 L390 72 L490 104 L590 125 L700 142"
                  />
                </svg>
                <div className="chart-x">
                  {["T-10", "T-8", "T-6", "FAULT", "T-2", "NOW"].map((item) => (
                    <span key={item}>{item}</span>
                  ))}
                </div>
              </div>
            </article>
            <article className="dark-panel impact-panel">
              <header>
                <div>
                  <span>IMPACT</span>
                  <strong>Affected entities</strong>
                </div>
                <button>View all</button>
              </header>
              {[
                ["dc-core-01", "Router", "CRITICAL"],
                ["dc-dist-01", "Distribution", "DEGRADED"],
                ["checkout-api", "Service", "DEGRADED"],
                ["branch-01.lab.example", "Site", "RECOVERING"],
              ].map(([entity, type, state]) => (
                <button
                  onClick={() => {
                    setSelected(entity)
                    setFiltered(true)
                  }}
                  key={entity}
                >
                  <span
                    className={`entity-state state-${state.toLowerCase()}`}
                  />
                  <span>
                    <strong>{entity}</strong>
                    <small>{type}</small>
                  </span>
                  <em>{state}</em>
                  <Icon name="chevron" size={13} />
                </button>
              ))}
            </article>
          </section>
          <section className="dark-panel dashboard-timeline-panel">
            <header>
              <div>
                <span>MAJOR TIMELINE</span>
                <strong>Incident and recovery sequence</strong>
              </div>
              <button onClick={() => navigate("timeline")}>
                Expand timeline <Icon name="external" size={13} />
              </button>
            </header>
            <div className="dark-timeline">
              {[
                ["14:31:02", "INTERFACE", "Provider link down", "critical"],
                ["14:31:06", "ROUTING", "BGP routes withdrawn", "critical"],
                ["14:31:18", "IMPACT", "Checkout latency elevated", "warning"],
                ["14:31:48", "FAILOVER", "Backup path selected", "info"],
                ["14:33:12", "RECOVERY", "Availability improving", "healthy"],
              ].map(([time, type, event, tone], index) => (
                <div key={time}>
                  <i className={tone} />
                  <time>{time}</time>
                  <span>{type}</span>
                  <strong>{event}</strong>
                  {index < 4 && <b />}
                </div>
              ))}
            </div>
          </section>
        </main>
      )}
      {view === "ENGINEER" && (
        <main className="dashboard-canvas engineer-view">
          <section className="engineer-summary">
            <div>
              <span>WORKING THEORY</span>
              <strong>
                Interface loss triggered route withdrawal; backup path has
                elevated loss.
              </strong>
            </div>
            <Button onClick={() => navigate("investigation")}>
              Open troubleshooting workflow
            </Button>
          </section>
          <section className="dashboard-primary-grid">
            <article className="dark-panel topology-dashboard-panel">
              <header>
                <div>
                  <span>DETAILED TOPOLOGY</span>
                  <strong>Routing and service dependencies</strong>
                </div>
                <Badge tone="blue">NETWORK DIAGRAM VIZ</Badge>
              </header>
              <DashboardTopology
                selected={selected}
                setSelected={setSelected}
              />
            </article>
            <article className="dark-panel recommendation-panel">
              <header>
                <div>
                  <span>RECOMMENDED VISUALIZATION</span>
                  <strong>Network Diagram Viz</strong>
                </div>
                <Status>INSTALLED</Status>
              </header>
              <p>
                This scenario contains a fixed datacenter hierarchy, known
                interfaces and directional path changes.
              </p>
              <dl>
                <div>
                  <dt>Alternative</dt>
                  <dd>Native Network Graph</dd>
                </div>
                <div>
                  <dt>Selection</dt>
                  <dd>Recipe recommended</dd>
                </div>
                <div>
                  <dt>Layout</dt>
                  <dd>Curated hint</dd>
                </div>
              </dl>
              <Button variant="secondary">Change visualization</Button>
            </article>
          </section>
          <section className="engineer-metrics">
            {[
              ["Interface state", "Provider link", "DOWN"],
              ["BGP peers", "1 of 2", "DEGRADED"],
              ["Routes withdrawn", "14", "OBSERVED"],
              ["Backup loss", "4.8%", "ELEVATED"],
            ].map(([label, value, state]) => (
              <article className="dark-panel" key={label}>
                <span>{label}</span>
                <strong>{value}</strong>
                <small>{state}</small>
              </article>
            ))}
          </section>
          <section className="dark-panel engineer-table">
            <header>
              <div>
                <span>CORRELATED TELEMETRY</span>
                <strong>Expected vs observed</strong>
              </div>
              <Button variant="secondary">Production-portable SPL</Button>
            </header>
            <div className="dark-table">
              <div>
                <span>Time</span>
                <span>Entity</span>
                <span>Observation</span>
                <span>Evidence state</span>
              </div>
              {[
                [
                  "14:31:02",
                  "dc-core-01",
                  "Interface operational state changed",
                  "STANDARD VERIFIED",
                ],
                [
                  "14:31:06",
                  "dc-core-01",
                  "Routing withdrawal observed",
                  "DATA VALIDATED",
                ],
                [
                  "14:31:18",
                  "checkout-api",
                  "Latency exceeded scenario threshold",
                  "MODELED VALUE",
                ],
                [
                  "14:33:12",
                  "branch-01.lab.example",
                  "Traffic shifted to backup path",
                  "SPLUNK OBSERVED",
                ],
              ].map((row) => (
                <button key={row[0]}>
                  {row.map((cell, index) =>
                    index === 3 ? (
                      <Badge
                        tone={cell === "MODELED VALUE" ? "blue" : "green"}
                        key={cell}
                      >
                        {cell}
                      </Badge>
                    ) : (
                      <span key={cell}>{cell}</span>
                    ),
                  )}
                </button>
              ))}
            </div>
          </section>
        </main>
      )}
      {view === "EVIDENCE" && (
        <main className="dashboard-canvas evidence-view">
          <section className="evidence-hero">
            <div>
              <span>VALIDATION POSITION</span>
              <strong>Design preview with illustrative panel values</strong>
              <p>
                Contracts and validation evidence are authoritative; values in
                this prototype dashboard are explicitly illustrative.
              </p>
            </div>
            <DashboardMaturityBadge maturity="DESIGN PREVIEW" />
          </section>
          <section className="dark-panel validation-chain">
            <header>
              <div>
                <span>DASHBOARD VALIDATION</span>
                <strong>Generation to drilldown</strong>
              </div>
              <Status tone="warning">Validation pending</Status>
            </header>
            <div>
              {[
                "SPL generated",
                "SPL parsed",
                "Search executed",
                "Data returned",
                "Fields present",
                "Shape valid",
                "Rendered",
                "Drilldown valid",
                "Dashboard readiness pending",
              ].map((item) => (
                <span key={item}>
                  <i>
                    <Icon name="check" size={11} />
                  </i>
                  {item}
                </span>
              ))}
            </div>
          </section>
          <section className="evidence-dashboard-grid">
            <article className="dark-panel contract-stack">
              <header>
                <div>
                  <span>VERIFIED CONTRACTS</span>
                  <strong>Source of truth</strong>
                </div>
              </header>
              {[
                [
                  "NATIVE CONTRACT",
                  "Open standard source definition",
                  "STANDARD VERIFIED",
                ],
                [
                  "SPLUNK CONTRACT",
                  "Observed parsing and search behavior",
                  "SPLUNK VERIFIED",
                ],
                [
                  "NETSPOUT CONTRACT",
                  "Scenario intent and modeled values",
                  "NETSPOUT DEFINED",
                ],
              ].map(([type, description, state]) => (
                <button key={type}>
                  <span>
                    <strong>{type}</strong>
                    <small>{description}</small>
                  </span>
                  <Badge
                    tone={state === "NETSPOUT DEFINED" ? "purple" : "green"}
                  >
                    {state}
                  </Badge>
                  <Icon name="chevron" size={13} />
                </button>
              ))}
            </article>
            <article className="dark-panel observation-stages">
              <header>
                <div>
                  <span>TELEMETRY STATE</span>
                  <strong>Observed delivery chain</strong>
                </div>
              </header>
              {[
                "Data generated",
                "Data sent",
                "Receiver observed",
                "Splunk dispatched",
                "Splunk observed",
                "Validated",
              ].map((item, index) => (
                <div key={item}>
                  <i>
                    <Icon name="check" size={11} />
                  </i>
                  <span>
                    <strong>{item}</strong>
                    <small>
                      {index < 4
                        ? "Complete"
                        : index === 4
                          ? "184 events · example run"
                          : "Expected fields present"}
                    </small>
                  </span>
                  {index < 5 && <b />}
                </div>
              ))}
            </article>
          </section>
          <section className="dark-panel evidence-table">
            <header>
              <div>
                <span>FIELD EVIDENCE</span>
                <strong>Observed and normalized preview</strong>
              </div>
              <Badge tone="amber">ILLUSTRATIVE VALUES</Badge>
            </header>
            <div className="dark-table">
              <div>
                <span>Field</span>
                <span>Example value</span>
                <span>Authority</span>
                <span>Validation</span>
              </div>
              {[
                [
                  "entity",
                  "dc-core-01.lab.example",
                  "NETSPOUT DEFINED",
                  "VALIDATED",
                ],
                ["network.transport", "tcp", "STANDARD VERIFIED", "OBSERVED"],
                [
                  "scenario_id",
                  "bgp-dc-failure",
                  "NETSPOUT DEFINED",
                  "VALIDATED",
                ],
                [
                  "vendor_field_example",
                  "Not asserted",
                  "RESEARCH REQUIRED",
                  "NOT VALIDATED",
                ],
              ].map((row) => (
                <button key={row[0]}>
                  {row.map((cell, index) =>
                    index > 1 ? (
                      <Badge
                        tone={
                          cell.includes("RESEARCH") || cell.includes("NOT")
                            ? "amber"
                            : cell.includes("NETSPOUT")
                              ? "purple"
                              : "green"
                        }
                        key={cell}
                      >
                        {cell}
                      </Badge>
                    ) : (
                      <code key={cell}>{cell}</code>
                    ),
                  )}
                </button>
              ))}
            </div>
          </section>
        </main>
      )}
      {advanced && (
        <aside className="dashboard-inspector">
          <header>
            <div>
              <span>ADVANCED DASHBOARD INSPECTOR</span>
              <strong>Failure propagation · topology panel</strong>
            </div>
            <button aria-label="Close inspector">×</button>
          </header>
          <nav>
            {[
              "OVERVIEW",
              "VISUALIZATION",
              "DATA",
              "SPL",
              "FIELDS",
              "CIM",
              "TOKENS",
              "DEPENDENCIES",
              "VALIDATION",
              "PROVENANCE",
            ].map((item, index) => (
              <button className={index === 0 ? "active" : ""} key={item}>
                {item}
              </button>
            ))}
          </nav>
          <dl>
            <div>
              <dt>Visualization</dt>
              <dd>Network Diagram Viz</dd>
            </div>
            <div>
              <dt>Base search</dt>
              <dd>
                <code>base_routing_health</code>
              </dd>
            </div>
            <div>
              <dt>Tokens</dt>
              <dd>
                <code>entity · site · incident</code>
              </dd>
            </div>
            <div>
              <dt>Dependency</dt>
              <dd>
                <Status>Installed</Status>
              </dd>
            </div>
            <div>
              <dt>Data shape</dt>
              <dd>Nodes + directed links</dd>
            </div>
            <div>
              <dt>Validation</dt>
              <dd>
                <Status>Rendered and drilled down</Status>
              </dd>
            </div>
          </dl>
          <div className="inspector-note">
            <Icon name="shield" />
            <span>
              <strong>Search reuse enabled</strong>Six panels derive from two
              shared base searches.
            </span>
          </div>
        </aside>
      )}
    </div>
  )
}

const validationLabels = [
  "Generated",
  "SPL Checked",
  "Search Executed",
  "Fields Verified",
  "Data Shape Verified",
  "Visualization Rendered",
  "Drilldowns Tested",
  "Dashboard Ready",
]

function DashboardValidationChain({ stages }: { stages: ValidationStage[] }) {
  return (
    <div className="dashboard-validation-chain">
      {validationLabels.map((label, index) => (
        <div
          className={`validation-step validation-${stages[index].toLowerCase().replace(/\s+/g, "-")}`}
          key={label}
        >
          <i>
            {stages[index] === "PASSED" ? (
              <Icon name="check" size={10} />
            ) : (
              index + 1
            )}
          </i>
          <span>
            <strong>{label}</strong>
            <small>{stages[index]}</small>
          </span>
          {index < validationLabels.length - 1 && <b />}
        </div>
      ))}
    </div>
  )
}

function DashboardInspector({
  scenario,
  tab,
  setTab,
  close,
}: {
  scenario: DashboardScenario
  tab: string
  setTab: (tab: string) => void
  close: () => void
}) {
  const tabs = [
    "OVERVIEW",
    "VISUALIZATION",
    "DATA",
    "SPL",
    "FIELDS",
    "CIM",
    "TOKENS",
    "DEPENDENCIES",
    "VALIDATION",
  ]
  const rows: Record<string, [string, string][]> = {
    OVERVIEW: [
      ["Purpose", scenario.expected],
      ["Recipe", scenario.recipe],
      ["Composition", "AUTO GENERATED · curated hints supported"],
      ["Dashboard status", scenario.dashboardMaturity],
    ],
    VISUALIZATION: [
      ["Selected", scenario.topology],
      ["Why selected", scenario.topologyReason],
      ["Alternative", "Native Network Graph"],
      ["Compatibility", "NOT VERIFIED"],
    ],
    DATA: [
      [
        "Source contracts",
        scenario.sourceContracts.join(" · ") || "NOT VERIFIED",
      ],
      ["Expected shape", "Scenario-defined entities + ordered observations"],
      ["Index", "ILLUSTRATIVE · backend integration required"],
      ["Sourcetype", scenario.telemetry],
    ],
    SPL: [
      ["Base search", "NOT VERIFIED"],
      ["Panel search", "NOT VERIFIED"],
      ["Search execution", "PENDING"],
      ["Portability", "Requires contract-supplied production recipe"],
    ],
    FIELDS: [
      ["Required fields", "NOT VERIFIED in dashboard context"],
      ["Vendor fields", "No fields invented"],
      ["Modeled values", "Clearly labeled illustrative"],
      ["Data shape", "PENDING"],
    ],
    CIM: [
      ["CIM status", scenario.cim],
      ["Data model", "NOT ESTABLISHED"],
      ["Runtime validation", "NOT ESTABLISHED"],
      ["Design behavior", "No inferred mapping"],
    ],
    TOKENS: [
      ["Prototype filters", "Entity · path · event · time range"],
      ["Production token names", "NOT ESTABLISHED"],
      ["Clear behavior", "Remove chips and restore scenario scope"],
      ["Drilldowns", "Prototype interaction only"],
    ],
    DEPENDENCIES: [
      ["Primary visualization", scenario.topology],
      ["Installation", "NOT VERIFIED"],
      ["Dashboard engine", "Compatibility review required"],
      ["Fallback", "Native Network Graph · explicit user choice"],
    ],
    VALIDATION: [
      ["Generated", "PENDING"],
      ["SPL checked", "PENDING"],
      ["Rendered", "DESIGN PREVIEW only"],
      ["Dashboard Ready", "NO"],
    ],
  }
  return (
    <aside className="dashboard-inspector">
      <header>
        <div>
          <span>ADVANCED DASHBOARD INSPECTOR</span>
          <strong>{scenario.id} · selected panel</strong>
        </div>
        <button onClick={close} aria-label="Close inspector">
          ×
        </button>
      </header>
      <nav>
        {tabs.map((item) => (
          <button
            className={tab === item ? "active" : ""}
            onClick={() => setTab(item)}
            key={item}
          >
            {item}
          </button>
        ))}
      </nav>
      <dl>
        {rows[tab].map(([term, value]) => (
          <div key={term}>
            <dt>{term}</dt>
            <dd>{value}</dd>
          </div>
        ))}
      </dl>
      <div className="inspector-note">
        <Icon name="shield" />
        <span>
          <strong>Prototype specification</strong>Authoritative values must come
          from scenario, source, Splunk, and validation contracts.
        </span>
      </div>
    </aside>
  )
}

function DashboardExportDialog({
  scenario,
  close,
}: {
  scenario: DashboardScenario
  close: () => void
}) {
  const [mode, setMode] = useState<"EXPORT" | "DEPLOY">("EXPORT")
  return (
    <div className="dashboard-modal-backdrop">
      <section className="dashboard-export-dialog">
        <header>
          <div>
            <span>IMPLEMENTATION HANDOFF · EXPORT / DEPLOY</span>
            <strong>
              {scenario.id} · {scenario.name}
            </strong>
          </div>
          <button onClick={close}>×</button>
        </header>
        <div className="export-tabs">
          <button
            className={mode === "EXPORT" ? "active" : ""}
            onClick={() => setMode("EXPORT")}
          >
            Export artifact
          </button>
          <button
            className={mode === "DEPLOY" ? "active" : ""}
            onClick={() => setMode("DEPLOY")}
          >
            Deploy to Splunk
          </button>
        </div>
        <DashboardValidationChain
          stages={[
            "PENDING",
            "PENDING",
            "PENDING",
            "PENDING",
            "PENDING",
            "PENDING",
            "PENDING",
            "PENDING",
          ]}
        />
        {mode === "EXPORT" ? (
          <div className="export-content">
            <div>
              <span>FORMAT</span>
              <strong>Dashboard Studio JSON</strong>
              <small>
                Classic XML only where a future compatibility contract permits
                it.
              </small>
            </div>
            <div>
              <span>DEPENDENCIES</span>
              <strong>{scenario.topology}</strong>
              <small>
                Installation and dashboard-engine compatibility are NOT
                VERIFIED.
              </small>
            </div>
            <div className="export-warning">
              <Icon name="shield" />
              <p>
                Design preview only. JSON generation is outside this prototype
                and no artifact has been created.
              </p>
            </div>
            <footer>
              <Button variant="ghost" onClick={close}>
                Cancel
              </Button>
              <Button disabled>Validation required</Button>
            </footer>
          </div>
        ) : (
          <div className="export-content">
            <div>
              <span>CONNECTION</span>
              <strong>Splunk connection unavailable in prototype</strong>
              <small>
                Authorization, compatibility, app dependencies, and update
                policy require future backend integration.
              </small>
            </div>
            <div className="export-warning">
              <Icon name="plug" />
              <p>
                No deployment request will be sent. A successful Figma
                interaction is not deployment evidence.
              </p>
            </div>
            <footer>
              <Button variant="ghost" onClick={close}>
                Cancel
              </Button>
              <Button disabled>Deploy unavailable</Button>
            </footer>
          </div>
        )}
      </section>
    </div>
  )
}

function ResearchRequiredDashboard({
  scenario,
  navigate,
  selectScenario,
}: {
  scenario: DashboardScenario
  navigate: (page: Page) => void
  selectScenario: (id: string) => void
}) {
  return (
    <div className="scenario-dashboard unavailable-dashboard">
      <header className="dashboard-command">
        <div className="dashboard-command__title">
          <button onClick={() => navigate("dashboards")}>←</button>
          <div>
            <span>DASHBOARDS / {scenario.id}</span>
            <strong>{scenario.name}</strong>
          </div>
          <Badge tone="amber">RESEARCH REQUIRED</Badge>
        </div>
        <div className="dashboard-scenario-switcher">
          <select
            value={scenario.id}
            onChange={(event) => selectScenario(event.target.value)}
          >
            {dashboardCatalog.map((item) => (
              <option value={item.id} key={item.id}>
                {item.id} · {item.name}
              </option>
            ))}
          </select>
        </div>
      </header>
      <main className="research-dashboard-state">
        <Icon name="shield" />
        <div>
          <span>EXECUTION AND DASHBOARD BLOCKED</span>
          <h1>Evidence is incomplete</h1>
          <p>{scenario.description}</p>
          <ul>
            <li>Native telemetry contract: NOT VERIFIED</li>
            <li>Transport and version applicability: NOT VERIFIED</li>
            <li>Splunk integration and sourcetype: NOT ESTABLISHED</li>
            <li>CIM: {scenario.cim}</li>
          </ul>
          <strong>
            No fallback event, SPL, vendor field, TA, CIM mapping, or runnable
            dashboard is generated.
          </strong>
          <div>
            <Button variant="secondary" onClick={() => navigate("dashboards")}>
              Back to Gallery
            </Button>
            <Button disabled>Run unavailable</Button>
          </div>
        </div>
      </main>
    </div>
  )
}

function ScenarioAwareDashboard({
  navigate,
  advanced,
  scenarioId,
  selectScenario,
}: {
  navigate: (page: Page) => void
  advanced: boolean
  scenarioId: string
  selectScenario: (id: string) => void
}) {
  const scenario =
    dashboardCatalog.find((item) => item.id === scenarioId) ||
    dashboardCatalog[0]
  const [view, setView] = useState<DashboardView>("NOC")
  const [selected, setSelected] = useState(scenario.entities[0] || "")
  const [filters, setFilters] = useState<string[]>([])
  const [inspectorOpen, setInspectorOpen] = useState(false)
  const [inspectorTab, setInspectorTab] = useState("OVERVIEW")
  const [exportOpen, setExportOpen] = useState(false)
  const [wallboard, setWallboard] = useState(false)
  const [event, setEvent] = useState("INCIDENT")
  if (scenario.dashboardMaturity === "RESEARCH REQUIRED")
    return (
      <ResearchRequiredDashboard
        scenario={scenario}
        navigate={navigate}
        selectScenario={selectScenario}
      />
    )
  const choose = (value: string) => {
    setSelected(value)
    setFilters((current) =>
      current.includes(value) ? current : [...current, value],
    )
  }
  const switchScenario = (id: string) => {
    selectScenario(id)
    const next = dashboardCatalog.find((item) => item.id === id)
    setSelected(next?.entities[0] || "")
    setFilters([])
    setView("NOC")
  }
  const validation: ValidationStage[] = [
    "PENDING",
    "PENDING",
    "PENDING",
    "PENDING",
    "PENDING",
    "PENDING",
    "PENDING",
    "PENDING",
  ]
  if (wallboard)
    return (
      <div className="scenario-dashboard dashboard-wallboard">
        <header>
          <div>
            <span>NOC WALLBOARD · {scenario.id}</span>
            <strong>{scenario.name}</strong>
          </div>
          <DashboardMaturityBadge maturity={scenario.dashboardMaturity} />
          <button onClick={() => setWallboard(false)}>Exit wallboard</button>
        </header>
        <main>
          <section className="wallboard-health">
            <span>CURRENT HEALTH</span>
            <strong>{scenario.kpis[0][1]}</strong>
            <small>Illustrative state from selected Dashboard Pack</small>
          </section>
          <section className="dark-panel topology-dashboard-panel">
            <header>
              <div>
                <span>PRIMARY TOPOLOGY</span>
                <strong>{scenario.topology}</strong>
              </div>
            </header>
            <DashboardTopology
              scenario={scenario}
              selected={selected}
              setSelected={choose}
            />
          </section>
          <section className="wallboard-kpis">
            {scenario.kpis.map(([label, value, tone]) => (
              <article className={`kpi-tile kpi-${tone}`} key={label}>
                <span>{label}</span>
                <strong>{value}</strong>
              </article>
            ))}
          </section>
          <section className="dark-panel dashboard-timeline-panel">
            <header>
              <div>
                <span>INCIDENT PROGRESSION</span>
                <strong>Baseline → incident → impact → recovery</strong>
              </div>
            </header>
            <div className="dark-timeline">
              {["BASELINE", "PRECURSOR", "INCIDENT", "IMPACT", "RECOVERY"].map(
                (item, index) => (
                  <button
                    key={item}
                    onClick={() => setEvent(item)}
                    className={event === item ? "active" : ""}
                  >
                    <i
                      className={
                        index < 2 ? "healthy" : index < 4 ? "critical" : "info"
                      }
                    />
                    <time>T+{index * 60}s</time>
                    <strong>{item}</strong>
                  </button>
                ),
              )}
            </div>
          </section>
        </main>
      </div>
    )
  return (
    <div className="scenario-dashboard">
      <header className="dashboard-command">
        <div className="dashboard-command__title">
          <button
            onClick={() => navigate("dashboards")}
            aria-label="Back to Dashboard Gallery"
          >
            ←
          </button>
          <div>
            <span>
              DASHBOARDS / {scenario.id} / {view}
            </span>
            <strong>{scenario.name}</strong>
          </div>
          <Badge tone="green">{scenario.scenarioMaturity}</Badge>
          <DashboardMaturityBadge maturity={scenario.dashboardMaturity} />
        </div>
        <div className="dashboard-scenario-switcher">
          <Icon name="search" size={13} />
          <select
            value={scenario.id}
            onChange={(event) => switchScenario(event.target.value)}
            aria-label="Switch scenario dashboard"
          >
            {dashboardCatalog.map((item) => (
              <option value={item.id} key={item.id}>
                {item.id} · {item.name}
              </option>
            ))}
          </select>
        </div>
        <div className="dashboard-command__actions">
          <Button
            variant="ghost"
            onClick={() => {
              setFilters([])
              setSelected(scenario.entities[0])
            }}
          >
            Reset
          </Button>
          <Button variant="secondary" onClick={() => setWallboard(true)}>
            Wallboard
          </Button>
          <Button variant="secondary" onClick={() => setExportOpen(true)}>
            Export / Deploy
          </Button>
          <Button
            variant="secondary"
            onClick={() => {
              setInspectorOpen(true)
              setInspectorTab("OVERVIEW")
            }}
          >
            Inspect panel
          </Button>
        </div>
      </header>
      <div className="dashboard-subnav">
        <div className="dashboard-view-toggle">
          {(["NOC", "ENGINEER", "EVIDENCE"] as DashboardView[]).map((item) => (
            <button
              className={view === item ? "active" : ""}
              onClick={() => setView(item)}
              key={item}
            >
              {item}
            </button>
          ))}
        </div>
        <div className="dashboard-filters">
          {filters.map((filter) => (
            <span key={filter}>
              {filter}
              <button
                onClick={() =>
                  setFilters((current) =>
                    current.filter((item) => item !== filter),
                  )
                }
              >
                ×
              </button>
            </span>
          ))}
          {filters.length > 0 && (
            <button onClick={() => setFilters([])}>Clear filters</button>
          )}
        </div>
        <span className="illustrative-label">
          DESIGN PROTOTYPE · {scenario.cim}
        </span>
      </div>
      {view === "NOC" && (
        <main className="dashboard-canvas">
          <section className="kpi-row">
            {scenario.kpis.map(([label, value, tone]) => (
              <button
                className={`kpi-tile kpi-${tone}`}
                key={label}
                onClick={() => choose(label)}
              >
                <span>{label}</span>
                <strong>{value}</strong>
                <small>Illustrative · select for supporting telemetry</small>
                <MiniTrend tone={tone} />
              </button>
            ))}
          </section>
          <section className="dashboard-primary-grid">
            <article className="dark-panel topology-dashboard-panel">
              <header>
                <div>
                  <span>PRIMARY TOPOLOGY</span>
                  <strong>{scenario.topology}</strong>
                </div>
                <button
                  onClick={() => {
                    setInspectorOpen(true)
                    setInspectorTab("VISUALIZATION")
                  }}
                >
                  Inspect dependency
                </button>
              </header>
              <DashboardTopology
                scenario={scenario}
                selected={selected}
                setSelected={choose}
                onInvestigate={() => setView("ENGINEER")}
              />
            </article>
            <article className="dark-panel incident-panel">
              <header>
                <div>
                  <span>ROOT CAUSE / EXPECTED FINDING</span>
                  <strong>{scenario.recipe}</strong>
                </div>
                <Status tone="warning">ILLUSTRATIVE</Status>
              </header>
              <div className="root-cause">
                <span>
                  <Icon name="shield" />
                </span>
                <div>
                  <small>SCENARIO-CONTRACT EXPECTATION</small>
                  <strong>{scenario.expected}</strong>
                  <p>
                    Behavioral interpretation is separate from native telemetry
                    and Splunk normalization.
                  </p>
                </div>
              </div>
              <dl>
                <div>
                  <dt>Selected</dt>
                  <dd>{selected}</dd>
                </div>
                <div>
                  <dt>Domain</dt>
                  <dd>{scenario.domainName}</dd>
                </div>
                <div>
                  <dt>CIM</dt>
                  <dd>{scenario.cim}</dd>
                </div>
                <div>
                  <dt>Dashboard</dt>
                  <dd>{scenario.dashboardMaturity}</dd>
                </div>
              </dl>
              <Button variant="secondary" onClick={() => setView("ENGINEER")}>
                Open investigation
              </Button>
            </article>
          </section>
          <section className="dark-panel dashboard-timeline-panel">
            <header>
              <div>
                <span>INCIDENT TIMELINE</span>
                <strong>
                  Click an event to set investigation time context
                </strong>
              </div>
              <span>Selected: {event}</span>
            </header>
            <div className="dark-timeline">
              {["BASELINE", "PRECURSOR", "INCIDENT", "IMPACT", "RECOVERY"].map(
                (item, index) => (
                  <button
                    key={item}
                    className={event === item ? "active" : ""}
                    onClick={() => {
                      setEvent(item)
                      choose(`Time: ${item}`)
                    }}
                  >
                    <i
                      className={
                        index < 2 ? "healthy" : index < 4 ? "critical" : "info"
                      }
                    />
                    <time>T+{index * 60}s</time>
                    <span>{item}</span>
                    <strong>
                      {index === 2
                        ? scenario.expected
                        : `${item.toLowerCase()} observation`}
                    </strong>
                  </button>
                ),
              )}
            </div>
          </section>
        </main>
      )}
      {view === "ENGINEER" && (
        <main className="dashboard-canvas engineer-view">
          <section className="engineer-summary">
            <div>
              <span>INVESTIGATION SCOPE</span>
              <strong>
                {selected} · {event} · {scenario.telemetry}
              </strong>
            </div>
            <Button onClick={() => choose("Supporting telemetry")}>
              Show supporting telemetry
            </Button>
          </section>
          <section className="dashboard-primary-grid">
            <article className="dark-panel topology-dashboard-panel">
              <header>
                <div>
                  <span>DETAILED TOPOLOGY</span>
                  <strong>Entity and dependency drilldown</strong>
                </div>
                <Badge tone="blue">{scenario.topology}</Badge>
              </header>
              <DashboardTopology
                scenario={scenario}
                selected={selected}
                setSelected={choose}
              />
            </article>
            <article className="dark-panel recommendation-panel">
              <header>
                <div>
                  <span>VISUALIZATION DECISION</span>
                  <strong>{scenario.topology}</strong>
                </div>
                <Status tone="warning">NOT VERIFIED</Status>
              </header>
              <p>{scenario.topologyReason}</p>
              <dl>
                <div>
                  <dt>Alternative</dt>
                  <dd>Native Network Graph</dd>
                </div>
                <div>
                  <dt>Dependency</dt>
                  <dd>Installation unknown</dd>
                </div>
                <div>
                  <dt>Compatibility</dt>
                  <dd>Review required</dd>
                </div>
              </dl>
              <Button
                variant="secondary"
                onClick={() => {
                  setInspectorOpen(true)
                  setInspectorTab("DEPENDENCIES")
                }}
              >
                Review dependency
              </Button>
            </article>
          </section>
          <section className="dark-panel engineer-table">
            <header>
              <div>
                <span>CORRELATED TELEMETRY</span>
                <strong>Contract-driven investigation</strong>
              </div>
              <Button
                variant="secondary"
                onClick={() => {
                  setInspectorOpen(true)
                  setInspectorTab("SPL")
                }}
              >
                Inspect SPL contract
              </Button>
            </header>
            <div className="dark-table">
              <div>
                <span>Phase</span>
                <span>Entity</span>
                <span>Observation</span>
                <span>Authority</span>
              </div>
              {["BASELINE", "INCIDENT", "IMPACT", "RECOVERY"].map(
                (phase, index) => (
                  <button key={phase} onClick={() => choose(`Time: ${phase}`)}>
                    <span>{phase}</span>
                    <span>
                      {scenario.entities[index % scenario.entities.length]}
                    </span>
                    <span>
                      {index === 1
                        ? scenario.expected
                        : `${phase.toLowerCase()} contract observation`}
                    </span>
                    <Badge tone={index === 1 ? "purple" : "neutral"}>
                      {index === 1 ? "SCENARIO EXPECTED" : "ILLUSTRATIVE"}
                    </Badge>
                  </button>
                ),
              )}
            </div>
          </section>
          <section className="dark-panel investigation-workbench">
            <header>
              <div>
                <span>TROUBLESHOOTING / SPL</span>
                <strong>Implementation handoff state</strong>
              </div>
            </header>
            <div>
              <article>
                <span>Base search</span>
                <strong>NOT VERIFIED</strong>
                <p>
                  Supply from the scenario Investigation Pack during
                  implementation.
                </p>
              </article>
              <article>
                <span>Required fields</span>
                <strong>NOT ESTABLISHED</strong>
                <p>Do not infer fields from the visualization.</p>
              </article>
              <article>
                <span>Expected finding</span>
                <strong>{scenario.expected}</strong>
                <p>Compare with observed results after search execution.</p>
              </article>
            </div>
          </section>
        </main>
      )}
      {view === "EVIDENCE" && (
        <main className="dashboard-canvas evidence-view">
          <section className="evidence-hero">
            <div>
              <span>VALIDATION POSITION</span>
              <strong>{scenario.dashboardMaturity}</strong>
              <p>
                The scenario is GOLDEN; the dashboard has not completed Splunk
                dashboard validation.
              </p>
            </div>
            <div>
              <Badge tone="green">SCENARIO · GOLDEN</Badge>
              <DashboardMaturityBadge maturity={scenario.dashboardMaturity} />
              <Badge tone="amber">CIM · {scenario.cim}</Badge>
            </div>
          </section>
          <section className="dark-panel validation-chain">
            <header>
              <div>
                <span>DASHBOARD VALIDATION</span>
                <strong>Generated to Dashboard Ready</strong>
              </div>
              <Status tone="warning">0 of 8 passed</Status>
            </header>
            <DashboardValidationChain stages={validation} />
          </section>
          <section className="evidence-dashboard-grid">
            <article className="dark-panel contract-stack">
              <header>
                <div>
                  <span>THREE-CONTRACT MODEL</span>
                  <strong>
                    Vendor, Splunk, and NetSpout claims stay separate
                  </strong>
                </div>
              </header>
              {[
                [
                  "NATIVE CONTRACT",
                  scenario.sourceContracts.join(" · ") || "NOT VERIFIED",
                  "EVIDENCE BACKED",
                ],
                [
                  "SPLUNK CONTRACT",
                  "Dashboard searches and fields require implementation validation",
                  "NOT VERIFIED",
                ],
                [
                  "NETSPOUT CONTRACT",
                  `${scenario.recipe} · modeled scenario state`,
                  "DESIGN INPUT",
                ],
              ].map(([type, description, state]) => (
                <button
                  key={type}
                  onClick={() => {
                    setInspectorOpen(true)
                    setInspectorTab(
                      type === "SPLUNK CONTRACT"
                        ? "SPL"
                        : type === "NATIVE CONTRACT"
                          ? "FIELDS"
                          : "OVERVIEW",
                    )
                  }}
                >
                  <span>
                    <strong>{type}</strong>
                    <small>{description}</small>
                  </span>
                  <Badge tone={state === "EVIDENCE BACKED" ? "green" : "amber"}>
                    {state}
                  </Badge>
                  <Icon name="chevron" size={13} />
                </button>
              ))}
            </article>
            <article className="dark-panel observation-stages">
              <header>
                <div>
                  <span>SCENARIO RUNTIME EVIDENCE</span>
                  <strong>Dashboard validation remains separate</strong>
                </div>
              </header>
              {[
                "Generated",
                "Receiver observed",
                "Splunk observed",
                "Dashboard search",
                "Fields verified",
                "Visualization rendered",
              ].map((item, index) => (
                <div key={item}>
                  <i>
                    {index < 3 ? <Icon name="check" size={11} /> : index + 1}
                  </i>
                  <span>
                    <strong>{item}</strong>
                    <small>
                      {index < 3
                        ? "Scenario evidence recorded"
                        : "Dashboard validation pending"}
                    </small>
                  </span>
                  {index < 5 && <b />}
                </div>
              ))}
            </article>
          </section>
          <section className="dark-panel evidence-table">
            <header>
              <div>
                <span>PROVENANCE / EXPECTED VS OBSERVED</span>
                <strong>Evidence-aware panel specification</strong>
              </div>
              <Badge tone="amber">NO DASHBOARD OBSERVATION YET</Badge>
            </header>
            <div className="dark-table">
              <div>
                <span>Claim</span>
                <span>Expected</span>
                <span>Observed</span>
                <span>Status</span>
              </div>
              <button
                onClick={() => {
                  setInspectorOpen(true)
                  setInspectorTab("VALIDATION")
                }}
              >
                <span>Primary finding</span>
                <span>{scenario.expected}</span>
                <span>NOT OBSERVED IN DASHBOARD</span>
                <Badge tone="amber">PENDING</Badge>
              </button>
              <button
                onClick={() => {
                  setInspectorOpen(true)
                  setInspectorTab("CIM")
                }}
              >
                <span>CIM</span>
                <span>Independent validation</span>
                <span>{scenario.cim}</span>
                <Badge tone="amber">NOT ESTABLISHED</Badge>
              </button>
            </div>
          </section>
        </main>
      )}
      {(advanced || inspectorOpen) && (
        <DashboardInspector
          scenario={scenario}
          tab={inspectorTab}
          setTab={setInspectorTab}
          close={() => setInspectorOpen(false)}
        />
      )}{" "}
      {exportOpen && (
        <DashboardExportDialog
          scenario={scenario}
          close={() => setExportOpen(false)}
        />
      )}
    </div>
  )
}

export default function NetSpoutApp() {
  const [page, setPage] = useState<Page>("home")
  const [collapsed, setCollapsed] = useState(false)
  const [advanced, setAdvanced] = useState(false)
  const [selectedDashboardId, setSelectedDashboardId] = useState("C100-SP-001")
  const navigate = (target: Page) => {
    setPage(target)
    window.scrollTo({ top: 0, behavior: "smooth" })
  }
  const screen = useMemo(() => {
    if (page === "home") return <UnifiedHome navigate={navigate} />
    if (page === "generate") return <GenerateHub navigate={navigate} />
    if (page === "data-source")
      return <GeneratorWorkspace mode="data" navigate={navigate} />
    if (page === "sourcetype")
      return <GeneratorWorkspace mode="sourcetype" navigate={navigate} />
    if (page === "single-event")
      return <GeneratorWorkspace mode="single" navigate={navigate} />
    if (page === "scenarios")
      return <RefinedScenarioLibrary navigate={navigate} />
    if (page === "dashboards")
      return (
        <DashboardGallery
          navigate={navigate}
          selectScenario={setSelectedDashboardId}
        />
      )
    if (page === "dashboard")
      return (
        <ScenarioAwareDashboard
          navigate={navigate}
          advanced={advanced}
          scenarioId={selectedDashboardId}
          selectScenario={setSelectedDashboardId}
        />
      )
    if (page === "security")
      return <SecurityScenarioDetail navigate={navigate} />
    if (page === "security-run") return <SecurityLiveRun navigate={navigate} />
    if (page === "itops") return <ITOpsScenarioDetail advanced={advanced} />
    if (page === "supply-chain")
      return <SupplyChainScenarioDetail navigate={navigate} />
    if (page === "supply-run") return <SupplyChainLiveRun />
    if (page === "scenario") return <ScenarioTrustView navigate={navigate} />
    if (page === "run") return <MultiDomainLiveRun navigate={navigate} />
    if (page === "timeline") return <TimelinePage navigate={navigate} />
    if (page === "investigation") return <Investigation navigate={navigate} />
    if (page === "explorer")
      return <TrustedTelemetryCatalog advanced={advanced} />
    if (page === "provenance") return <TrustedTelemetryCatalog advanced />
    if (page === "integrations") return <SplunkIntegrationsCatalog />
    if (page === "builder") return <ScenarioBuilder />
    if (page === "agentic") return <AgenticIncident navigate={navigate} />
    if (page === "pipeline") return <EvidenceBasedPipeline />
    return <Connections />
  }, [page, advanced, selectedDashboardId])
  return (
    <div className="app-shell">
      <a className="skip-link" href="#main">
        Skip to content
      </a>
      <Sidebar
        page={page}
        navigate={navigate}
        collapsed={collapsed}
        setCollapsed={setCollapsed}
      />
      <div className="app-main">
        <Topbar page={page} advanced={advanced} setAdvanced={setAdvanced} />
        <main id="main">
          {advanced && (
            <div className="advanced-banner">
              <Icon name="settings" size={15} />
              <strong>Advanced mode enabled</strong>
              <span>
                Protocol paths, transport details and raw payloads are visible.
              </span>
            </div>
          )}
          {screen}
        </main>
      </div>
    </div>
  )
}
